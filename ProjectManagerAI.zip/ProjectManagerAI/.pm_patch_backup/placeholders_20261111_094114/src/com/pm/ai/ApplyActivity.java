package com.pm.ai;
import @@PKG@@.core.CoverManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.pm.ai.core.Action;
import com.pm.ai.core.ActionApplier;
import com.pm.ai.core.Prefs;
import com.pm.ai.core.Project;
import com.pm.ai.core.PromptBuilder;
import com.pm.ai.core.ResponseParser;
import com.pm.ai.core.Storage;
import com.pm.ai.ui.ActionAdapter;
import com.pm.ai.util.Utils;

import java.util.ArrayList;
import java.util.List;

public class ApplyActivity extends Activity {

    private Storage store;
    private Project p;
    private EditText etResponse;
    private TextView tvLog;
    private ListView lv;
    private LinearLayout paneInput;
    private LinearLayout paneActions;
    private ScrollView paneLog;
    private TextView tabInput;
    private TextView tabActions;
    private TextView tabLog;
    private LinearLayout banner;
    private TextView tvBanner;

    private final List<Action> actions = new ArrayList<Action>();
    private ActionAdapter adapter;
    private ResponseParser.Result last;
    private String pendingContinuePath = null;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_apply);
        store = Storage.get(this);
        p = store.open(getIntent().getStringExtra("project"));

        etResponse = (EditText) findViewById(R.id.etResponse);
        tvLog = (TextView) findViewById(R.id.tvLog);
        lv = (ListView) findViewById(R.id.lvActions);
        paneInput = (LinearLayout) findViewById(R.id.paneInput);
        paneActions = (LinearLayout) findViewById(R.id.paneActions);
        paneLog = (ScrollView) findViewById(R.id.paneLog);
        tabInput = (TextView) findViewById(R.id.tabInput);
        tabActions = (TextView) findViewById(R.id.tabActions);
        tabLog = (TextView) findViewById(R.id.tabLog);
        banner = (LinearLayout) findViewById(R.id.banner);
        tvBanner = (TextView) findViewById(R.id.tvBanner);

        ((TextView) findViewById(R.id.tvSub)).setText(p.name + " | " + p.typeLabel());

        adapter = new ActionAdapter(this, actions);
        lv.setAdapter(adapter);

        tabInput.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(0);
            }
        });
        tabActions.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(1);
            }
        });
        tabLog.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(2);
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.btnHelp).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                help();
            }
        });
        findViewById(R.id.btnPaste).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String c = Utils.clipboard(ApplyActivity.this);
                if (c.length() == 0) {
                    Utils.toast(ApplyActivity.this, "El portapapeles esta vacio");
                    return;
                }
                etResponse.setText(c);
                etResponse.setSelection(c.length());
                Utils.toast(ApplyActivity.this, c.length() + " caracteres pegados");
            }
        });
        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etResponse.setText("");
            }
        });
        findViewById(R.id.btnAnalyze).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                analyze();
            }
        });
        findViewById(R.id.btnAll).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean any = false;
                for (int i = 0; i < actions.size(); i++) if (!actions.get(i).selected) any = true;
                for (int i = 0; i < actions.size(); i++) actions.get(i).selected = any;
                adapter.notifyDataSetChanged();
            }
        });
        findViewById(R.id.btnApply).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                applySelected();
            }
        });
        findViewById(R.id.btnBanner).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                goContinue();
            }
        });

        List<String> pend = PromptBuilder.pendingPaths(p);
        if (pend.size() > 0) {
            banner.setVisibility(View.VISIBLE);
            tvBanner.setText(pend.size() + " archivo(s) a medias: " + Utils.join(pend, ", "));
            pendingContinuePath = pend.get(0);
        }
        showPane(0);
    }

    private void showPane(int i) {
        paneInput.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        paneActions.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        paneLog.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
        tabInput.setSelected(i == 0);
        tabActions.setSelected(i == 1);
        tabLog.setSelected(i == 2);
    }

    private void analyze() {
        String text = etResponse.getText().toString();
        if (text.trim().length() == 0) {
            Utils.toast(this, "Pega primero la respuesta de Qwen");
            return;
        }
        store.saveResponse(p, text);
        last = ResponseParser.parse(text);
        actions.clear();
        actions.addAll(last.actions);
        adapter.notifyDataSetChanged();

        StringBuilder head = new StringBuilder();
        head.append("Analizadas ").append(actions.size()).append(" acciones de ").append(last.chars).append(" caracteres.\n");
        if (last.usedFallback) head.append("AVISO: sin marcadores @@PM, se uso deteccion de bloques markdown.\n");
        if (last.plan.size() > 0) {
            head.append("\nPLAN:\n");
            for (int i = 0; i < last.plan.size(); i++) head.append("  ").append(last.plan.get(i)).append("\n");
        }
        if (last.summary.length() > 0) head.append("\nRESUMEN:\n").append(last.summary).append("\n");
        if (last.next.length() > 0) head.append("\nSIGUIENTE PASO:\n").append(last.next).append("\n");
        if (last.warnings.size() > 0) {
            head.append("\nAVISOS:\n");
            for (int i = 0; i < last.warnings.size(); i++) head.append("  - ").append(last.warnings.get(i)).append("\n");
        }
        tvLog.setText(head.toString());

        List<Action> inc = last.incompleteFiles();
        if (inc.size() > 0) {
            banner.setVisibility(View.VISIBLE);
            tvBanner.setText(inc.size() + " archivo(s) incompletos: " + inc.get(0).path);
            pendingContinuePath = inc.get(0).path;
        } else {
            banner.setVisibility(View.GONE);
        }

        if (actions.size() == 0) {
            Utils.toastLong(this, "No se detecto ninguna accion. Revisa que la respuesta use los marcadores @@PM_");
            showPane(2);
        } else {
            showPane(1);
        }
    }

    private void applySelected() {
        if (actions.size() == 0) {
            Utils.toast(this, "Analiza primero la respuesta");
            return;
        }
        int n = 0;
        for (int i = 0; i < actions.size(); i++) if (actions.get(i).selected) n++;
        if (n == 0) {
            Utils.toast(this, "No hay acciones marcadas");
            return;
        }
        ActionApplier.Report rep = ActionApplier.apply(store, p, actions, Prefs.backup(this));
        CoverManager.ensure(store, p);
        adapter.notifyDataSetChanged();
        StringBuilder sb = new StringBuilder(tvLog.getText().toString());
        sb.append("\n\n").append(rep.text());
        tvLog.setText(sb.toString());
        showPane(2);

        List<Action> inc = new ArrayList<Action>();
        for (int i = 0; i < actions.size(); i++) if (actions.get(i).incomplete()) inc.add(actions.get(i));
        if (inc.size() > 0 || rep.partial > 0) {
            banner.setVisibility(View.VISIBLE);
            String path = inc.size() > 0 ? inc.get(0).path : null;
            if (path == null) {
                List<String> pend = PromptBuilder.pendingPaths(p);
                path = pend.size() > 0 ? pend.get(0) : null;
            }
            pendingContinuePath = path;
            tvBanner.setText("Hay codigo sin terminar. Pulsa CONTINUAR para pedir el resto a Qwen.");
        } else {
            banner.setVisibility(View.GONE);
        }

        new AlertDialog.Builder(this)
                .setTitle("Aplicado")
                .setMessage(rep.ok + " correctos, " + rep.fail + " fallos, " + rep.partial + " parciales.\n\n"
                        + (rep.backupPath.length() > 0 ? "Backup en:\n" + rep.backupPath : "Sin backup"))
                .setPositiveButton(R.string.act_ok, null)
                .setNeutralButton("Ver log", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        showPane(2);
                    }
                })
                .show();
    }

    private void goContinue() {
        Intent i = new Intent(this, PromptActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("mode", PromptBuilder.MODE_CONTINUE);
        if (pendingContinuePath != null) i.putExtra("path", pendingContinuePath);
        startActivity(i);
    }

    private void help() {
        new AlertDialog.Builder(this)
                .setTitle("Protocolo PM")
                .setMessage(ResponseParser.PAT_HELP)
                .setPositiveButton(R.string.act_ok, null)
                .show();
    }
}
