package com.pm.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.pm.ai.core.Prefs;
import com.pm.ai.core.Project;
import com.pm.ai.core.Runner;
import com.pm.ai.core.Storage;
import com.pm.ai.ui.CodeEditor;
import com.pm.ai.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EditorActivity extends Activity {

    private Storage store;
    private Project p;
    private String path;
    private CodeEditor editor;
    private TextView tvPos;
    private TextView tvDirty;
    private boolean dirty = false;
    private String original = "";

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        store = Storage.get(this);
        p = store.open(getIntent().getStringExtra("project"));
        path = Utils.normPath(getIntent().getStringExtra("path"));

        editor = (CodeEditor) findViewById(R.id.editor);
        tvPos = (TextView) findViewById(R.id.tvPos);
        tvDirty = (TextView) findViewById(R.id.tvDirty);
        LinearLayout tools = (LinearLayout) findViewById(R.id.llTools);

        ((TextView) findViewById(R.id.tvFile)).setText(Utils.baseName(path));
        ((TextView) findViewById(R.id.tvPath)).setText(p.name + "/" + path);

        editor.setHighlightEnabled(Prefs.highlight(this));
        editor.setGutterEnabled(Prefs.gutter(this));
        editor.setLang(path);
        editor.setListener(new CodeEditor.Listener() {
            public void onContentChanged() {
                dirty = !editor.content().equals(original);
                tvDirty.setText(dirty ? "sin guardar" : "");
            }

            public void onCursorMoved(int line, int col) {
                tvPos.setText("Ln " + line + ", Col " + col);
            }
        });

        original = store.read(p, path);
        editor.load(original);
        dirty = false;
        tvDirty.setText("");

        buildTools(tools);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                save();
            }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showMenu(v);
            }
        });
    }

    private void buildTools(LinearLayout tools) {
        String[][] items = {
                {"tab", "    "}, {"{", "{"}, {"}", "}"}, {"(", "("}, {")", ")"},
                {"[", "["}, {"]", "]"}, {"\"", "\""}, {"'", "'"}, {"<", "<"}, {">", ">"},
                {"/", "/"}, {";", ";"}, {":", ":"}, {".", "."}, {",", ","},
                {"=", "="}, {"+", "+"}, {"-", "-"}, {"*", "*"}, {"_", "_"}, {"@", "@"}, {"#", "#"},
                {"//", "//"}, {"/*", "/*"}, {"*/", "*/"}, {"<!", "<!--"}, {"-->", "-->"},
                {"nl", "\n"}
        };
        for (int i = 0; i < items.length; i++) {
            final String ins = items[i][1];
            TextView tv = (TextView) LayoutInflater.from(this).inflate(R.layout.item_tool_btn, tools, false);
            tv.setText(items[i][0]);
            tv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    editor.insertText(ins);
                }
            });
            tools.addView(tv);
        }
        TextView wrap = (TextView) LayoutInflater.from(this).inflate(R.layout.item_tool_btn, tools, false);
        wrap.setText("()");
        wrap.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editor.wrapSelection("(", ")");
            }
        });
        tools.addView(wrap);

        TextView wrapQ = (TextView) LayoutInflater.from(this).inflate(R.layout.item_tool_btn, tools, false);
        wrapQ.setText("\"\"");
        wrapQ.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editor.wrapSelection("\"", "\"");
            }
        });
        tools.addView(wrapQ);

        TextView desh = (TextView) LayoutInflater.from(this).inflate(R.layout.item_tool_btn, tools, false);
        desh.setText("deshacer");
        desh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editor.load(original);
                dirty = false;
                tvDirty.setText("");
            }
        });
        tools.addView(desh);
    }

    private boolean save() {
        String c = editor.content();
        if (store.write(p, path, c)) {
            original = c;
            dirty = false;
            tvDirty.setText("");
            Utils.toast(this, "Guardado " + path);
            return true;
        }
        Utils.toast(this, "No se pudo guardar");
        return false;
    }

    public void onBackPressed() {
        if (dirty) {
            new AlertDialog.Builder(this)
                    .setTitle("Guardar cambios?")
                    .setMessage(path)
                    .setPositiveButton(R.string.act_save, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            save();
                            finish();
                        }
                    })
                    .setNegativeButton("Descartar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            finish();
                        }
                    })
                    .setNeutralButton(R.string.act_cancel, null)
                    .show();
            return;
        }
        super.onBackPressed();
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Buscar y reemplazar");
        pm.getMenu().add(0, 2, 0, "Ir a linea");
        pm.getMenu().add(0, 3, 0, "Ejecutar / previsualizar");
        pm.getMenu().add(0, 4, 0, "Pedir cambio a Qwen (archivo)");
        pm.getMenu().add(0, 5, 0, "Copiar contenido");
        pm.getMenu().add(0, 6, 0, "Compartir contenido");
        pm.getMenu().add(0, 7, 0, "Copiar ruta");
        pm.getMenu().add(0, 8, 0, "Renombrar archivo");
        pm.getMenu().add(0, 9, 0, "Eliminar archivo");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == 1) searchDialog();
                else if (id == 2) gotoLine();
                else if (id == 3) {
                    save();
                    Runner.runFile(EditorActivity.this, p, path);
                } else if (id == 4) askQwen();
                else if (id == 5) Utils.copy(EditorActivity.this, path, editor.content());
                else if (id == 6) Utils.share(EditorActivity.this, path, editor.content());
                else if (id == 7) Utils.copy(EditorActivity.this, "ruta", p.name + "/" + path);
                else if (id == 8) renameFile();
                else if (id == 9) deleteFile();
                return true;
            }
        });
        pm.show();
    }

    private void searchDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_search, null);
        final EditText etFind = (EditText) v.findViewById(R.id.etFind);
        final EditText etRepl = (EditText) v.findViewById(R.id.etRepl);
        final CheckBox cbRx = (CheckBox) v.findViewById(R.id.cbRegex);
        final TextView tvCount = (TextView) v.findViewById(R.id.tvCount);

        int s = Math.min(editor.getSelectionStart(), editor.getSelectionEnd());
        int e = Math.max(editor.getSelectionStart(), editor.getSelectionEnd());
        if (e > s) etFind.setText(editor.content().substring(s, e));

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Buscar y reemplazar")
                .setView(v)
                .setPositiveButton("Reemplazar todo", null)
                .setNeutralButton("Reemplazar 1", null)
                .setNegativeButton(R.string.act_cancel, null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        int n = doReplace(etFind.getText().toString(), etRepl.getText().toString(), cbRx.isChecked(), false);
                        tvCount.setText(n + " reemplazos");
                    }
                });
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        int n = doReplace(etFind.getText().toString(), etRepl.getText().toString(), cbRx.isChecked(), true);
                        tvCount.setText(n + " reemplazo(s)");
                    }
                });
            }
        });
        dlg.show();
    }

    private int doReplace(String find, String repl, boolean regex, boolean onlyFirst) {
        if (find == null || find.length() == 0) return 0;
        String text = editor.content();
        int n = 0;
        String out;
        if (regex) {
            try {
                Pattern pt = Pattern.compile(find);
                Matcher m = pt.matcher(text);
                StringBuffer sb = new StringBuffer();
                while (m.find()) {
                    n++;
                    m.appendReplacement(sb, Matcher.quoteReplacement(repl));
                    if (onlyFirst) break;
                }
                m.appendTail(sb);
                out = sb.toString();
            } catch (Exception ex) {
                Utils.toast(this, "Regex invalida");
                return 0;
            }
        } else {
            n = Utils.countOccurrences(text, find);
            if (n == 0) {
                Utils.toast(this, "No se encontro");
                return 0;
            }
            if (onlyFirst) {
                int i = text.indexOf(find);
                out = text.substring(0, i) + repl + text.substring(i + find.length());
                n = 1;
            } else {
                out = text.replace(find, repl);
            }
        }
        if (n > 0) {
            editor.load(out);
            dirty = true;
            tvDirty.setText("sin guardar");
        }
        return n;
    }

    private void gotoLine() {
        final EditText et = new EditText(this);
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        et.setHint("numero de linea");
        new AlertDialog.Builder(this)
                .setTitle("Ir a linea")
                .setView(et)
                .setPositiveButton("Ir", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        try {
                            editor.goToLine(Integer.parseInt(et.getText().toString().trim()));
                        } catch (Exception e) {
                            Utils.toast(EditorActivity.this, "Numero no valido");
                        }
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void askQwen() {
        save();
        String sel = "";
        int s = Math.min(editor.getSelectionStart(), editor.getSelectionEnd());
        int e = Math.max(editor.getSelectionStart(), editor.getSelectionEnd());
        if (e > s) sel = editor.content().substring(s, e);
        StringBuilder task = new StringBuilder();
        task.append("Modificar el archivo ").append(path).append(".\n");
        task.append("Cambio pedido: \n");
        if (sel.length() > 0) {
            task.append("\nFragmento seleccionado del archivo:\n").append(sel).append("\n");
        }
        Intent i = new Intent(this, PromptActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("mode", "UPDATE");
        i.putExtra("task", task.toString());
        i.putExtra("picked", path);
        startActivity(i);
    }

    private void renameFile() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(path);
        new AlertDialog.Builder(this)
                .setTitle("Renombrar / mover")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String to = Utils.normPath(et.getText().toString());
                        if (!Utils.isSafePath(to)) {
                            Utils.toast(EditorActivity.this, "Ruta no valida");
                            return;
                        }
                        File src = store.file(p, path);
                        File dst = store.file(p, to);
                        if (dst.exists()) {
                            Utils.toast(EditorActivity.this, "Ya existe");
                            return;
                        }
                        save();
                        File pd = dst.getParentFile();
                        if (pd != null && !pd.exists()) pd.mkdirs();
                        if (src.renameTo(dst)) {
                            path = to;
                            store.touch(p);
                            ((TextView) findViewById(R.id.tvFile)).setText(Utils.baseName(path));
                            ((TextView) findViewById(R.id.tvPath)).setText(p.name + "/" + path);
                            editor.setLang(path);
                        } else {
                            Utils.toast(EditorActivity.this, "No se pudo renombrar");
                        }
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void deleteFile() {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + path + "?")
                .setPositiveButton(R.string.act_delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        store.file(p, path).delete();
                        store.touch(p);
                        dirty = false;
                        finish();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }
}
