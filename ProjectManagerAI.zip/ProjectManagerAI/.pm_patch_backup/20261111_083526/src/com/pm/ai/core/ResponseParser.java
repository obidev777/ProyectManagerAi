package com.pm.ai.core;

import com.pm.ai.util.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Analiza la respuesta del modelo (Protocolo PM) y produce la lista de acciones.
 * Es tolerante: acepta marcadores dentro de comentarios, bloques markdown
 * envolventes y variantes de nombre. Si no encuentra ningun marcador, intenta
 * reconstruir las acciones desde bloques de codigo markdown con su ruta.
 */
public class ResponseParser {

    private static final Pattern PAT = Pattern.compile("PM_([A-Za-z_]+)\\s*[:=]?\\s*(.*)");
    private static final Pattern PATHY = Pattern.compile("([A-Za-z0-9_.\\-/]+\\.[A-Za-z0-9]{1,8})");

    public static final String PAT_HELP =
            "PROTOCOLO PM: la respuesta de Qwen debe llevar marcadores de texto.\n"
            + "@@PM_START  ...  @@PM_END\n"
            + "@@PM_FILE / @@PM_ACTION: CREATE|REPLACE|EDIT|DELETE|RENAME|CONTINUE|APPEND\n"
            + "@@PM_PATH: ruta/relativa   @@PM_LANG   @@PM_NOTE\n"
            + "@@PM_CODE_START ... @@PM_CODE_END   @@PM_STATUS: COMPLETE|INCOMPLETE\n"
            + "@@PM_END_FILE\n"
            + "Para ediciones: @@PM_EDIT_START + @@PM_FIND_START/@@PM_FIND_END +\n"
            + "@@PM_REPLACE_START/@@PM_REPLACE_END + @@PM_EDIT_END.\n"
            + "Si el codigo se corta: @@PM_STATUS: INCOMPLETE y esta app generara\n"
            + "el prompt CONTINUAR con las ultimas lineas ya escritas.";

    public static class Result {
        public List<Action> actions = new ArrayList<Action>();
        public List<String> plan = new ArrayList<String>();
        public List<String> warnings = new ArrayList<String>();
        public String projectName = "";
        public String mode = "";
        public String summary = "";
        public String next = "";
        public boolean truncated = false;
        public boolean usedFallback = false;
        public int chars = 0;

        public List<Action> incompleteFiles() {
            List<Action> out = new ArrayList<Action>();
            for (int i = 0; i < actions.size(); i++) {
                if (actions.get(i).incomplete()) out.add(actions.get(i));
            }
            return out;
        }

        public int countSelected() {
            int n = 0;
            for (int i = 0; i < actions.size(); i++) if (actions.get(i).selected) n++;
            return n;
        }
    }

    public static Result parse(String text) {
        Result res = new Result();
        if (text == null) text = "";
        res.chars = text.length();
        String norm = text.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = norm.split("\n", -1);

        Action cur = null;
        StringBuilder buf = new StringBuilder();
        int mode = 0;   // 0 nada, 1 code, 2 find, 3 replace, 4 plan, 6 note, 7 summary, 8 next
        String pendingFind = null;
        boolean fence = false;
        boolean wantFence = false;

        for (int i = 0; i < lines.length; i++) {
            String raw = lines[i];
            String t = raw.trim();

            if (mode == 1 || mode == 2 || mode == 3) {
                if (wantFence) {
                    wantFence = false;
                    if (t.startsWith("```")) {
                        fence = true;
                        continue;
                    }
                }
                String k = markerKey(t);
                boolean closing = false;
                boolean fallthrough = false;
                if (k != null) {
                    if (mode == 1 && (k.equals("CODE_END") || k.equals("CONTENT_END") || k.equals("BEGIN_END"))) closing = true;
                    else if (mode == 2 && (k.equals("FIND_END") || k.equals("END_FIND"))) closing = true;
                    else if (mode == 3 && (k.equals("REPLACE_END") || k.equals("EDIT_END") || k.equals("CODE_END") || k.equals("END_REPLACE"))) closing = true;
                    else if (k.equals("END_FILE") || k.equals("STATUS") || k.equals("SUMMARY")
                            || k.equals("END") || k.equals("FILE") || k.equals("FILE_STATUS")) fallthrough = true;
                }
                if (closing) {
                    if (mode == 1) {
                        if (cur != null) cur.content = stripFenceTail(buf.toString());
                    } else if (mode == 2) {
                        pendingFind = buf.toString();
                    } else {
                        if (cur != null) {
                            cur.edits.add(new String[]{pendingFind == null ? "" : pendingFind, buf.toString()});
                        }
                        pendingFind = null;
                    }
                    buf.setLength(0);
                    mode = 0;
                    fence = false;
                    continue;
                }
                if (fallthrough) {
                    if (mode == 1) {
                        if (cur != null) cur.content = stripFenceTail(buf.toString());
                    } else if (mode == 2) {
                        pendingFind = buf.toString();
                    } else {
                        if (cur != null) {
                            cur.edits.add(new String[]{pendingFind == null ? "" : pendingFind, buf.toString()});
                        }
                        pendingFind = null;
                    }
                    buf.setLength(0);
                    mode = 0;
                    fence = false;
                } else {
                    if (fence && t.startsWith("```")) continue;
                    buf.append(raw).append("\n");
                    continue;
                }
            }

            if (mode == 6) {
                if (markerKey(t) == null) {
                    buf.append(raw).append("\n");
                    continue;
                }
                if (cur != null) cur.note = buf.toString().trim();
                buf.setLength(0);
                mode = 0;
            } else if (mode == 4) {
                if (markerKey(t) == null) {
                    buf.append(raw).append("\n");
                    continue;
                }
                addNonEmpty(res.plan, buf.toString());
                buf.setLength(0);
                mode = 0;
            } else if (mode == 7) {
                if (markerKey(t) == null) {
                    buf.append(raw).append("\n");
                    continue;
                }
                res.summary = buf.toString().trim();
                buf.setLength(0);
                mode = 0;
            } else if (mode == 8) {
                if (markerKey(t) == null) {
                    buf.append(raw).append("\n");
                    continue;
                }
                res.next = buf.toString().trim();
                buf.setLength(0);
                mode = 0;
            }

            String key = markerKey(t);
            if (key == null) continue;
            String val = markerVal(t);

            if (key.equals("START") || key.equals("BEGIN")) continue;
            if (key.equals("PROJECT") || key.equals("PROJECT_NAME")) {
                res.projectName = val;
                continue;
            }
            if (key.equals("MODE")) {
                res.mode = val;
                continue;
            }
            if (key.equals("PLAN")) {
                mode = 4;
                buf.setLength(0);
                continue;
            }
            if (key.equals("END_PLAN")) {
                addNonEmpty(res.plan, buf.toString());
                buf.setLength(0);
                mode = 0;
                continue;
            }
            if (key.equals("FILE")) {
                if (cur != null) push(res, cur);
                cur = new Action();
                mode = 0;
                continue;
            }
            if (key.equals("END")) {
                if (cur != null) {
                    push(res, cur);
                    cur = null;
                }
                break;
            }
            if (key.equals("SUMMARY")) {
                mode = 7;
                buf.setLength(0);
                continue;
            }
            if (key.equals("NEXT")) {
                if (val.length() == 0) {
                    mode = 8;
                    buf.setLength(0);
                } else {
                    res.next = val;
                }
                continue;
            }
            if (key.equals("WARN") || key.equals("WARNING") || key.equals("INFO")) {
                res.warnings.add(val);
                continue;
            }
            if (cur == null) continue;

            if (key.equals("ACTION") || key.equals("OP") || key.equals("TYPE")) {
                cur.kind = Action.kindFrom(val);
            } else if (key.equals("PATH") || key.equals("FILE_PATH")) {
                cur.path = Utils.normPath(val);
            } else if (key.equals("TARGET") || key.equals("NEW_PATH") || key.equals("TO") || key.equals("DEST")) {
                cur.target = Utils.normPath(val);
            } else if (key.equals("LANG") || key.equals("LANGUAGE")) {
                cur.lang = val;
            } else if (key.equals("NOTE") || key.equals("DESC") || key.equals("DESCRIPTION")) {
                if (val.length() == 0) {
                    mode = 6;
                    buf.setLength(0);
                } else {
                    cur.note = val;
                }
            } else if (key.equals("CODE_START") || key.equals("CONTENT_START") || key.equals("BEGIN_CONTENT")) {
                mode = 1;
                buf.setLength(0);
                wantFence = true;
            } else if (key.equals("FIND_START") || key.equals("SEARCH_START")) {
                mode = 2;
                buf.setLength(0);
                wantFence = true;
            } else if (key.equals("REPLACE_START") || key.equals("REPLACE_WITH_START")) {
                mode = 3;
                buf.setLength(0);
                wantFence = true;
            } else if (key.equals("EDIT_START")) {
                mode = 0;
            } else if (key.equals("STATUS") || key.equals("FILE_STATUS")) {
                cur.status = val.toUpperCase();
            } else if (key.equals("END_FILE")) {
                push(res, cur);
                cur = null;
                mode = 0;
            }
        }

        if (mode == 1 && cur != null) {
            cur.content = stripFenceTail(buf.toString());
            cur.status = "INCOMPLETE";
            res.truncated = true;
            res.warnings.add("La respuesta se corto dentro del archivo: " + cur.path);
        }
        if (cur != null) push(res, cur);

        if (res.actions.isEmpty() && text.indexOf("```") >= 0) fallbackMarkdown(text, res);
        return res;
    }

    private static void push(Result res, Action a) {
        if (a == null) return;
        if (a.path.length() == 0) {
            res.warnings.add("Bloque sin @@PM_PATH ignorado");
            return;
        }
        if (a.kind == Action.UNKNOWN) {
            if (a.content.length() > 0) a.kind = Action.CREATE;
            else if (a.edits.size() > 0) a.kind = Action.EDIT;
            else a.kind = Action.CREATE;
        }
        if (a.kind == Action.EDIT && a.edits.isEmpty() && a.content.length() > 0) a.kind = Action.REPLACE;
        if (a.incomplete()) res.truncated = true;
        res.actions.add(a);
    }

    private static void addNonEmpty(List<String> out, String block) {
        List<String> ls = Utils.splitLines(block);
        for (int i = 0; i < ls.size(); i++) {
            String s = ls.get(i).trim();
            if (s.length() > 0) out.add(s);
        }
    }

    private static String stripFenceTail(String s) {
        if (s == null) return "";
        List<String> ls = Utils.splitLines(s);
        while (ls.size() > 0 && ls.get(ls.size() - 1).trim().length() == 0) ls.remove(ls.size() - 1);
        if (ls.size() > 0 && ls.get(ls.size() - 1).trim().startsWith("```")) ls.remove(ls.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ls.size(); i++) sb.append(ls.get(i)).append("\n");
        return sb.toString();
    }

    private static String clean(String line) {
        String s = line == null ? "" : line.trim();
        if (s.startsWith("<!--")) s = s.substring(4);
        if (s.endsWith("-->")) s = s.substring(0, s.length() - 3);
        if (s.startsWith("/*")) s = s.substring(2);
        if (s.endsWith("*/")) s = s.substring(0, s.length() - 2);
        s = s.trim();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '@' || c == '#' || c == '>' || c == '*' || c == '`' || c == ' '
                    || c == '\t' || c == ':' || c == '-') i++;
            else break;
        }
        return s.substring(i).trim();
    }

    private static String markerKey(String line) {
        String s = clean(line);
        if (s.length() < 5) return null;
        Matcher m = PAT.matcher(s);
        if (m.find() && m.start() <= 2) return m.group(1).toUpperCase();
        return null;
    }

    private static String markerVal(String line) {
        String s = clean(line);
        Matcher m = PAT.matcher(s);
        if (m.find() && m.start() <= 2) {
            String v = m.group(2);
            return v == null ? "" : v.trim();
        }
        return "";
    }

    /** Plan B: respuestas sin protocolo, solo bloques markdown con su ruta. */
    private static void fallbackMarkdown(String text, Result res) {
        res.usedFallback = true;
        res.warnings.add("Sin marcadores @@PM: se han detectado bloques de codigo markdown con su ruta.");
        String[] lines = text.replace("\r\n", "\n").split("\n", -1);
        int i = 0;
        while (i < lines.length) {
            String t = lines[i].trim();
            if (t.startsWith("```") && t.length() > 3) {
                String lang = t.substring(3).trim();
                StringBuilder body = new StringBuilder();
                int j = i + 1;
                while (j < lines.length && !lines[j].trim().startsWith("```")) {
                    body.append(lines[j]).append("\n");
                    j++;
                }
                String path = pathNear(lines, i, j);
                if (path != null && body.length() > 0) {
                    Action a = new Action();
                    a.kind = Action.CREATE;
                    a.path = path;
                    a.lang = lang;
                    a.content = body.toString();
                    a.note = "detectado desde bloque markdown";
                    res.actions.add(a);
                }
                i = j + 1;
            } else {
                i++;
            }
        }
    }

    private static String pathNear(String[] lines, int start, int end) {
        for (int k = start - 1; k >= 0 && k >= start - 3; k--) {
            String p = pickPath(lines[k]);
            if (p != null) return p;
        }
        for (int k = end + 1; k < lines.length && k <= end + 2; k++) {
            String p = pickPath(lines[k]);
            if (p != null) return p;
        }
        return null;
    }

    private static String pickPath(String line) {
        if (line == null || line.length() > 160) return null;
        Matcher m = PATHY.matcher(line);
        if (m.find()) {
            String p = Utils.normPath(m.group(1));
            if (Utils.isSafePath(p) && p.indexOf('/') >= 0 || p.indexOf('.') > 0) return p;
        }
        return null;
    }
}
