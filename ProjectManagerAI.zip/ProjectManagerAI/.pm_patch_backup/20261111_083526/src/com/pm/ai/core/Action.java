package com.pm.ai.core;

import java.util.ArrayList;
import java.util.List;

/** Una accion de ficheros devuelta por el modelo (Protocolo PM). */
public class Action {

    public static final int CREATE = 0;
    public static final int REPLACE = 1;
    public static final int EDIT = 2;
    public static final int DELETE = 3;
    public static final int RENAME = 4;
    public static final int CONTINUE = 5;
    public static final int APPEND = 6;
    public static final int UNKNOWN = 9;

    public int kind = UNKNOWN;
    public String path = "";
    public String target = "";
    public String lang = "";
    public String note = "";
    public String content = "";
    public String status = "COMPLETE";
    public List<String[]> edits = new ArrayList<String[]>();
    public boolean selected = true;
    public String result = "";

    public static int kindFrom(String s) {
        if (s == null) return UNKNOWN;
        String v = s.trim().toUpperCase();
        if (v.startsWith("CREAT") || v.equals("NEW") || v.startsWith("ADD")) return CREATE;
        if (v.startsWith("REPLAC") || v.equals("OVERWRITE") || v.equals("WRITE") || v.startsWith("REWRITE")) return REPLACE;
        if (v.startsWith("EDIT") || v.equals("MODIFY") || v.equals("PATCH") || v.startsWith("UPDATE")) return EDIT;
        if (v.startsWith("DELET") || v.equals("REMOVE")) return DELETE;
        if (v.startsWith("RENAM") || v.equals("MOVE")) return RENAME;
        if (v.startsWith("CONTINU") || v.equals("RESUME")) return CONTINUE;
        if (v.startsWith("APPEND")) return APPEND;
        return UNKNOWN;
    }

    public String kindLabel() {
        switch (kind) {
            case CREATE: return "CREAR";
            case REPLACE: return "REEMPLAZAR";
            case EDIT: return "EDITAR";
            case DELETE: return "BORRAR";
            case RENAME: return "RENOMBRAR";
            case CONTINUE: return "CONTINUAR";
            case APPEND: return "ANADIR";
            default: return "ESCRIBIR";
        }
    }

    public boolean incomplete() {
        return status != null && status.toUpperCase().indexOf("INCOMPLETE") >= 0;
    }

    public int size() {
        return content == null ? 0 : content.length();
    }

    public int lines() {
        if (content == null || content.length() == 0) return 0;
        return content.split("\n", -1).length;
    }
}
