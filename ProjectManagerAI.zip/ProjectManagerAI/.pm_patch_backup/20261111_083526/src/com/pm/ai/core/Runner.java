package com.pm.ai.core;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

import com.pm.ai.PreviewActivity;
import com.pm.ai.util.Utils;

import java.io.File;
import java.util.List;

/** Ejecuta / previsualiza proyectos segun su tipo. */
public class Runner {

    public static void run(Activity a, Project p) {
        String t = p.type == null ? Types.TEXT : p.type;
        if (Types.HTML.equals(t)) {
            String entry = htmlEntry(a, p);
            if (entry == null) {
                Utils.toast(a, "No hay index.html ni ningun .html en el proyecto");
                return;
            }
            openWeb(a, p, entry);
            return;
        }
        if (Types.ANDROID.equals(t)) {
            tryOpen(a, p, new String[]{"com.aide.ui", "com.droid.ide.ui", "com.google.android.studio"},
                    androidHelp(a, p));
            return;
        }
        if (Types.PYTHON.equals(t)) {
            tryOpen(a, p, new String[]{"ru.iiec.pydroid3", "ru.iiec.pydroid3.quick", "com.termux"}, pythonHelp(a, p));
            return;
        }
        if (Types.NODE.equals(t)) {
            tryOpen(a, p, new String[]{"com.termux", "com.nodejs.nodejs"}, nodeHelp(a, p));
            return;
        }
        if (Types.CPP.equals(t)) {
            tryOpen(a, p, new String[]{"com.termux"}, cppHelp(a, p));
            return;
        }
        if (Types.JAVA.equals(t)) {
            tryOpen(a, p, new String[]{"com.aide.ui", "com.termux"}, javaHelp(a, p));
            return;
        }
        openText(a, p, firstFile(a, p));
    }

    public static void runFile(Activity a, Project p, String rel) {
        if (rel == null || rel.length() == 0) {
            run(a, p);
            return;
        }
        String e = Utils.ext(rel);
        if (e.equals("html") || e.equals("htm")) {
            openWeb(a, p, rel);
            return;
        }
        openText(a, p, rel);
    }

    private static String htmlEntry(Activity a, Project p) {
        Storage st = Storage.get(a);
        if (st.file(p, "index.html").isFile()) return "index.html";
        List<String> fs = st.files(p);
        for (int i = 0; i < fs.size(); i++) {
            String e = Utils.ext(fs.get(i));
            if (e.equals("html") || e.equals("htm")) return fs.get(i);
        }
        return null;
    }

    private static String firstFile(Activity a, Project p) {
        Storage st = Storage.get(a);
        if (st.file(p, "README.md").isFile()) return "README.md";
        List<String> fs = st.files(p);
        return fs.size() > 0 ? fs.get(0) : "README.md";
    }

    public static void openWeb(Activity a, Project p, String rel) {
        Intent i = new Intent(a, PreviewActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("path", rel);
        i.putExtra("mode", "web");
        a.startActivity(i);
    }

    public static void openText(Activity a, Project p, String rel) {
        Intent i = new Intent(a, PreviewActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("path", rel);
        i.putExtra("mode", "text");
        a.startActivity(i);
    }

    private static void tryOpen(final Activity a, final Project p, String[] pkgs, final String help) {
        for (int i = 0; i < pkgs.length; i++) {
            if (Utils.hasApp(a, pkgs[i])) {
                Utils.launchApp(a, pkgs[i]);
                Utils.toastLong(a, "Abriendo " + pkgs[i] + ". Carpeta del proyecto:\n" + p.dir.getAbsolutePath());
                Utils.copy(a, "ruta", p.dir.getAbsolutePath());
                return;
            }
        }
        new AlertDialog.Builder(a)
                .setTitle("Como ejecutar este proyecto")
                .setMessage(help + "\n\nRuta del proyecto (copiada al portapapeles):\n" + p.dir.getAbsolutePath())
                .setPositiveButton("Exportar ZIP", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        File z = Storage.get(a).exportZip(p);
                        if (z == null) {
                            Utils.toast(a, "No se pudo crear el ZIP");
                        } else {
                            Utils.copy(a, "ruta", z.getAbsolutePath());
                            new AlertDialog.Builder(a)
                                    .setTitle("ZIP creado")
                                    .setMessage(z.getAbsolutePath() + "\n\nQuieres compartirlo?")
                                    .setPositiveButton("Compartir", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface d2, int w2) {
                                            Utils.shareFile(a, Storage.get(a).exportZip(p));
                                        }
                                    })
                                    .setNegativeButton("Cerrar", null)
                                    .show();
                        }
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
        Utils.copy(a, "ruta", p.dir.getAbsolutePath());
    }

    private static String androidHelp(Activity a, Project p) {
        return "Proyecto Android para AIDE.\n\n"
                + "1) Instala AIDE (o AIDE Web) desde la tienda.\n"
                + "2) Exporta el ZIP desde Project Manager AI.\n"
                + "3) Descomprimelo y abre la carpeta en AIDE (Project -> Open).\n"
                + "4) Pulsa Run para compilar el APK.\n\n"
                + "Requisitos del proyecto: Java clasico, minSdk 21, targetSdk 28, sin AndroidX.\n"
                + Types.runHint(Types.ANDROID);
    }

    private static String pythonHelp(Activity a, Project p) {
        return "Proyecto Python.\n\n"
                + "1) Instala Pydroid 3 (o Termux).\n"
                + "2) Abre main.py desde la ruta del proyecto.\n"
                + "3) Pulsa Run.\n\n"
                + "En Termux: cd " + p.dir.getAbsolutePath() + " && python3 main.py";
    }

    private static String nodeHelp(Activity a, Project p) {
        return "Proyecto Node.js.\n\nEn Termux:\n  pkg install nodejs\n  cd "
                + p.dir.getAbsolutePath() + "\n  npm install\n  node index.js";
    }

    private static String cppHelp(Activity a, Project p) {
        return "Proyecto C/C++.\n\nEn Termux:\n  pkg install clang make\n  cd "
                + p.dir.getAbsolutePath() + "\n  make && ./app";
    }

    private static String javaHelp(Activity a, Project p) {
        return "Proyecto Java de consola.\n\nEn Termux:\n  pkg install openjdk-17\n  cd "
                + p.dir.getAbsolutePath() + "\n  javac -d bin src/Main.java\n  java -cp bin Main";
    }
}
