package com.pm.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.pm.ai.core.PendingManager;
import com.pm.ai.core.Prefs;
import com.pm.ai.core.Project;
import com.pm.ai.core.PromptBuilder;
import com.pm.ai.core.Storage;
import com.pm.ai.util.Utils;

import java.util.ArrayList;
import java.util.List;

public class PromptActivity extends Activity {

    private Storage store;
    private Project p;
    private String mode = PromptBuilder.MODE_CREATE;

    private ScrollView paneConfig;
    private LinearLayout paneResult;
    private TextView tabConfig;
    private TextView tabResult;
    private TextView chipCreate;
    private TextView chipUpdate;
    private TextView chipFix;
    private TextView chipContinue;
    private EditText etTask;
    private EditText etPrompt;
    private EditText etModel;
    private Spinner spLang;
    private SeekBar sbLimit;
    private TextView tvLimit;
    private TextView tvPicked;
    private TextView tvInfo;
    private CheckBox cbTree;
    private CheckBox cbContents;
    private CheckBox cbSpec;

    private List<String> picked = new ArrayList<String>();
    private boolean editable = false;
    private android.text.method.KeyListener origKey;
    private final String[] langs = {"Espanol", "English", "Portugues", "Frances"};

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_prompt);
        store = Storage.get(this);
        p = store.open(getIntent().getStringExtra("project"));

        paneConfig = (ScrollView) findViewById(R.id.paneConfig);
        paneResult = (LinearLayout) findViewById(R.id.paneResult);
        tabConfig = (TextView) findViewById(R.id.tabConfig);
        tabResult = (TextView) findViewById(R.id.tabResult);
        chipCreate = (TextView) findViewById(R.id.chipCreate);
        chipUpdate = (TextView) findViewById(R.id.chipUpdate);
        chipFix = (TextView) findViewById(R.id.chipFix);
        chipContinue = (TextView) findViewById(R.id.chipContinue);
        etTask = (EditText) findViewById(R.id.etTask);
        etPrompt = (EditText) findViewById(R.id.etPrompt);
        etModel = (EditText) findViewById(R.id.etModel);
        spLang = (Spinner) findViewById(R.id.spLang);
        sbLimit = (SeekBar) findViewById(R.id.sbLimit);
        tvLimit = (TextView) findViewById(R.id.tvLimit);
        tvPicked = (TextView) findViewById(R.id.tvPicked);
        tvInfo = (TextView) findViewById(R.id.tvPromptInfo);
        cbTree = (CheckBox) findViewById(R.id.cbTree);
        cbContents = (CheckBox) findViewById(R.id.cbContents);
        cbSpec = (CheckBox) findViewById(R.id.cbSpec);

        ((TextView) findViewById(R.id.tvSub)).setText(p.name + " | " + p.typeLabel());
        origKey = etPrompt.getKeyListener();
        etPrompt.setKeyListener(null);
        etPrompt.setTextIsSelectable(true);

        etModel.setText(p.model == null || p.model.length() == 0 ? Prefs.model(this) : p.model);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, langs);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        spLang.setAdapter(ad);
        for (int i = 0; i < langs.length; i++) {
            if (langs[i].equals(p.docsLang)) {
                spLang.setSelection(i);
                break;
            }
        }
        int lim = Prefs.limit(this);
        sbLimit.setProgress(Math.max(1, lim / 500));
        tvLimit.setText(lim + " caracteres por archivo");
        sbLimit.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int progress, boolean user) {
                int v = Math.max(1, progress) * 500;
                tvLimit.setText(v + " caracteres por archivo");
            }

            public void onStartTrackingTouch(SeekBar sb) {
            }

            public void onStopTrackingTouch(SeekBar sb) {
            }
        });

        etTask.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                ((TextView) findViewById(R.id.tvTaskCount)).setText(e.length() + " caracteres");
            }
        });

        String task = getIntent().getStringExtra("task");
        if (task != null) etTask.setText(task);
        String pk = getIntent().getStringExtra("picked");
        if (pk != null && pk.trim().length() > 0) {
            picked = Utils.splitLines(pk);
            updatePicked();
            cbContents.setChecked(true);
        }
        String m = getIntent().getStringExtra("mode");
        if (m != null) setMode(m);
        String path = getIntent().getStringExtra("path");
        if (path != null && path.length() > 0) {
            setMode(PromptBuilder.MODE_CONTINUE);
            List<String> one = new ArrayList<String>();
            one.add(path);
            picked = one;
            updatePicked();
        }

        tabConfig.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(true);
            }
        });
        tabResult.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(false);
            }
        });
        chipCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_CREATE);
            }
        });
        chipUpdate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_UPDATE);
            }
        });
        chipFix.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_FIX);
            }
        });
        chipContinue.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_CONTINUE);
            }
        });
        findViewById(R.id.btnPick).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pickFiles();
            }
        });
        findViewById(R.id.btnGenerate).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                generate();
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.btnHelp).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showHelp();
            }
        });
        findViewById(R.id.btnCopy).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Utils.copy(PromptActivity.this, "prompt", etPrompt.getText().toString());
            }
        });
        findViewById(R.id.btnOpenQwen).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Utils.copy(PromptActivity.this, "prompt", etPrompt.getText().toString());
                Utils.openUrl(PromptActivity.this, "https://chat.qwen.ai/");
            }
        });
        findViewById(R.id.btnToApply).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(PromptActivity.this, ApplyActivity.class);
                i.putExtra("project", p.name);
                startActivity(i);
            }
        });
        findViewById(R.id.btnEditToggle).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editable = !editable;
                if (editable) {
                    etPrompt.setTextIsSelectable(false);
                    etPrompt.setKeyListener(origKey);
                } else {
                    etPrompt.setKeyListener(null);
                    etPrompt.setTextIsSelectable(true);
                }
                etPrompt.setFocusable(editable);
                etPrompt.setFocusableInTouchMode(editable);
                ((TextView) findViewById(R.id.btnEditToggle)).setText("Editable: " + (editable ? "ON" : "OFF"));
            }
        });

        updateChips();
        showPane(true);
    }

    private void setMode(String m) {
        mode = m;
        updateChips();
        if (PromptBuilder.MODE_CONTINUE.equals(m)) {
            List<String> pend = PendingManager.paths(p);
            if (pend.size() > 0) {
                picked = pend;
                updatePicked();
            }
        }
    }

    private void updateChips() {
        chipCreate.setSelected(PromptBuilder.MODE_CREATE.equals(mode));
        chipUpdate.setSelected(PromptBuilder.MODE_UPDATE.equals(mode));
        chipFix.setSelected(PromptBuilder.MODE_FIX.equals(mode));
        chipContinue.setSelected(PromptBuilder.MODE_CONTINUE.equals(mode));
        String hint;
        if (PromptBuilder.MODE_FIX.equals(mode)) hint = "Pega aqui el error completo (log de AIDE, consola, traceback...).";
        else if (PromptBuilder.MODE_UPDATE.equals(mode)) hint = "Describe el cambio o la nueva funcionalidad que quieres anadir.";
        else if (PromptBuilder.MODE_CONTINUE.equals(mode)) hint = "Elige el archivo cortado en 'Elegir archivos'. Se enviara su cola para continuar.";
        else hint = "Describe el proyecto completo: pantallas, funciones, datos, estilo y restricciones.";
        etTask.setHint(hint);
    }

    private void showPane(boolean config) {
        paneConfig.setVisibility(config ? View.VISIBLE : View.GONE);
        paneResult.setVisibility(config ? View.GONE : View.VISIBLE);
        tabConfig.setSelected(config);
        tabResult.setSelected(!config);
    }

    private void updatePicked() {
        if (picked.size() == 0) tvPicked.setText("Ninguno seleccionado");
        else if (picked.size() <= 3) tvPicked.setText(Utils.join(picked, ", "));
        else tvPicked.setText(picked.size() + " archivos: " + Utils.join(picked.subList(0, 3), ", ") + " ...");
    }

    private void pickFiles() {
        final List<String> files = store.files(p);
        if (files.size() == 0) {
            Utils.toast(this, "El proyecto no tiene archivos");
            return;
        }
        final String[] arr = files.toArray(new String[files.size()]);
        final boolean[] checks = new boolean[arr.length];
        for (int i = 0; i < arr.length; i++) checks[i] = picked.contains(arr[i]);
        new AlertDialog.Builder(this)
                .setTitle("Archivos de contexto")
                .setMultiChoiceItems(arr, checks, new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checks[which] = isChecked;
                    }
                })
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        picked.clear();
                        for (int i = 0; i < arr.length; i++) if (checks[i]) picked.add(arr[i]);
                        updatePicked();
                    }
                })
                .setNeutralButton("Todos", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        picked = new ArrayList<String>(files);
                        updatePicked();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void generate() {
        p.model = etModel.getText().toString().trim();
        int pos = spLang.getSelectedItemPosition();
        p.docsLang = pos < 0 ? "Espanol" : langs[pos];
        store.save(p);
        Prefs.setNum(this, "limit", Math.max(1, sbLimit.getProgress()) * 500);

        String task = etTask.getText().toString();
        int limit = Math.max(1, sbLimit.getProgress()) * 500;
        String prompt;

        if (PromptBuilder.MODE_CONTINUE.equals(mode)) {
            String path = picked.size() > 0 ? picked.get(0) : null;
            if (path == null) {
                List<String> pend = PendingManager.paths(p);
                if (pend.size() == 0) {
                    Utils.toast(this, "No hay archivos cortados. Pega primero la respuesta incompleta en Aplicar.");
                    return;
                }
                path = pend.get(0);
            }
            prompt = PromptBuilder.continuePrompt(store, p, path);
        } else if (PromptBuilder.MODE_FIX.equals(mode)) {
            String full = "[ERROR REPORTADO]\n" + task + "\n\n"
                    + "Diagnostica la causa raiz y entrega SOLO los cambios necesarios "
                    + "(EDIT sobre los archivos existentes o CREATE si falta alguno).";
            prompt = PromptBuilder.build(store, p, PromptBuilder.MODE_FIX, full,
                    cbSpec.isChecked(), cbTree.isChecked(), cbContents.isChecked(), picked, limit);
        } else {
            prompt = PromptBuilder.build(store, p, mode, task,
                    cbSpec.isChecked(), cbTree.isChecked(), cbContents.isChecked(), picked, limit);
        }

        etPrompt.setText(prompt);
        tvInfo.setText(prompt.length() + " caracteres | ~" + (prompt.length() / 4) + " tokens");
        store.savePrompt(p, prompt);
        showPane(false);
        Utils.toast(this, "Prompt generado y guardado en .pm/prompts");
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Como funciona")
                .setMessage("1) Rellena la ficha del proyecto y pulsa GENERAR.\n"
                        + "2) Copia el prompt y pegalo en Qwen3-Max (boton Abrir Qwen).\n"
                        + "3) Qwen NO crea archivos: responde con marcadores @@PM_... indicando la ruta\n"
                        + "   exacta de cada archivo y su contenido completo, en orden.\n"
                        + "4) Copia TODA la respuesta y pegala en APLICAR: la app crea, reemplaza,\n"
                        + "   edita (FIND/REPLACE), borra y renombra archivos con backup.\n"
                        + "5) Si la respuesta se corta, la app guarda el archivo parcial y genera el\n"
                        + "   prompt CONTINUAR para retomarlo exactamente donde se quedo.\n\n"
                        + "Modo CORREGIR: pega el error y la app genera el prompt de arreglo.\n"
                        + "Los prompts quedan guardados en .pm/prompts y las respuestas en .pm/responses.")
                .setPositiveButton(R.string.act_ok, null)
                .show();
    }
}
