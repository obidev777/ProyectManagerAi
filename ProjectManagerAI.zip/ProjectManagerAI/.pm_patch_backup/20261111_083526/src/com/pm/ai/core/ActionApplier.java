package com.pm.ai.core;

import com.pm.ai.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Ejecuta sobre disco las acciones devueltas por el modelo, con backup. */
public class ActionApplier {

    public static class Report {
        public List<String> log = new ArrayList<String>();
        public int ok = 0;
        public int fail = 0;
        public int skipped = 0;
        public int partial = 0;
        public String backupPath = "";

        public String text() {
            return Utils.join(log, "\n");
        }
    }

    public static Report apply(Storage st, Project p, List<Action> actions, boolean backup) {
        Report rep = new Report();
        File bdir = backup ? new File(p.pm(), "backups/" + Utils.stamp()) : null;
        rep.log.add("=== Aplicado " + Utils.dateLong(System.currentTimeMillis()) + " ===");

        for (int i = 0; i < actions.size(); i++) {
            Action a = actions.get(i);
            if (!a.selected) {
                rep.skipped++;
                continue;
            }
            String rel = Utils.normPath(a.path);
            if (!Utils.isSafePath(rel)) {
                a.result = "ruta no valida";
                rep.fail++;
                rep.log.add("[FALLO] ruta no valida: " + a.path);
                continue;
            }
            File f = st.file(p, rel);
            try {
                if (a.kind == Action.DELETE) {
                    if (!f.exists()) {
                        rep.log.add("[SKIP]  " + rel + " (no existe)");
                        rep.skipped++;
                    } else {
                        backupFile(p, bdir, rel, f);
                        boolean d = f.isFile() ? f.delete() : Utils.deleteRecursive(f);
                        if (d) {
                            rep.ok++;
                            a.result = "borrado";
                            rep.log.add("[BORRA] " + rel);
                        } else {
                            rep.fail++;
                            a.result = "no se pudo borrar";
                            rep.log.add("[FALLO] no se pudo borrar " + rel);
                        }
                    }
                } else if (a.kind == Action.RENAME) {
                    String to = Utils.normPath(a.target);
                    if (!Utils.isSafePath(to) || !f.exists()) {
                        rep.fail++;
                        rep.log.add("[FALLO] renombrado invalido: " + rel + " -> " + a.target);
                    } else {
                        File dst = st.file(p, to);
                        File pd = dst.getParentFile();
                        if (pd != null && !pd.exists()) pd.mkdirs();
                        if (f.renameTo(dst)) {
                            rep.ok++;
                            a.result = "renombrado";
                            rep.log.add("[MOVE]  " + rel + " -> " + to);
                        } else {
                            rep.fail++;
                            rep.log.add("[FALLO] no se pudo mover " + rel);
                        }
                    }
                } else if (a.kind == Action.EDIT) {
                    if (!f.isFile()) {
                        rep.fail++;
                        a.result = "el archivo no existe";
                        rep.log.add("[FALLO] EDIT sobre archivo inexistente: " + rel);
                    } else {
                        String src = Utils.readText(f);
                        StringBuilder detail = new StringBuilder();
                        String out = applyEdits(src, a.edits, detail);
                        backupFile(p, bdir, rel, f);
                        if (Utils.writeText(f, out)) {
                            rep.ok++;
                            a.result = a.edits.size() + " ediciones";
                            rep.log.add("[EDITA] " + rel + "\n" + detail.toString());
                        } else {
                            rep.fail++;
                            rep.log.add("[FALLO] no se pudo escribir " + rel);
                        }
                    }
                } else if (a.kind == Action.CONTINUE || a.kind == Action.APPEND) {
                    String prev = PendingManager.get(p, rel);
                    if (prev == null) prev = f.isFile() ? Utils.readText(f) : "";
                    String merged = prev + (a.content == null ? "" : a.content);
                    if (a.incomplete()) {
                        PendingManager.put(p, rel, merged, a.lang);
                        rep.partial++;
                        a.result = "parcial " + merged.length() + " chars";
                        rep.log.add("[PARC]  " + rel + " incompleto (" + merged.length() + " chars guardados). Usa CONTINUAR.");
                    } else {
                        if (f.isFile()) backupFile(p, bdir, rel, f);
                        if (Utils.writeText(f, merged)) {
                            PendingManager.remove(p, rel);
                            rep.ok++;
                            a.result = "continuado (" + merged.length() + " chars)";
                            rep.log.add("[CONT]  " + rel + " completado (" + merged.length() + " chars)");
                        } else {
                            rep.fail++;
                            rep.log.add("[FALLO] no se pudo escribir " + rel);
                        }
                    }
                } else {
                    String content = a.content == null ? "" : a.content;
                    if (content.length() == 0) {
                        rep.fail++;
                        a.result = "sin contenido";
                        rep.log.add("[FALLO] bloque sin contenido: " + rel);
                        continue;
                    }
                    if (a.incomplete()) {
                        PendingManager.put(p, rel, content, a.lang);
                        rep.partial++;
                        a.result = "parcial " + content.length() + " chars";
                        rep.log.add("[PARC]  " + rel + " incompleto (" + content.length() + " chars). Usa CONTINUAR.");
                        continue;
                    }
                    if (f.isFile()) backupFile(p, bdir, rel, f);
                    if (Utils.writeText(f, content)) {
                        PendingManager.remove(p, rel);
                        rep.ok++;
                        a.result = (f.exists() ? "escrito " : "creado ") + content.length() + " chars";
                        rep.log.add((a.kind == Action.REPLACE ? "[REEMP] " : "[CREA]  ") + rel
                                + " (" + content.length() + " chars, " + a.lines() + " lineas)");
                    } else {
                        rep.fail++;
                        a.result = "error de escritura";
                        rep.log.add("[FALLO] no se pudo escribir " + rel);
                    }
                }
            } catch (Throwable e) {
                rep.fail++;
                rep.log.add("[ERROR] " + rel + " : " + e.getClass().getSimpleName() + " " + e.getMessage());
            }
        }

        if (bdir != null && bdir.exists() && rep.ok > 0) {
            rep.backupPath = bdir.getAbsolutePath();
            rep.log.add("Backup: " + rep.backupPath);
        }
        rep.log.add("Resumen: " + rep.ok + " ok, " + rep.fail + " fallos, "
                + rep.partial + " parciales, " + rep.skipped + " omitidos");
        st.touch(p);
        st.save(p);
        return rep;
    }

    private static void backupFile(Project p, File bdir, String rel, File f) {
        if (bdir == null || f == null || !f.isFile()) return;
        Utils.copyFile(f, new File(bdir, rel));
    }

    private static String applyEdits(String src, List<String[]> edits, StringBuilder log) {
        String text = src == null ? "" : src.replace("\r\n", "\n");
        if (edits == null) return text;
        for (int i = 0; i < edits.size(); i++) {
            String find = edits.get(i)[0] == null ? "" : edits.get(i)[0].replace("\r\n", "\n");
            String repl = edits.get(i)[1] == null ? "" : edits.get(i)[1].replace("\r\n", "\n");
            if (find.trim().length() == 0) {
                log.append("    ! bloque FIND vacio\n");
                continue;
            }
            if (text.indexOf(find) >= 0) {
                int n = Utils.countOccurrences(text, find);
                text = text.replace(find, repl);
                log.append("    ok reemplazo exacto x").append(n).append("\n");
                continue;
            }
            String tf = find.trim();
            if (text.trim().equals(tf)) {
                text = repl;
                log.append("    ok archivo reemplazado completo\n");
                continue;
            }
            int[] range = fuzzyRange(text, tf);
            if (range != null) {
                List<String> ls = toLines(text);
                List<String> rl = toLines(repl);
                List<String> out = new ArrayList<String>();
                for (int k = 0; k < range[0] && k < ls.size(); k++) out.add(ls.get(k));
                for (int k = 0; k < rl.size(); k++) out.add(rl.get(k));
                for (int k = range[1] + 1; k < ls.size(); k++) out.add(ls.get(k));
                text = Utils.join(out, "\n");
                log.append("    ok reemplazo tolerante (lineas ").append(range[0] + 1)
                        .append("-").append(range[1] + 1).append(")\n");
                continue;
            }
            log.append("    ! FIND no localizado (usa texto literal del archivo actual)\n");
        }
        return text;
    }

    private static int[] fuzzyRange(String text, String find) {
        List<String> tl = toLines(text);
        List<String> fl = toLines(find);
        while (fl.size() > 0 && fl.get(0).trim().length() == 0) fl.remove(0);
        while (fl.size() > 0 && fl.get(fl.size() - 1).trim().length() == 0) fl.remove(fl.size() - 1);
        if (fl.size() == 0) return null;
        for (int i = 0; i + fl.size() <= tl.size(); i++) {
            boolean ok = true;
            for (int j = 0; j < fl.size(); j++) {
                if (!tl.get(i + j).trim().equals(fl.get(j).trim())) {
                    ok = false;
                    break;
                }
            }
            if (ok) return new int[]{i, i + fl.size() - 1};
        }
        return null;
    }

    private static List<String> toLines(String s) {
        List<String> l = new ArrayList<String>();
        String[] a = s.split("\n", -1);
        for (int i = 0; i < a.length; i++) l.add(a[i]);
        return l;
    }
}
