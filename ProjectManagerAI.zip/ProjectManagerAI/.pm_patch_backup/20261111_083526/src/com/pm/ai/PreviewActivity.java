package com.pm.ai;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.pm.ai.core.Project;
import com.pm.ai.core.Runner;
import com.pm.ai.core.Storage;
import com.pm.ai.core.Types;
import com.pm.ai.util.Utils;

import java.io.File;

public class PreviewActivity extends Activity {

    private Storage store;
    private Project p;
    private String path;
    private String mode;
    private WebView web;
    private TextView tvText;
    private TextView tvConsole;
    private TextView tvUrl;
    private LinearLayout llConsole;
    private ScrollView scrollText;
    private ScrollView scrollConsole;
    private boolean consoleVisible = true;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_preview);
        store = Storage.get(this);
        p = store.open(getIntent().getStringExtra("project"));
        path = Utils.normPath(getIntent().getStringExtra("path"));
        mode = getIntent().getStringExtra("mode");
        if (mode == null) mode = "text";

        web = (WebView) findViewById(R.id.web);
        tvText = (TextView) findViewById(R.id.tvText);
        tvConsole = (TextView) findViewById(R.id.tvConsole);
        tvUrl = (TextView) findViewById(R.id.tvUrl);
        llConsole = (LinearLayout) findViewById(R.id.llConsole);
        scrollText = (ScrollView) findViewById(R.id.scrollText);
        scrollConsole = (ScrollView) findViewById(R.id.scrollConsole);

        ((TextView) findViewById(R.id.tvTitle)).setText(p.name + " - " + Utils.baseName(path));

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                load();
            }
        });
        findViewById(R.id.btnExternal).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                external();
            }
        });
        findViewById(R.id.btnClearConsole).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tvConsole.setText("");
            }
        });
        findViewById(R.id.btnToggleConsole).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                consoleVisible = !consoleVisible;
                scrollConsole.setVisibility(consoleVisible ? View.VISIBLE : View.GONE);
                ((TextView) v).setText(consoleVisible ? "ocultar" : "mostrar");
            }
        });

        load();
    }

    private void load() {
        File f = store.file(p, path);
        if (!f.isFile()) {
            web.setVisibility(View.GONE);
            scrollText.setVisibility(View.VISIBLE);
            tvText.setText("No existe el archivo: " + path
                    + "\n\nRuta esperada:\n" + f.getAbsolutePath()
                    + "\n\nTipo de proyecto: " + Types.label(p.type)
                    + "\n" + Types.runHint(p.type));
            tvUrl.setText(f.getAbsolutePath());
            return;
        }
        String ext = Utils.ext(path);
        if ("web".equals(mode) || ext.equals("html") || ext.equals("htm")) {
            setupWeb();
            web.setVisibility(View.VISIBLE);
            scrollText.setVisibility(View.GONE);
            llConsole.setVisibility(View.VISIBLE);
            tvUrl.setText("file://" + f.getAbsolutePath());
            web.loadUrl("file://" + f.getAbsolutePath());
            appendConsole("Cargando file://" + f.getAbsolutePath());
        } else {
            web.setVisibility(View.GONE);
            scrollText.setVisibility(View.VISIBLE);
            llConsole.setVisibility(View.GONE);
            String content = Utils.readText(f);
            StringBuilder sb = new StringBuilder();
            sb.append("== ").append(path).append(" ==\n");
            sb.append(Utils.humanSize(f.length())).append(" | ").append(Utils.dateLong(f.lastModified())).append("\n\n");
            sb.append(content);
            sb.append("\n\n----------------------------------------\n");
            sb.append("COMO EJECUTAR ESTE PROYECTO\n");
            sb.append(Types.runHint(p.type)).append("\n\n");
            sb.append("Ruta del proyecto:\n").append(p.dir.getAbsolutePath()).append("\n");
            tvText.setText(sb.toString());
            tvUrl.setText(f.getAbsolutePath());
        }
    }

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        try {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        } catch (Throwable t) {
            // ignorado
        }
        web.setBackgroundColor(0xFF0A0E1C);
        web.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("file://")) return false;
                Utils.openUrl(PreviewActivity.this, url);
                return true;
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                appendConsole("[ERROR " + errorCode + "] " + description + "  " + failingUrl);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            public boolean onConsoleMessage(ConsoleMessage cm) {
                appendConsole("[" + cm.messageLevel() + "] " + cm.message()
                        + "  (" + cm.sourceId() + ":" + cm.lineNumber() + ")");
                return true;
            }
        });
    }

    private void appendConsole(final String line) {
        runOnUiThread(new Runnable() {
            public void run() {
                llConsole.setVisibility(View.VISIBLE);
                String cur = tvConsole.getText().toString();
                if (cur.length() > 12000) cur = cur.substring(cur.length() - 8000);
                tvConsole.setText(cur + line + "\n");
                scrollConsole.post(new Runnable() {
                    public void run() {
                        scrollConsole.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    private void external() {
        File f = store.file(p, path);
        if (!f.isFile()) {
            Utils.toast(this, "Archivo no encontrado");
            return;
        }
        String ext = Utils.ext(path);
        if (ext.equals("html") || ext.equals("htm")) {
            try {
                Utils.allowFileUri();
                android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW);
                i.setDataAndType(android.net.Uri.fromFile(f), "text/html");
                i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(android.content.Intent.createChooser(i, "Abrir con"));
                return;
            } catch (Throwable t) {
                // se intenta compartir
            }
        }
        Utils.shareFile(this, f);
    }

    public void onBackPressed() {
        if (web != null && web.getVisibility() == View.VISIBLE && web.canGoBack()) {
            web.goBack();
            return;
        }
        super.onBackPressed();
    }

    protected void onPause() {
        super.onPause();
        try {
            if (web != null) web.onPause();
        } catch (Throwable t) {
            // ignorado
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (web != null) web.onResume();
        } catch (Throwable t) {
            // ignorado
        }
    }
}
