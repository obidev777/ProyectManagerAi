package com.pm.ai.core;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferencias globales. */
public class Prefs {

    private static final String NAME = "pm_ai_prefs";

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static String str(Context c, String k, String d) {
        return sp(c).getString(k, d);
    }

    public static void setStr(Context c, String k, String v) {
        sp(c).edit().putString(k, v).apply();
    }

    public static boolean bool(Context c, String k, boolean d) {
        return sp(c).getBoolean(k, d);
    }

    public static void setBool(Context c, String k, boolean v) {
        sp(c).edit().putBoolean(k, v).apply();
    }

    public static int num(Context c, String k, int d) {
        return sp(c).getInt(k, d);
    }

    public static void setNum(Context c, String k, int v) {
        sp(c).edit().putInt(k, v).apply();
    }

    public static String model(Context c) {
        return str(c, "model", "Qwen3-Max");
    }

    public static String docsLang(Context c) {
        return str(c, "docsLang", "Espanol");
    }

    public static boolean backup(Context c) {
        return bool(c, "backup", true);
    }

    public static boolean highlight(Context c) {
        return bool(c, "highlight", true);
    }

    public static boolean gutter(Context c) {
        return bool(c, "gutter", true);
    }

    public static int limit(Context c) {
        return num(c, "limit", 4000);
    }
}
