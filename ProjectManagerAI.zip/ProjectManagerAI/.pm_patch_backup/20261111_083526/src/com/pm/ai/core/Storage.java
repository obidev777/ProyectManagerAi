package com.pm.ai.core;

import android.content.Context;

import com.pm.ai.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Gestiona la carpeta raiz y el ciclo de vida de los proyectos. */
public class Storage {

    private static Storage INSTANCE;

    private final Context ctx;
    private final File root;

    private Storage(Context c) {
        this.ctx = c.getApplicationContext();
        File base = null;
        try {
            base = ctx.getExternalFilesDir(null);
        } catch (Exception e) {
            base = null;
        }
        if (base == null) base = ctx.getFilesDir();
        root = new File(base, "PM_Projects");
        if (!root.exists()) root.mkdirs();
    }

    public static synchronized Storage get(Context c) {
        if (INSTANCE == null) INSTANCE = new Storage(c);
        return INSTANCE;
    }

    public Context context() {
        return ctx;
    }

    public File getRoot() {
        return root;
    }

    public String rootPath() {
        return root.getAbsolutePath();
    }

    public File dirOf(String name) {
        return new File(root, name);
    }

    public List<Project> list() {
        List<Project> out = new ArrayList<Project>();
        File[] kids = root.listFiles();
        if (kids == null) return out;
        Arrays.sort(kids, new Comparator<File>() {
            public int compare(File a, File b) {
                long la = a.lastModified();
                long lb = b.lastModified();
                if (la < lb) return 1;
                if (la > lb) return -1;
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (int i = 0; i < kids.length; i++) {
            File d = kids[i];
            if (!d.isDirectory()) continue;
            if (d.getName().startsWith(".")) continue;
            out.add(open(d.getName()));
        }
        return out;
    }

    public Project open(String name) {
        File d = dirOf(name);
        File meta = new File(new File(d, ".pm"), "project.json");
        Project p;
        if (meta.isFile()) {
            p = Project.fromJson(Utils.readText(meta), d);
            p.dir = d;
        } else {
            p = new Project(d);
            p.name = d.getName();
            p.type = guessType(d);
            p.created = d.lastModified();
            p.updated = d.lastModified();
            p.model = Prefs.model(ctx);
            p.docsLang = Prefs.docsLang(ctx);
        }
        return p;
    }

    private String guessType(File d) {
        if (new File(d, "AndroidManifest.xml").isFile()) return Types.ANDROID;
        if (new File(d, "index.html").isFile()) return Types.HTML;
        if (new File(d, "package.json").isFile()) return Types.NODE;
        if (new File(d, "main.py").isFile()) return Types.PYTHON;
        if (new File(d, "requirements.txt").isFile()) return Types.PYTHON;
        if (new File(d, "main.cpp").isFile() || new File(d, "Makefile").isFile()) return Types.CPP;
        return Types.TEXT;
    }

    public void save(Project p) {
        if (p == null || p.dir == null) return;
        p.updated = System.currentTimeMillis();
        Utils.writeText(p.metaFile(), p.toJson().toString());
        p.dir.setLastModified(p.updated);
    }

    public String freeName(String base) {
        String n = Utils.safeName(base);
        if (!dirOf(n).exists()) return n;
        int i = 2;
        while (dirOf(n + "-" + i).exists()) i++;
        return n + "-" + i;
    }

    public Project create(String name, String type, String desc, String feat, boolean withTemplate) {
        String n = freeName(name);
        File d = dirOf(n);
        d.mkdirs();
        Project p = new Project(d);
        p.name = n;
        p.type = type == null ? Types.TEXT : type;
        p.description = desc == null ? "" : desc;
        p.features = feat == null ? "" : feat;
        p.model = Prefs.model(ctx);
        p.docsLang = Prefs.docsLang(ctx);
        p.created = System.currentTimeMillis();
        p.updated = p.created;
        new File(d, ".pm").mkdirs();
        if (withTemplate) {
            String[][] t = ProjectTemplates.files(p, n);
            for (int i = 0; i < t.length; i++) {
                Utils.writeText(new File(d, t[i][0]), t[i][1]);
            }
        }
        save(p);
        return p;
    }

    public boolean delete(String name) {
        return Utils.deleteRecursive(dirOf(name));
    }

    public String rename(String oldName, String newName) {
        String n = Utils.safeName(newName);
        if (n.length() == 0) return null;
        File from = dirOf(oldName);
        File to = dirOf(n);
        if (to.exists() || !from.exists()) return null;
        if (!from.renameTo(to)) return null;
        Project p = open(n);
        p.name = n;
        save(p);
        return n;
    }

    public Project duplicate(String name) {
        Project src = open(name);
        String n = freeName(name + "-copia");
        File to = dirOf(n);
        if (!copyDir(src.dir, to)) return null;
        File oldMeta = new File(new File(to, ".pm"), "project.json");
        if (oldMeta.exists()) oldMeta.delete();
        Project p = open(n);
        p.name = n;
        p.created = System.currentTimeMillis();
        save(p);
        return p;
    }

    private boolean copyDir(File src, File dst) {
        if (!src.exists()) return false;
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) return false;
            File[] kids = src.listFiles();
            if (kids == null) return true;
            for (int i = 0; i < kids.length; i++) {
                if (!copyDir(kids[i], new File(dst, kids[i].getName()))) return false;
            }
            return true;
        }
        return Utils.copyFile(src, dst);
    }

    public File file(Project p, String rel) {
        return new File(p.dir, Utils.normPath(rel));
    }

    public String read(Project p, String rel) {
        return Utils.readText(file(p, rel));
    }

    public boolean write(Project p, String rel, String content) {
        boolean ok = Utils.writeText(file(p, rel), content);
        if (ok) touch(p);
        return ok;
    }

    public void touch(Project p) {
        p.updated = System.currentTimeMillis();
        if (p.dir != null) p.dir.setLastModified(p.updated);
    }

    public List<String> files(Project p) {
        List<String> out = new ArrayList<String>();
        walk(p.dir, "", out, false);
        Collections.sort(out);
        return out;
    }

    public List<String> tree(Project p) {
        List<String> out = new ArrayList<String>();
        walk(p.dir, "", out, true);
        Collections.sort(out);
        return out;
    }

    private void walk(File dir, String prefix, List<String> out, boolean dirs) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (int i = 0; i < kids.length; i++) {
            File f = kids[i];
            String n = f.getName();
            if (n.equals(".pm")) continue;
            String rel = prefix.length() == 0 ? n : prefix + "/" + n;
            if (f.isDirectory()) {
                if (dirs) out.add(rel + "/");
                walk(f, rel, out, dirs);
            } else {
                out.add(rel);
            }
        }
    }

    public int countFiles(Project p) {
        return files(p).size();
    }

    public File exportZip(Project p) {
        File dir = Utils.exportDir(ctx);
        if (!dir.exists()) dir.mkdirs();
        File zip = new File(dir, p.name + "_" + Utils.stamp() + ".zip");
        if (Utils.zipDir(p.dir, zip)) return zip;
        return null;
    }

    public void savePrompt(Project p, String text) {
        Utils.writeText(new File(p.pm(), "prompts/" + Utils.stamp() + ".txt"), text);
    }

    public void saveResponse(Project p, String text) {
        Utils.writeText(new File(p.pm(), "responses/" + Utils.stamp() + ".txt"), text);
    }

    public long totalSize() {
        return Utils.dirSize(root);
    }

    public int totalFiles() {
        int t = 0;
        List<Project> ps = list();
        for (int i = 0; i < ps.size(); i++) t += countFiles(ps.get(i));
        return t;
    }
}
