package com.pm.ai.core;

import com.pm.ai.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Construye el mega-prompt para Qwen3-Max usando el PROTOCOLO PM.
 * El modelo NO crea archivos: solo devuelve texto con marcadores que esta
 * aplicacion entiende y aplica sobre el proyecto.
 */
public class PromptBuilder {

    public static final String MODE_CREATE = "CREATE";
    public static final String MODE_UPDATE = "UPDATE";
    public static final String MODE_FIX = "FIX";
    public static final String MODE_CONTINUE = "CONTINUE";

    public static String protocol() {
        StringBuilder s = new StringBuilder();
        s.append("================ PROTOCOLO PM v1.0 (SALIDA OBLIGATORIA) ================\n\n");
        s.append("[REGLAS ABSOLUTAS]\n");
        s.append("R1. NO tienes acceso a ningun sistema de archivos, terminal, navegador ni herramienta.\n");
        s.append("    NO crees, NO abras, NO ejecutes ni NO modifiques archivos por tu cuenta.\n");
        s.append("    Tu UNICA salida es TEXTO PLANO siguiendo este protocolo.\n");
        s.append("R2. PROHIBIDO envolver la respuesta en bloques markdown. PROHIBIDO anadir texto\n");
        s.append("    explicativo fuera de los marcadores (solo se permite el PLAN y el SUMMARY).\n");
        s.append("R3. Cada archivo se entrega en un bloque @@PM_FILE ... @@PM_END_FILE con su ruta\n");
        s.append("    RELATIVA a la raiz del proyecto, siempre con barras '/'.\n");
        s.append("R4. El contenido va entre @@PM_CODE_START y @@PM_CODE_END: EXACTO y COMPLETO.\n");
        s.append("    PROHIBIDO usar '...', '// resto del codigo igual', 'idem' u omisiones.\n");
        s.append("R5. ORDEN de entrega: 1) configuracion/manifest, 2) recursos, 3) codigo fuente por\n");
        s.append("    capas (modelo -> nucleo -> interfaz), 4) documentacion al final.\n");
        s.append("R6. Si el archivo YA EXISTE y solo cambia una parte -> ACTION: EDIT con pares\n");
        s.append("    FIND/REPLACE copiados LITERALMENTE del contenido actual que te doy.\n");
        s.append("R7. Si se te acaba el espacio a mitad de un archivo -> escribe @@PM_STATUS: INCOMPLETE,\n");
        s.append("    cierra con @@PM_END_FILE y DETENTE. No inventes ni resumes lo que falta.\n");
        s.append("R8. No repitas archivos que no cambian.\n");
        s.append("R9. Empieza SIEMPRE con @@PM_START y termina SIEMPRE con @@PM_END.\n\n");

        s.append("[MARCADORES]\n");
        s.append("@@PM_START\n");
        s.append("@@PM_PROJECT: <nombre>\n");
        s.append("@@PM_MODE: CREATE | UPDATE | FIX | CONTINUE\n");
        s.append("@@PM_PLAN\n");
        s.append("1. <paso y archivo>\n");
        s.append("@@PM_END_PLAN\n\n");

        s.append("@@PM_FILE\n");
        s.append("@@PM_ACTION: CREATE | REPLACE | EDIT | DELETE | RENAME | CONTINUE | APPEND\n");
        s.append("@@PM_PATH: ruta/relativa/del/archivo\n");
        s.append("@@PM_TARGET: solo para RENAME (nueva ruta)\n");
        s.append("@@PM_LANG: html | css | js | java | xml | py | json | md | c | txt\n");
        s.append("@@PM_NOTE: explicacion corta de una linea\n");
        s.append("@@PM_CODE_START\n");
        s.append("<contenido completo del archivo>\n");
        s.append("@@PM_CODE_END\n");
        s.append("@@PM_STATUS: COMPLETE | INCOMPLETE\n");
        s.append("@@PM_END_FILE\n\n");

        s.append("[EDICIONES QUIRURGICAS sobre un archivo existente]\n");
        s.append("@@PM_FILE\n");
        s.append("@@PM_ACTION: EDIT\n");
        s.append("@@PM_PATH: ruta/del/archivo\n");
        s.append("@@PM_EDIT_START\n");
        s.append("@@PM_FIND_START\n");
        s.append("<texto exacto que existe hoy, varias lineas si hace falta>\n");
        s.append("@@PM_FIND_END\n");
        s.append("@@PM_REPLACE_START\n");
        s.append("<texto nuevo que lo sustituye>\n");
        s.append("@@PM_REPLACE_END\n");
        s.append("@@PM_EDIT_END\n");
        s.append("@@PM_STATUS: COMPLETE\n");
        s.append("@@PM_END_FILE\n");
        s.append("(puedes poner varios pares FIND/REPLACE dentro del mismo bloque EDIT)\n\n");

        s.append("[CONTINUAR UN ARCHIVO CORTADO]\n");
        s.append("@@PM_FILE\n");
        s.append("@@PM_ACTION: CONTINUE\n");
        s.append("@@PM_PATH: ruta/del/archivo\n");
        s.append("@@PM_CODE_START\n");
        s.append("<SOLO lo que falta, empezando exactamente donde se corto, sin repetir nada>\n");
        s.append("@@PM_CODE_END\n");
        s.append("@@PM_STATUS: COMPLETE | INCOMPLETE\n");
        s.append("@@PM_END_FILE\n\n");

        s.append("@@PM_SUMMARY\n");
        s.append("<que se ha hecho y como probarlo>\n");
        s.append("@@PM_NEXT\n");
        s.append("<que pedirme en la siguiente iteracion>\n");
        s.append("@@PM_END\n");
        s.append("========================================================================\n");
        return s.toString();
    }

    public static String tree(Storage st, Project p) {
        List<String> t = st.tree(p);
        if (t.size() == 0) return "(proyecto vacio)\n";
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < t.size(); i++) s.append(t.get(i)).append("\n");
        return s.toString();
    }

    public static String contents(Storage st, Project p, List<String> paths, int limit) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < paths.size(); i++) {
            String rel = paths.get(i);
            File f = st.file(p, rel);
            if (!f.isFile()) continue;
            String c = Utils.readText(f);
            boolean cut = false;
            if (limit > 0 && c.length() > limit) {
                c = c.substring(0, limit);
                cut = true;
            }
            s.append("----- ARCHIVO: ").append(rel).append(" -----\n");
            s.append(c);
            if (!c.endsWith("\n")) s.append("\n");
            if (cut) s.append("... [RECORTADO POR LIMITE DE CONTEXTO] ...\n");
            s.append("----- FIN: ").append(rel).append(" -----\n\n");
        }
        return s.toString();
    }

    public static String build(Storage st, Project p, String mode, String task,
                               boolean withSpec, boolean withTree, boolean withContents,
                               List<String> picked, int limit) {
        StringBuilder s = new StringBuilder();
        String model = p.model == null || p.model.length() == 0 ? "Qwen3-Max" : p.model;

        s.append("ROL: Eres un ingeniero de software senior experto en ").append(Types.label(p.type)).append(".\n");
        s.append("MODELO DESTINO: ").append(model).append("\n");
        s.append("IDIOMA de comentarios, textos y documentacion: ").append(p.docsLang).append("\n\n");

        if (MODE_FIX.equals(mode)) {
            s.append("MODO: CORREGIR ERROR. El proyecto ya existe y falla. Diagnostica la causa raiz\n");
            s.append("y entrega SOLO los archivos o ediciones necesarias para arreglarlo.\n\n");
        } else if (MODE_UPDATE.equals(mode)) {
            s.append("MODO: MEJORAR / EDITAR un proyecto YA EXISTENTE. Entrega solo lo que cambia:\n");
            s.append("archivos nuevos con CREATE y cambios sobre archivos existentes con EDIT.\n\n");
        } else {
            s.append("MODO: CREAR el proyecto COMPLETO desde cero, archivo por archivo.\n\n");
        }

        s.append("[PROYECTO]\n");
        s.append("nombre: ").append(p.name).append("\n");
        s.append("tipo:   ").append(Types.label(p.type)).append("\n\n");

        if (withSpec) {
            s.append("[FICHA TECNICA]\n");
            if (p.description != null && p.description.trim().length() > 0) {
                s.append("Descripcion: ").append(p.description.trim()).append("\n\n");
            }
            if (p.features != null && p.features.trim().length() > 0) {
                s.append("Caracteristicas:\n").append(p.features.trim()).append("\n\n");
            }
        }

        s.append("[REGLAS TECNICAS OBLIGATORIAS PARA ESTE TIPO]\n");
        s.append(Types.constraints(p.type)).append("\n");

        if (withTree || withContents) {
            s.append("[ESTADO ACTUAL DEL PROYECTO]\n");
            if (withTree) {
                s.append("Arbol de archivos (raiz = carpeta del proyecto):\n");
                s.append(tree(st, p)).append("\n");
            }
            if (withContents) {
                List<String> paths = picked != null && picked.size() > 0 ? picked : st.files(p);
                s.append("Contenido actual (copialo LITERAL en los FIND cuando edites):\n\n");
                s.append(contents(st, p, paths, limit));
            }
        }

        s.append("[TAREA]\n");
        if (task == null || task.trim().length() == 0) {
            s.append("Construye el proyecto completo segun la ficha tecnica y las reglas anteriores.\n\n");
        } else {
            s.append(task.trim()).append("\n\n");
        }

        s.append(protocol());

        s.append("\n[ORDEN Y COMPLETITUD]\n");
        s.append("- Entrega TODOS los archivos necesarios para que el proyecto funcione al primer intento.\n");
        s.append("- No dejes nada a medias: si un archivo es largo, entregalo completo aunque ocupes\n");
        s.append("  varios bloques de tu respuesta.\n");
        s.append("- Antes de @@PM_END revisa que cada @@PM_FILE tenga PATH, CODE_START/CODE_END y STATUS.\n\n");

        s.append("EMPIEZA TU RESPUESTA AHORA CON: @@PM_START\n");
        return s.toString();
    }

    public static String continuePrompt(Storage st, Project p, String path) {
        String partial = PendingManager.get(p, path);
        if (partial == null) {
            File f = st.file(p, path);
            partial = f.isFile() ? Utils.readText(f) : "";
        }
        int tailLines = 30;
        String tail = Utils.tail(partial, tailLines);

        StringBuilder s = new StringBuilder();
        String model = p.model == null || p.model.length() == 0 ? "Qwen3-Max" : p.model;
        s.append("ROL: Eres un ingeniero de software senior. MODELO: ").append(model).append("\n");
        s.append("MODO: CONTINUAR UN ARCHIVO QUE SE QUEDO CORTADO.\n\n");
        s.append("[PROYECTO] ").append(p.name).append("  (tipo: ").append(Types.label(p.type)).append(")\n\n");
        s.append("[REGLAS TECNICAS DEL TIPO]\n").append(Types.constraints(p.type)).append("\n");
        s.append("[SITUACION]\n");
        s.append("El archivo '").append(path).append("' se quedo a medias. Ya tenemos escritos\n");
        s.append(partial.length() + " caracteres. Te muestro las ULTIMAS ").append(tailLines)
                .append(" lineas que ya existen:\n\n");
        s.append("@@PM_CONTEXT_START\n");
        s.append(tail);
        if (!tail.endsWith("\n")) s.append("\n");
        s.append("@@PM_CONTEXT_END\n\n");
        s.append("[INSTRUCCIONES]\n");
        s.append("1. Continua el archivo EXACTAMENTE donde se corto. NO repitas ninguna linea\n");
        s.append("   de las que ya te he mostrado, ni reescribas el principio del archivo.\n");
        s.append("2. Entrega SOLO el texto que falta para terminar el archivo completo y funcional.\n");
        s.append("3. Usa este formato exacto:\n\n");
        s.append("@@PM_START\n");
        s.append("@@PM_MODE: CONTINUE\n");
        s.append("@@PM_FILE\n");
        s.append("@@PM_ACTION: CONTINUE\n");
        s.append("@@PM_PATH: ").append(path).append("\n");
        s.append("@@PM_CODE_START\n");
        s.append("<aqui SOLO lo que falta>\n");
        s.append("@@PM_CODE_END\n");
        s.append("@@PM_STATUS: COMPLETE\n");
        s.append("@@PM_END_FILE\n");
        s.append("@@PM_END\n\n");
        s.append("4. Si vuelve a faltarte espacio, pon @@PM_STATUS: INCOMPLETE y para; yo te pedire\n");
        s.append("   otra continuacion con las nuevas ultimas lineas.\n");
        s.append("5. No anadas ningun otro archivo ni texto fuera de los marcadores.\n\n");
        s.append("EMPIEZA AHORA CON: @@PM_START\n");
        return s.toString();
    }

    public static List<String> pendingPaths(Project p) {
        return PendingManager.paths(p);
    }
}
