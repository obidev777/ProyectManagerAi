package com.pm.ai.core;

/** Tipos de proyecto soportados y sus reglas tecnicas para el prompt. */
public class Types {

    public static final String HTML = "html";
    public static final String PYTHON = "python";
    public static final String ANDROID = "android";
    public static final String JAVA = "java";
    public static final String NODE = "node";
    public static final String CPP = "cpp";
    public static final String TEXT = "text";

    public static final String[] KEYS = {HTML, PYTHON, ANDROID, JAVA, NODE, CPP, TEXT};

    public static String label(String k) {
        if (HTML.equals(k)) return "HTML / Web";
        if (PYTHON.equals(k)) return "Python";
        if (ANDROID.equals(k)) return "Android (AIDE 3.2.2)";
        if (JAVA.equals(k)) return "Java (consola)";
        if (NODE.equals(k)) return "Node.js";
        if (CPP.equals(k)) return "C / C++";
        return "Texto / Otro";
    }

    public static String emoji(String k) {
        if (HTML.equals(k)) return "</>";
        if (PYTHON.equals(k)) return "py";
        if (ANDROID.equals(k)) return "AI";
        if (JAVA.equals(k)) return "Jv";
        if (NODE.equals(k)) return "js";
        if (CPP.equals(k)) return "C+";
        return "txt";
    }

    public static String constraints(String k) {
        StringBuilder sb = new StringBuilder();
        if (HTML.equals(k)) {
            sb.append("- Proyecto web puro: HTML5 + CSS3 + JavaScript vanilla.\n");
            sb.append("- PROHIBIDO usar frameworks, npm, bundlers, CDNs externos o build tools.\n");
            sb.append("- El archivo principal es 'index.html' en la raiz del proyecto.\n");
            sb.append("- Estructura: index.html, css/styles.css, js/app.js y las paginas extra necesarias.\n");
            sb.append("- Debe funcionar abriendo index.html con file:// (sin servidor) y verse perfecto en movil.\n");
            sb.append("- Diseno responsive mobile-first, modo oscuro elegante, animaciones suaves en CSS.\n");
            sb.append("- Persistencia con localStorage. Sin fetch a rutas absolutas.\n");
        } else if (PYTHON.equals(k)) {
            sb.append("- Python 3 compatible con Pydroid 3 / Termux en Android.\n");
            sb.append("- Punto de entrada: 'main.py' en la raiz. Incluye 'requirements.txt'.\n");
            sb.append("- Evita librerias que requieran compilacion nativa; si son imprescindibles, avisalo en el PLAN.\n");
            sb.append("- Estructura: main.py, core/, ui/ (si es Tkinter), data/, README.md.\n");
            sb.append("- Rutas relativas al script: os.path.dirname(os.path.abspath(__file__)).\n");
        } else if (ANDROID.equals(k)) {
            sb.append("- PROYECTO ANDROID PARA AIDE 3.2.2: se compila DENTRO del telefono.\n");
            sb.append("- Java CLASICO (Java 7). PROHIBIDO: lambdas, streams, method references,\n");
            sb.append("  try-with-resources, String.join, diamond en clases anonimas.\n");
            sb.append("- PROHIBIDO AndroidX, AppCompat, Material Components, Kotlin, ViewBinding, DataBinding.\n");
            sb.append("- Las Activity extienden android.app.Activity. Tema android:Theme.Material.NoActionBar.\n");
            sb.append("- minSdkVersion 21, targetSdkVersion 28. CERO dependencias externas.\n");
            sb.append("- Estructura EXACTA:\n");
            sb.append("    AndroidManifest.xml\n");
            sb.append("    project.properties   (target=android-28)\n");
            sb.append("    src/<paquete>/Xxx.java\n");
            sb.append("    res/layout/*.xml\n");
            sb.append("    res/values/{strings,colors,styles,dimens}.xml\n");
            sb.append("    res/drawable/*.xml   (shapes y vectores; NUNCA referencies PNG que no entregues)\n");
            sb.append("- Listas con ListView + BaseAdapter propio (nada de RecyclerView).\n");
            sb.append("- JSON con org.json (viene en el SDK). HTTP con HttpURLConnection. Ficheros con java.io.File.\n");
            sb.append("- Almacenamiento en getExternalFilesDir(null) o getFilesDir().\n");
            sb.append("- Declara TODAS las Activity y permisos en el Manifest.\n");
            sb.append("- Protege APIs nuevas con Build.VERSION.SDK_INT y da alternativa para API 21.\n");
        } else if (JAVA.equals(k)) {
            sb.append("- Java 8 de consola, sin Maven ni Gradle. Entrada: 'src/Main.java'.\n");
            sb.append("- Estructura por paquetes bajo src/. README.md con el comando de compilacion.\n");
        } else if (NODE.equals(k)) {
            sb.append("- Node.js sin frameworks pesados. Entrada 'index.js' + package.json con scripts.\n");
            sb.append("- Dependencias minimas y justificadas en el PLAN.\n");
        } else if (CPP.equals(k)) {
            sb.append("- C/C++ portable (C++11). Entrada 'main.cpp' + Makefile + README.md.\n");
            sb.append("- Solo libreria estandar.\n");
        } else {
            sb.append("- Proyecto de documentos/texto. Empieza siempre por README.md con el indice.\n");
        }
        return sb.toString();
    }

    public static String runHint(String k) {
        if (HTML.equals(k)) return "Se abrira en el navegador interno (WebView) con consola JS.";
        if (PYTHON.equals(k)) return "Se intentara abrir con Pydroid 3 o Termux.";
        if (ANDROID.equals(k)) return "Se intentara abrir con AIDE para compilar el APK.";
        if (NODE.equals(k)) return "Se intentara abrir con Termux (node index.js).";
        if (CPP.equals(k)) return "Se intentara abrir con Termux (make).";
        return "Vista previa de texto.";
    }
}
