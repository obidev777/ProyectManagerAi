package com.pm.ai.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.pm.ai.R;
import com.pm.ai.core.Action;
import com.pm.ai.util.Utils;

import java.util.List;

public class ActionAdapter extends BaseAdapter
{

    private final List<Action> data;
    private final LayoutInflater inf;
    private final Context ctx;

    public ActionAdapter(Context c, List<Action> data)
	{
        this.ctx = c;
        this.data = data;
        this.inf = LayoutInflater.from(c);
    }

    public int getCount()
	{
        return data.size();
    }

    public Object getItem(int i)
	{
        return data.get(i);
    }

    public long getItemId(int i)
	{
        return i;
    }

    public View getView(int pos, View cv, ViewGroup parent)
	{
        View v = cv == null ? inf.inflate(R.layout.item_action, parent, false) : cv;
        final Action a = data.get(pos);

        CheckBox cb = (CheckBox) v.findViewById(R.id.cbSel);
        cb.setOnCheckedChangeListener(null);
        cb.setChecked(a.selected);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton b, boolean checked)
				{
					a.selected = checked;
				}
			});

        TextView kind = (TextView) v.findViewById(R.id.tvKind);
        kind.setText(a.kindLabel() + (a.incomplete() ? " ..." : ""));
        int bg = R.drawable.bg_badge_ok;
        int fg = R.color.ok;
        if (a.kind == Action.REPLACE)
		{
            bg = R.drawable.bg_badge_info;
            fg = R.color.info;
        }
		else if (a.kind == Action.EDIT)
		{
            bg = R.drawable.bg_badge_acc;
            fg = R.color.acc;
        }
		else if (a.kind == Action.DELETE)
		{
            bg = R.drawable.bg_badge_err;
            fg = R.color.err;
        }
		else if (a.kind == Action.RENAME)
		{
            bg = R.drawable.bg_badge_warn;
            fg = R.color.warn;
        }
		else if (a.kind == Action.CONTINUE || a.kind == Action.APPEND)
		{
            bg = R.drawable.bg_badge_warn;
            fg = R.color.warn;
        }
        kind.setBackgroundResource(bg);
        kind.setTextColor(Utils.color(ctx, fg));

        ((TextView) v.findViewById(R.id.tvPath)).setText(a.path);

        TextView note = (TextView) v.findViewById(R.id.tvNote);
        String nt = a.note == null ? "" : a.note;
        if (a.result.length() > 0) nt = nt + "  ->  " + a.result;
        note.setText(nt);
        note.setVisibility(nt.length() == 0 ? View.GONE : View.VISIBLE);

        TextView detail = (TextView) v.findViewById(R.id.tvDetail);
        StringBuilder d = new StringBuilder();
        if (a.kind == Action.EDIT)
		{
            d.append(a.edits.size()).append(" bloque(s) FIND/REPLACE");
        }
		else if (a.kind == Action.DELETE)
		{
            d.append("se eliminara el archivo");
        }
		else if (a.kind == Action.RENAME)
		{
            d.append("-> ").append(a.target);
        }
		else
		{
            d.append(a.lines()).append(" lineas, ").append(a.size()).append(" chars");
            String head = Utils.tail(a.content == null ? "" : head(a.content, 3), 3);
            if (head.trim().length() > 0) d.append("\n").append(head.trim());
        }
        detail.setText(d.toString());
        return v;
    }

    private String head(String s, int lines)
	{
        List<String> ls = Utils.splitLines(s);
        List<String> out = new java.util.ArrayList<String>();
        for (int i = 0; i < ls.size() && i < lines; i++) out.add(ls.get(i));
        return Utils.join(out, "\n");
    }
}
