package com.pm.ai.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.pm.ai.R;
import com.pm.ai.core.Project;
import com.pm.ai.core.Storage;
import com.pm.ai.core.Types;
import com.pm.ai.util.Utils;

import java.util.List;

public class ProjectAdapter extends BaseAdapter {

    public interface Host {
        void onOpen(Project p);

        void onMore(Project p, View anchor);
    }

    private final List<Project> data;
    private final Storage store;
    private final Host host;
    private final LayoutInflater inf;

    public ProjectAdapter(Context c, List<Project> data, Storage store, Host host) {
        this.data = data;
        this.store = store;
        this.host = host;
        this.inf = LayoutInflater.from(c);
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int i) {
        return data.get(i);
    }

    public long getItemId(int i) {
        return i;
    }

    public View getView(int pos, View cv, ViewGroup parent) {
        View v = cv == null ? inf.inflate(R.layout.item_project, parent, false) : cv;
        final Project p = data.get(pos);
        ((TextView) v.findViewById(R.id.tvEmoji)).setText(Types.emoji(p.type));
        ((TextView) v.findViewById(R.id.tvName)).setText(p.name);
        String d = p.description == null ? "" : p.description.trim();
        if (d.length() == 0) d = "Sin descripcion. Anadela para mejorar los prompts.";
        ((TextView) v.findViewById(R.id.tvDesc)).setText(d);
        ((TextView) v.findViewById(R.id.tvType)).setText(Types.label(p.type));
        ((TextView) v.findViewById(R.id.tvMeta)).setText(store.countFiles(p) + " archivos | "
                + Utils.humanSize(Utils.dirSize(p.dir)) + " | " + Utils.dateShort(p.updated));
        ImageView more = (ImageView) v.findViewById(R.id.btnMore);
        more.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                host.onMore(p, view);
            }
        });
        return v;
    }
}
