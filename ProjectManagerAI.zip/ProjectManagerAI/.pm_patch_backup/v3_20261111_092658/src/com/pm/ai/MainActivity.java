package com.pm.ai;
import android.os.Build;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;

import com.pm.ai.core.Prefs;
import com.pm.ai.core.Project;
import com.pm.ai.core.Storage;
import com.pm.ai.core.Types;
import com.pm.ai.ui.ProjectAdapter;
import com.pm.ai.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements ProjectAdapter.Host {

    private Storage store;
    private final List<Project> all = new ArrayList<Project>();
    private final List<Project> shown = new ArrayList<Project>();
    private ProjectAdapter adapter;
    private ListView lv;
    private LinearLayout emptyBox;
    private TextView statProjects;
    private TextView statFiles;
    private TextView statSize;
    private EditText etSearch;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        Utils.allowFileUri();
        store = Storage.get(this);
        Storage.ensureAccess(this);
store = Storage.get(this);

        lv = (ListView) findViewById(R.id.lvProjects);
        emptyBox = (LinearLayout) findViewById(R.id.emptyBox);
        statProjects = (TextView) findViewById(R.id.statProjects);
        statFiles = (TextView) findViewById(R.id.statFiles);
        statSize = (TextView) findViewById(R.id.statSize);
        etSearch = (EditText) findViewById(R.id.etSearch);

        adapter = new ProjectAdapter(this, shown, store, this);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) onOpen(shown.get(pos));
            }
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                filter();
            }

            public void afterTextChanged(Editable e) {
            }
        });

        findViewById(R.id.fab).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                newProjectDialog();
            }
        });
                findViewById(R.id.btnPrompts).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PromptsActivity.class));
            }
        });
findViewById(R.id.btnSettings).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                settingsDialog();
            }
        });
        findViewById(R.id.btnImport).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                importFolders();
            }
        });
    }

    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        store.reload();
        all.clear();
        all.addAll(store.list());
        filter();
        statProjects.setText(all.size() + " proyectos");
        statFiles.setText(store.totalFiles() + " archivos");
        statSize.setText(Utils.humanSize(store.totalSize()));
    }

    private void filter() {
        String q = etSearch.getText().toString().trim().toLowerCase(Locale.US);
        shown.clear();
        for (int i = 0; i < all.size(); i++) {
            Project p = all.get(i);
            if (q.length() == 0
                    || p.name.toLowerCase(Locale.US).indexOf(q) >= 0
                    || (p.description != null && p.description.toLowerCase(Locale.US).indexOf(q) >= 0)
                    || p.type.indexOf(q) >= 0) {
                shown.add(p);
            }
        }
        adapter.notifyDataSetChanged();
        boolean empty = shown.size() == 0;
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        lv.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    public void onOpen(Project p) {
        Intent i = new Intent(this, ProjectActivity.class);
        i.putExtra("project", p.name);
        startActivity(i);
    }

    public void onMore(final Project p, View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Abrir");
        pm.getMenu().add(0, 2, 0, "Prompt Qwen");
        pm.getMenu().add(0, 3, 0, "Aplicar respuesta");
        pm.getMenu().add(0, 4, 0, "Editar ficha tecnica");
        pm.getMenu().add(0, 5, 0, "Renombrar");
        pm.getMenu().add(0, 6, 0, "Duplicar");
        pm.getMenu().add(0, 7, 0, "Exportar ZIP");
        pm.getMenu().add(0, 8, 0, "Eliminar");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == 1) onOpen(p);
                else if (id == 2) goPrompt(p, "CREATE");
                else if (id == 3) goApply(p);
                else if (id == 4) editSpec(p);
                else if (id == 5) renameDialog(p);
                else if (id == 6) {
                    Project d = store.duplicate(p.name);
                    if (d == null) Utils.toast(MainActivity.this, "No se pudo duplicar");
                    else {
                        Utils.toast(MainActivity.this, "Duplicado como " + d.name);
                        reload();
                    }
                } else if (id == 7) exportZip(p);
                else if (id == 8) deleteDialog(p);
                return true;
            }
        });
        pm.show();
    }

    private void goPrompt(Project p, String mode) {
        Intent i = new Intent(this, PromptActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("mode", mode);
        startActivity(i);
    }

    private void goApply(Project p) {
        Intent i = new Intent(this, ApplyActivity.class);
        i.putExtra("project", p.name);
        startActivity(i);
    }

    private void newProjectDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_new_project, null);
        final EditText etName = (EditText) v.findViewById(R.id.etName);
        final Spinner sp = (Spinner) v.findViewById(R.id.spType);
        final EditText etDesc = (EditText) v.findViewById(R.id.etDesc);
        final EditText etFeat = (EditText) v.findViewById(R.id.etFeat);
        final CheckBox cbT = (CheckBox) v.findViewById(R.id.cbTemplate);

        List<String> labels = new ArrayList<String>();
        for (int i = 0; i < Types.KEYS.length; i++) labels.add(Types.label(Types.KEYS[i]));
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, labels);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        sp.setAdapter(ad);

        new AlertDialog.Builder(this)
                .setTitle("Nuevo proyecto")
                .setView(v)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String name = etName.getText().toString().trim();
                        if (name.length() == 0) {
                            Utils.toast(MainActivity.this, "Escribe un nombre");
                            return;
                        }
                        int pos = sp.getSelectedItemPosition();
                        String type = pos < 0 ? Types.HTML : Types.KEYS[pos];
                        Project p = store.create(name, type,
                                etDesc.getText().toString(), etFeat.getText().toString(), cbT.isChecked());
                        Utils.toast(MainActivity.this, "Proyecto creado: " + p.dir.getAbsolutePath());
                        reload();
                        onOpen(p);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void editSpec(final Project p) {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_new_project, null);
        final EditText etName = (EditText) v.findViewById(R.id.etName);
        final Spinner sp = (Spinner) v.findViewById(R.id.spType);
        final EditText etDesc = (EditText) v.findViewById(R.id.etDesc);
        final EditText etFeat = (EditText) v.findViewById(R.id.etFeat);
        CheckBox cbT = (CheckBox) v.findViewById(R.id.cbTemplate);
        cbT.setVisibility(View.GONE);
        etName.setText(p.name);
        etDesc.setText(p.description);
        etFeat.setText(p.features);

        List<String> labels = new ArrayList<String>();
        for (int i = 0; i < Types.KEYS.length; i++) labels.add(Types.label(Types.KEYS[i]));
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, labels);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        sp.setAdapter(ad);
        for (int i = 0; i < Types.KEYS.length; i++) {
            if (Types.KEYS[i].equals(p.type)) {
                sp.setSelection(i);
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Ficha tecnica de " + p.name)
                .setView(v)
                .setPositiveButton(R.string.act_save, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        p.description = etDesc.getText().toString();
                        p.features = etFeat.getText().toString();
                        int pos = sp.getSelectedItemPosition();
                        if (pos >= 0) p.type = Types.KEYS[pos];
                        store.save(p);
                        Utils.toast(MainActivity.this, "Ficha guardada");
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void renameDialog(final Project p) {
        final EditText et = new EditText(this);
        et.setText(p.name);
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Renombrar proyecto")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String n = store.rename(p.name, et.getText().toString());
                        if (n == null) Utils.toast(MainActivity.this, "Nombre no valido o ya existe");
                        else reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void deleteDialog(final Project p) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + p.name + "?")
                .setMessage("Se borrara la carpeta completa:\n" + p.dir.getAbsolutePath())
                .setPositiveButton(R.string.act_delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        store.delete(p.name);
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void exportZip(final Project p) {
        Utils.requestStorageIfNeeded(this);
        File z = store.exportZip(p);
        if (z == null) {
            Utils.toast(this, "No se pudo crear el ZIP");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("ZIP creado")
                .setMessage(z.getAbsolutePath() + "\n\nTamano: " + Utils.humanSize(z.length()))
                .setPositiveButton(R.string.act_share, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        Utils.shareFile(MainActivity.this, store.exportZip(p));
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void importFolders() {
        File root = store.getRoot();
        File[] kids = root.listFiles();
        int n = 0;
        if (kids != null) {
            for (int i = 0; i < kids.length; i++) {
                File d = kids[i];
                if (!d.isDirectory() || d.getName().startsWith(".")) continue;
                File meta = new File(new File(d, ".pm"), "project.json");
                if (!meta.isFile()) {
                    store.save(store.open(d.getName()));
                    n++;
                }
            }
        }
        Utils.toast(this, n == 0 ? "No hay carpetas nuevas que importar" : n + " carpetas importadas");
        reload();
    }

        private void settingsDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null);
        final EditText etModel = (EditText) v.findViewById(R.id.etModel);
        final Spinner spLang = (Spinner) v.findViewById(R.id.spLang);
        final CheckBox cbBackup = (CheckBox) v.findViewById(R.id.cbBackup);
        final CheckBox cbHi = (CheckBox) v.findViewById(R.id.cbHighlight);
        final CheckBox cbGu = (CheckBox) v.findViewById(R.id.cbGutter);
        final CheckBox cbAutoP = (CheckBox) v.findViewById(R.id.cbAutoPrompts);
        final CheckBox cbAide = (CheckBox) v.findViewById(R.id.cbAide);
        final TextView tvRoot = (TextView) v.findViewById(R.id.tvRoot);
        etModel.setText(Prefs.model(this));
        cbBackup.setChecked(Prefs.backup(this));
        cbHi.setChecked(Prefs.highlight(this));
        cbGu.setChecked(Prefs.gutter(this));
        cbAutoP.setChecked(Prefs.autoPrompts(this));
        cbAide.setChecked(Prefs.useAide(this));
        tvRoot.setText("Almacen: " + store.rootPath() + "\n" + store.rootLabel());
        v.findViewById(R.id.btnAllFiles).setVisibility(
                Build.VERSION.SDK_INT >= 30 ? View.VISIBLE : View.GONE);
        v.findViewById(R.id.btnRoot).setOnClickListener(new View.OnClickListener() {
            public void onClick(View w) {
                storageDialog(tvRoot);
            }
        });
        v.findViewById(R.id.btnMigrate).setOnClickListener(new View.OnClickListener() {
            public void onClick(View w) {
                migrateDialog(tvRoot);
            }
        });
        v.findViewById(R.id.btnAllFiles).setOnClickListener(new View.OnClickListener() {
            public void onClick(View w) {
                Utils.requestAllFilesAccess(MainActivity.this);
            }
        });
        final String[] langs = {"Espanol", "English", "Portugues", "Frances"};
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, langs);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        spLang.setAdapter(ad);
        for (int i = 0; i < langs.length; i++) {
            if (langs[i].equals(Prefs.docsLang(this))) {
                spLang.setSelection(i);
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(v)
                .setNeutralButton("Historial de prompts", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        openPrompts();
                    }
                })
                .setPositiveButton(R.string.act_save, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        Prefs.str(MainActivity.this, "model", etModel.getText().toString().trim());
                        int pos = spLang.getSelectedItemPosition();
                        Prefs.str(MainActivity.this, "docsLang", pos < 0 ? "Espanol" : langs[pos]);
                        Prefs.bool(MainActivity.this, "backup", cbBackup.isChecked());
                        Prefs.bool(MainActivity.this, "highlight", cbHi.isChecked());
                        Prefs.bool(MainActivity.this, "gutter", cbGu.isChecked());
                        Prefs.autoPrompts(MainActivity.this, cbAutoP.isChecked());
                        Prefs.useAide(MainActivity.this, cbAide.isChecked());
                        Utils.toast(MainActivity.this, "Ajustes guardados");
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    // ==================== PATCH V2: almacenamiento e historial ====================
    private void openPrompts() {
        startActivity(new Intent(this, PromptsActivity.class));
    }

    private void storageDialog(final TextView tvRoot) {
        final File[] cands = Storage.candidates(this);
        final List<String> names = new ArrayList<String>();
        for (int i = 0; i < cands.length; i++) names.add(cands[i].getAbsolutePath());
        names.add("Ruta personalizada...");
        int checked = names.indexOf(store.rootPath());
        new AlertDialog.Builder(this)
                .setTitle("Carpeta de los proyectos")
                .setSingleChoiceItems(names.toArray(new String[names.size()]), checked,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                d.dismiss();
                                if (w < cands.length) applyRoot(cands[w].getAbsolutePath(), tvRoot);
                                else customRootDialog(tvRoot);
                            }
                        })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void customRootDialog(final TextView tvRoot) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("/storage/emulated/0/MisProyectos");
        et.setText(store.rootPath());
        new AlertDialog.Builder(this)
                .setTitle("Ruta personalizada")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        applyRoot(et.getText().toString().trim(), tvRoot);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void applyRoot(String path, TextView tvRoot) {
        if (path == null || path.length() == 0) return;
        File f = new File(path);
        if (!Utils.canWriteDir(f)) {
            if (!Utils.allFilesAccess()) {
                new AlertDialog.Builder(this)
                        .setTitle("Falta permiso de almacenamiento")
                        .setMessage("Android 11 o superior necesita 'Todos los archivos' "
                                + "para escribir en:\n" + path)
                        .setPositiveButton("Abrir ajustes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                Utils.requestAllFilesAccess(MainActivity.this);
                            }
                        })
                        .setNegativeButton(R.string.act_cancel, null)
                        .show();
                return;
            }
            Utils.toast(this, "No se puede escribir en esa carpeta");
            return;
        }
        store.setRoot(path);
        if (tvRoot != null) {
            tvRoot.setText("Almacen: " + store.rootPath() + "\n" + store.rootLabel());
        }
        Utils.toastLong(this, "Carpeta activa:\n" + store.rootPath());
        reload();
    }

    private void migrateDialog(final TextView tvRoot) {
        File[] cands = Storage.candidates(this);
        final List<String> names = new ArrayList<String>();
        final List<File> dirs = new ArrayList<File>();
        for (int i = 0; i < cands.length; i++) {
            if (cands[i].getAbsolutePath().equals(store.rootPath())) continue;
            names.add(cands[i].getAbsolutePath());
            dirs.add(cands[i]);
        }
        names.add("Ruta personalizada...");
        new AlertDialog.Builder(this)
                .setTitle("Migrar proyectos a...")
                .setItems(names.toArray(new String[names.size()]),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                if (w < dirs.size()) doMigrate(dirs.get(w), tvRoot);
                                else customMigrate(tvRoot);
                            }
                        })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void customMigrate(final TextView tvRoot) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("/storage/emulated/0/ProjectManagerAI");
        new AlertDialog.Builder(this)
                .setTitle("Ruta destino")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String s = et.getText().toString().trim();
                        if (s.length() > 0) doMigrate(new File(s), tvRoot);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void doMigrate(File dst, TextView tvRoot) {
        if (dst == null) return;
        if (!Utils.canWriteDir(dst)) {
            if (!Utils.allFilesAccess()) {
                Utils.requestAllFilesAccess(this);
                return;
            }
            Utils.toast(this, "No se puede escribir en " + dst.getAbsolutePath());
            return;
        }
        int n = store.migrateTo(dst);
        if (n < 0) {
            Utils.toast(this, "Fallo al migrar");
            return;
        }
        if (tvRoot != null) {
            tvRoot.setText("Almacen: " + store.rootPath() + "\n" + store.rootLabel());
        }
        Utils.toastLong(this, n + " elemento(s) migrados a\n" + store.rootPath());
        reload();
    }
}
