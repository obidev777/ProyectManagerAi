/** Automatically generated file. DO NOT MODIFY */
package com.pm.ai;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}