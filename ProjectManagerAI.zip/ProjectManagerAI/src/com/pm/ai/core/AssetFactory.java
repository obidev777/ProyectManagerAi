package com.pm.ai.core;

import android.util.Base64;
import com.pm.ai.util.Utils;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Punto de entrada unico para crear IMAGENES y AUDIOS desde las respuestas
 * del modelo. La app recibe comandos (SPEC / VECTOR / SVG / BASE64) y sabe
 * como materializarlos en archivos reales del proyecto.
 */
public class AssetFactory {

    private static final char BT = '`';

    public static class Result {
        public boolean ok = false;
        public String msg = "";
    }

    /** Quita vallas markdown y espacios sobrantes. */
    public static String stripFences(String s) {
        if (s == null) return "";
        java.util.List<String> ls = Utils.splitLines(s);
        while (ls.size() > 0 && ls.get(0).trim().length() == 0) ls.remove(0);
        while (ls.size() > 0 && ls.get(ls.size() - 1).trim().length() == 0) ls.remove(ls.size() - 1);
        if (ls.size() > 0 && isFence(ls.get(0).trim())) ls.remove(0);
        if (ls.size() > 0 && isFence(ls.get(ls.size() - 1).trim())) ls.remove(ls.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ls.size(); i++) sb.append(ls.get(i)).append("\n");
        return sb.toString();
    }

    private static boolean isFence(String t) {
        return t != null && t.length() >= 3 && t.charAt(0) == BT && t.charAt(1) == BT && t.charAt(2) == BT;
    }

    public static byte[] decodeBase64(String s) {
        if (s == null) return new byte[0];
        String clean = s.replaceAll("[^A-Za-z0-9+/=]", "");
        if (clean.length() == 0) return new byte[0];
        try {
            byte[] d = Base64.decode(clean, Base64.DEFAULT);
            return d == null ? new byte[0] : d;
        } catch (Throwable t) {
            return new byte[0];
        }
    }

    public static boolean writeBytes(File f, byte[] data) {
        FileOutputStream fos = null;
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            fos = new FileOutputStream(f);
            fos.write(data);
            fos.flush();
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            Utils.close(fos);
        }
    }

    public static boolean isImagePath(String path) {
        String e = ImageGen.extOf(path == null ? "" : path);
        return e.equals("png") || e.equals("jpg") || e.equals("jpeg") || e.equals("webp")
                || e.equals("svg") || e.equals("xml") || e.equals("gif") || e.equals("bmp");
    }

    public static boolean isAudioPath(String path) {
        String e = ImageGen.extOf(path == null ? "" : path);
        return e.equals("wav") || e.equals("mp3") || e.equals("ogg") || e.equals("m4a")
                || e.equals("pcm") || e.equals("aac");
    }

    /** Crea el asset y devuelve un mensaje legible para el log. */
    public static Result create(Action a, File outFile) {
        Result r = new Result();
        if (a.kind == Action.CREATE_IMAGE) {
            ImageGen.Out o = ImageGen.create(outFile, a.format, a.content, a.path);
            r.ok = o.ok;
            r.msg = o.ok ? ("imagen " + o.msg) : ("imagen fallida: " + o.msg);
            return r;
        }
        if (a.kind == Action.CREATE_AUDIO) {
            AudioGen.Out o = AudioGen.create(outFile, a.format, a.content, a.path);
            r.ok = o.ok;
            r.msg = o.ok ? ("audio " + o.msg) : ("audio fallido: " + o.msg);
            return r;
        }
        r.msg = "accion no es un asset";
        return r;
    }

    /** Validacion previa: avisa de problemas antes de escribir nada. */
    public static String validate(Action a) {
        String body = stripFences(a.content);
        if (body.trim().length() == 0) return "contenido vacio";
        String fmt = a.format == null ? "" : a.format.trim().toUpperCase();
        String ext = ImageGen.extOf(a.path);
        if (a.kind == Action.CREATE_AUDIO) {
            if (fmt.equals("SPEC") || (fmt.length() == 0 && body.trim().startsWith("{"))) {
                if (!ext.equals("wav") && !ext.equals("pcm")) {
                    return "un audio sintetizado debe ser .wav (usa @@PM_FORMAT: BASE64 para ."
                            + ext + ")";
                }
                try {
                    new org.json.JSONObject(body);
                } catch (Throwable t) {
                    return "SPEC de audio con JSON invalido";
                }
            }
            return "";
        }
        if (fmt.equals("SPEC") || (fmt.length() == 0 && body.trim().startsWith("{"))) {
            try {
                new org.json.JSONObject(body);
            } catch (Throwable t) {
                return "SPEC de imagen con JSON invalido";
            }
        }
        if (ext.equals("xml") && !body.contains("pathData") && !body.startsWith("<?xml")
                && !body.contains("S:") && !body.contains("F:") && !body.contains("M:")) {
            return "VECTOR sin path data reconocible";
        }
        if (!isImagePath(a.path)) return "extension inesperada para imagen: ." + ext;
        return "";
    }
}
