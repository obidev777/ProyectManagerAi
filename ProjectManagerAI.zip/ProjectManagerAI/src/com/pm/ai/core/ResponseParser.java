package com.pm.ai.core;

import com.pm.ai.util.Utils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Analiza la respuesta del modelo (Protocolo PM v2.1) y produce la lista de
 * acciones: archivos, ediciones por rango de lineas e imagenes/audios.
 * Tolerante: marcadores dentro de comentarios, vallas markdown y variantes.
 */
public class ResponseParser {

    private static final char BT = '`';

    public static final String PAT_HELP =
            "PROTOCOLO PM v2.1 (lo que esta app entiende)\n\n"
          + "Cabecera:\n"
          + "  @@PM_START / @@PM_END\n"
          + "  @@PM_PROJECT / @@PM_MODE / @@PM_PLAN / @@PM_SUMMARY / @@PM_NEXT\n"
          + "  @@PM_DIAGNOSIS (causa raiz en modo FIX) / @@PM_WARN\n\n"
          + "Bloque de archivo:\n"
          + "  @@PM_FILE\n"
          + "  @@PM_ACTION: CREATE | REPLACE | EDIT | EDIT_RANGE | INSERT_AFTER\n"
          + "               | DELETE_LINES | DELETE | RENAME | CONTINUE | APPEND\n"
          + "               | CREATE_IMAGE | CREATE_AUDIO\n"
          + "  @@PM_PATH / @@PM_TARGET / @@PM_LANG / @@PM_NOTE / @@PM_STATUS\n"
          + "  @@PM_CODE_START ... @@PM_CODE_END\n"
          + "  @@PM_END_FILE\n\n"
          + "Rangos de lineas:\n"
          + "  @@PM_FROM_LINE: 42   @@PM_TO_LINE: 57   @@PM_AFTER_LINE: 41\n\n"
          + "Imagen y audio:\n"
          + "  @@PM_FORMAT: SPEC | VECTOR | SVG | BASE64 | TEXT\n"
          + "  @@PM_SPEC_START ... @@PM_SPEC_END   (equivale a CODE_START/END)\n";

    private static final Pattern PAT = Pattern.compile("PM_([A-Za-z0-9_]+)\\s*[:=]?\\s*(.*)");
    private static final Pattern PATHY = Pattern.compile("([A-Za-z0-9_.\\-/]+\\.[A-Za-z0-9]{1,8})");
    private static final Pattern NUMLINE = Pattern.compile("^\\s*(\\d{1,6})\\s*[|:\\.\\)\\]>]\\s?");
    private static final Pattern RANGEVAL = Pattern.compile("(\\d+)\\s*[-:;,a-zA-Z ]*\\s*(\\d+)");

    private static final Set<String> KEYS = new HashSet<String>(Arrays.asList(new String[]{
            "START", "BEGIN", "PROJECT", "PROJECT_NAME", "MODE", "TITLE", "PLAN", "END_PLAN",
            "FILE", "END", "SUMMARY", "NEXT", "WARN", "WARNING", "INFO", "RISK", "TEST",
            "DIAGNOSIS", "CAUSE", "HYPOTHESIS", "ERROR", "ACTION", "OP", "TYPE", "PATH",
            "FILE_PATH", "TARGET", "NEW_PATH", "TO", "DEST", "LANG", "LANGUAGE", "NOTE",
            "DESC", "DESCRIPTION", "CODE_START", "CONTENT_START", "BEGIN_CONTENT", "CODE_END",
            "CONTENT_END", "BEGIN_END", "FIND_START", "SEARCH_START", "FIND_END", "END_FIND",
            "REPLACE_START", "REPLACE_WITH_START", "REPLACE_END", "EDIT_END", "END_REPLACE",
            "EDIT_START", "STATUS", "FILE_STATUS", "END_FILE", "FROM_LINE", "TO_LINE",
            "AFTER_LINE", "ANCHOR", "LINES", "RANGE", "LINE_FROM", "LINE_TO", "START_LINE",
            "END_LINE", "CONTEXT_START", "CONTEXT_END", "FILES", "VERSION", "FORMAT",
            "IMG_FORMAT", "AUDIO_FORMAT", "SPEC_START", "SPEC_END", "ASSET_START", "ASSET_END",
            "ASSET_FORMAT", "MEDIA_FORMAT", "ENCODING"
    }));

    public static class Result {
        public List<Action> actions = new ArrayList<Action>();
        public List<String> plan = new ArrayList<String>();
        public List<String> warnings = new ArrayList<String>();
        public String projectName = "";
        public String mode = "";
        public String title = "";
        public String summary = "";
        public String next = "";
        public String diagnosis = "";
        public boolean truncated = false;
        public boolean usedFallback = false;
        public int chars = 0;

        public List<Action> incompleteFiles() {
            List<Action> out = new ArrayList<Action>();
            for (int i = 0; i < actions.size(); i++) {
                if (actions.get(i).incomplete()) out.add(actions.get(i));
            }
            return out;
        }

        public int countSelected() {
            int n = 0;
            for (int i = 0; i < actions.size(); i++) if (actions.get(i).selected) n++;
            return n;
        }

        public int countRange() {
            int n = 0;
            for (int i = 0; i < actions.size(); i++) if (actions.get(i).isRange()) n++;
            return n;
        }

        public int countAssets() {
            int n = 0;
            for (int i = 0; i < actions.size(); i++) if (actions.get(i).isAsset()) n++;
            return n;
        }

        public String stats() {
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < actions.size(); i++) {
                Action a = actions.get(i);
                s.append("  ").append(a.kindLabel());
                if (a.isRange() && a.rangeLabel().length() > 0) {
                    s.append(" (").append(a.rangeLabel()).append(")");
                }
                if (a.format.length() > 0) s.append(" [").append(a.format).append("]");
                s.append("  ").append(a.path);
                if (i < actions.size() - 1) s.append("\n");
            }
            return s.toString();
        }
    }

    private static boolean isFence(String t) {
        return t != null && t.length() >= 3 && t.charAt(0) == BT && t.charAt(1) == BT
                && t.charAt(2) == BT;
    }

    private static boolean hasFence(String s) {
        if (s == null) return false;
        for (int i = 0; i + 2 < s.length(); i++) {
            if (s.charAt(i) == BT && s.charAt(i + 1) == BT && s.charAt(i + 2) == BT) return true;
        }
        return false;
    }

    public static Result parse(String text) {
        Result res = new Result();
        if (text == null) text = "";
        res.chars = text.length();
        String norm = text.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = norm.split("\n", -1);
        Action cur = null;
        StringBuilder buf = new StringBuilder();
        int mode = 0;
        String pendingFind = null;
        boolean fence = false;
        boolean wantFence = false;

        for (int i = 0; i < lines.length; i++) {
            String raw = lines[i];
            String t = raw.trim();

            if (mode == 1 || mode == 2 || mode == 3) {
                if (wantFence) {
                    wantFence = false;
                    if (isFence(t)) {
                        fence = true;
                        continue;
                    }
                }
                String k = markerKey(t);
                boolean closing = false;
                boolean fallthrough = false;
                if (k != null) {
                    if (mode == 1 && (k.equals("CODE_END") || k.equals("CONTENT_END")
                            || k.equals("BEGIN_END") || k.equals("SPEC_END")
                            || k.equals("ASSET_END"))) {
                        closing = true;
                    } else if (mode == 2 && (k.equals("FIND_END") || k.equals("END_FIND"))) {
                        closing = true;
                    } else if (mode == 3 && (k.equals("REPLACE_END") || k.equals("EDIT_END")
                            || k.equals("CODE_END") || k.equals("END_REPLACE"))) {
                        closing = true;
                    } else if (k.equals("END_FILE") || k.equals("STATUS") || k.equals("FILE_STATUS")
                            || k.equals("SUMMARY") || k.equals("END") || k.equals("FILE")
                            || k.equals("PATH") || k.equals("FILE_PATH") || k.equals("ACTION")
                            || k.equals("NEXT") || k.equals("DIAGNOSIS")) {
                        fallthrough = true;
                    }
                }
                if (fence && !closing && !fallthrough && isFence(t)) continue;
                if (closing || fallthrough) {
                    if (mode == 1) {
                        if (cur != null) cur.content = cleanBody(buf.toString(), cur);
                    } else if (mode == 2) {
                        pendingFind = buf.toString();
                    } else {
                        if (cur != null) {
                            cur.edits.add(new String[]{pendingFind == null ? "" : pendingFind,
                                    buf.toString()});
                        }
                        pendingFind = null;
                    }
                    buf.setLength(0);
                    mode = 0;
                    fence = false;
                    if (closing) continue;
                } else {
                    buf.append(raw).append("\n");
                    continue;
                }
            } else if (mode == 4 || mode == 6 || mode == 7 || mode == 8 || mode == 9) {
                if (markerKey(t) == null) {
                    buf.append(raw).append("\n");
                    continue;
                }
                if (mode == 4) addNonEmpty(res.plan, buf.toString());
                else if (mode == 6 && cur != null) cur.note = buf.toString().trim();
                else if (mode == 7) res.summary = buf.toString().trim();
                else if (mode == 8) res.next = buf.toString().trim();
                else if (mode == 9) res.diagnosis = (res.diagnosis + "\n" + buf.toString().trim()).trim();
                buf.setLength(0);
                mode = 0;
            }

            String key = markerKey(t);
            if (key == null) continue;
            String val = markerVal(t);

            if (key.equals("START") || key.equals("BEGIN") || key.equals("VERSION")
                    || key.equals("CONTEXT_START") || key.equals("CONTEXT_END")) continue;
            if (key.equals("PROJECT") || key.equals("PROJECT_NAME")) {
                res.projectName = val;
                continue;
            }
            if (key.equals("MODE")) {
                res.mode = val;
                continue;
            }
            if (key.equals("TITLE")) {
                res.title = val;
                continue;
            }
            if (key.equals("PLAN")) {
                mode = 4;
                buf.setLength(0);
                continue;
            }
            if (key.equals("END_PLAN")) {
                addNonEmpty(res.plan, buf.toString());
                buf.setLength(0);
                mode = 0;
                continue;
            }
            if (key.equals("FILE")) {
                if (cur != null) push(res, cur);
                cur = new Action();
                mode = 0;
                continue;
            }
            if (key.equals("END")) {
                if (cur != null) {
                    push(res, cur);
                    cur = null;
                }
                mode = 0;
                break;
            }
            if (key.equals("SUMMARY")) {
                if (val.length() == 0) {
                    mode = 7;
                    buf.setLength(0);
                } else {
                    res.summary = val;
                }
                continue;
            }
            if (key.equals("NEXT")) {
                if (val.length() == 0) {
                    mode = 8;
                    buf.setLength(0);
                } else {
                    res.next = val;
                }
                continue;
            }
            if (key.equals("DIAGNOSIS") || key.equals("CAUSE") || key.equals("HYPOTHESIS")) {
                if (val.length() == 0) {
                    mode = 9;
                    buf.setLength(0);
                } else {
                    res.diagnosis = (res.diagnosis + "\n" + val).trim();
                }
                continue;
            }
            if (key.equals("WARN") || key.equals("WARNING") || key.equals("INFO")
                    || key.equals("RISK") || key.equals("ERROR")) {
                if (val.length() > 0) res.warnings.add(val);
                continue;
            }
            if (cur == null) continue;

            if (key.equals("ACTION") || key.equals("OP") || key.equals("TYPE")) {
                cur.kind = Action.kindFrom(val);
            } else if (key.equals("PATH") || key.equals("FILE_PATH")) {
                cur.path = Utils.normPath(val);
            } else if (key.equals("TARGET") || key.equals("NEW_PATH") || key.equals("DEST")) {
                cur.target = Utils.normPath(val);
            } else if (key.equals("TO")) {
                int n = toInt(val);
                if (n > 0) cur.toLine = n;
                else cur.target = Utils.normPath(val);
            } else if (key.equals("LANG") || key.equals("LANGUAGE")) {
                cur.lang = val;
            } else if (key.equals("FORMAT") || key.equals("IMG_FORMAT")
                    || key.equals("AUDIO_FORMAT") || key.equals("ASSET_FORMAT")
                    || key.equals("MEDIA_FORMAT") || key.equals("ENCODING")) {
                cur.format = val;
            } else if (key.equals("NOTE") || key.equals("DESC") || key.equals("DESCRIPTION")) {
                if (val.length() == 0) {
                    mode = 6;
                    buf.setLength(0);
                } else {
                    cur.note = val;
                }
            } else if (key.equals("FROM_LINE") || key.equals("LINE_FROM") || key.equals("START_LINE")) {
                cur.fromLine = toInt(val);
            } else if (key.equals("TO_LINE") || key.equals("LINE_TO") || key.equals("END_LINE")) {
                cur.toLine = toInt(val);
            } else if (key.equals("AFTER_LINE")) {
                cur.afterLine = toInt(val);
            } else if (key.equals("ANCHOR")) {
                cur.anchor = val;
            } else if (key.equals("LINES") || key.equals("RANGE")) {
                int[] r = parseRange(val);
                if (r != null) {
                    cur.fromLine = r[0];
                    cur.toLine = r[1];
                }
            } else if (key.equals("CODE_START") || key.equals("CONTENT_START")
                    || key.equals("BEGIN_CONTENT") || key.equals("SPEC_START")
                    || key.equals("ASSET_START")) {
                mode = 1;
                buf.setLength(0);
                wantFence = true;
            } else if (key.equals("FIND_START") || key.equals("SEARCH_START")) {
                mode = 2;
                buf.setLength(0);
                wantFence = true;
            } else if (key.equals("REPLACE_START") || key.equals("REPLACE_WITH_START")) {
                mode = 3;
                buf.setLength(0);
                wantFence = true;
            } else if (key.equals("EDIT_START")) {
                mode = 0;
            } else if (key.equals("STATUS") || key.equals("FILE_STATUS")) {
                cur.status = val.toUpperCase();
            } else if (key.equals("END_FILE")) {
                push(res, cur);
                cur = null;
                mode = 0;
            }
        }

        if (mode == 1 && cur != null) {
            cur.content = cleanBody(buf.toString(), cur);
            cur.status = "INCOMPLETE";
            res.truncated = true;
            res.warnings.add("La respuesta se corto dentro del archivo: " + cur.path);
        }
        if (cur != null) push(res, cur);
        if (res.actions.size() == 0 && hasFence(text)) fallbackMarkdown(text, res);
        for (int i = 0; i < res.actions.size(); i++) {
            Action a = res.actions.get(i);
            if (a.isRange() && !a.validRange()) {
                res.warnings.add("Rango de lineas dudoso en " + a.path + " (" + a.rangeLabel() + ")");
            }
            String v = a.isAsset() ? AssetFactory.validate(a) : "";
            if (v.length() > 0) res.warnings.add("Asset " + a.path + ": " + v);
        }
        return res;
    }

    private static void push(Result res, Action a) {
        if (a == null) return;
        if (a.path.length() == 0) {
            res.warnings.add("Bloque sin @@PM_PATH ignorado");
            return;
        }
        if (a.kind == Action.UNKNOWN) {
            if (AssetFactory.isImagePath(a.path) && a.format.length() > 0) a.kind = Action.CREATE_IMAGE;
            else if (AssetFactory.isAudioPath(a.path) && a.format.length() > 0) a.kind = Action.CREATE_AUDIO;
            else if (a.afterLine > 0) a.kind = Action.INSERT_AFTER;
            else if (a.fromLine > 0 || a.toLine > 0) a.kind = Action.EDIT_RANGE;
            else if (a.edits.size() > 0) a.kind = Action.EDIT;
            else a.kind = Action.CREATE;
        }
        if (a.kind == Action.EDIT_RANGE) {
            if (a.fromLine <= 0 && a.afterLine > 0) a.fromLine = a.afterLine + 1;
            if (a.toLine < a.fromLine) a.toLine = a.fromLine;
        }
        if (a.kind == Action.INSERT_AFTER && a.afterLine <= 0 && a.fromLine > 0) {
            a.afterLine = a.fromLine;
        }
        if (a.kind == Action.DELETE_LINES && a.toLine < a.fromLine) a.toLine = a.fromLine;
        if (a.kind == Action.EDIT && a.edits.isEmpty() && a.content.length() > 0) a.kind = Action.REPLACE;
        if (a.incomplete()) res.truncated = true;
        res.actions.add(a);
    }

    private static String cleanBody(String s, Action a) {
        String out = stripFenceTail(s);
        if (a != null && (a.kind == Action.EDIT_RANGE || a.kind == Action.INSERT_AFTER)) {
            out = stripLineNumbers(out);
        }
        return out;
    }

    private static void addNonEmpty(List<String> out, String block) {
        List<String> ls = Utils.splitLines(block);
        for (int i = 0; i < ls.size(); i++) {
            String s = ls.get(i).trim();
            if (s.length() > 0) out.add(s);
        }
    }

    private static String stripFenceTail(String s) {
        if (s == null) return "";
        List<String> ls = Utils.splitLines(s);
        while (ls.size() > 0 && ls.get(ls.size() - 1).trim().length() == 0) ls.remove(ls.size() - 1);
        if (ls.size() > 0 && isFence(ls.get(ls.size() - 1).trim())) ls.remove(ls.size() - 1);
        if (ls.size() > 0 && isFence(ls.get(0).trim())) ls.remove(0);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ls.size(); i++) sb.append(ls.get(i)).append("\n");
        return sb.toString();
    }

    public static String stripLineNumbers(String s) {
        List<String> ls = Utils.splitLines(s);
        int total = 0;
        int hit = 0;
        int last = 0;
        boolean ordered = true;
        for (int i = 0; i < ls.size(); i++) {
            String t = ls.get(i);
            if (t.trim().length() == 0) continue;
            total++;
            Matcher m = NUMLINE.matcher(t);
            if (m.find()) {
                hit++;
                int n = toInt(m.group(1));
                if (n < last) ordered = false;
                last = n;
            }
        }
        if (total == 0 || hit < total || !ordered) return s;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ls.size(); i++) {
            Matcher m = NUMLINE.matcher(ls.get(i));
            if (m.find()) sb.append(ls.get(i).substring(m.end()));
            else sb.append(ls.get(i));
            sb.append("\n");
        }
        return sb.toString();
    }

    private static int toInt(String s) {
        if (s == null) return 0;
        String v = s.trim();
        int i = 0;
        while (i < v.length() && !Character.isDigit(v.charAt(i))) i++;
        int j = i;
        while (j < v.length() && Character.isDigit(v.charAt(j))) j++;
        if (j <= i) return 0;
        try {
            return Integer.parseInt(v.substring(i, j));
        } catch (Exception e) {
            return 0;
        }
    }

    private static int[] parseRange(String s) {
        if (s == null) return null;
        Matcher m = RANGEVAL.matcher(s);
        if (m.find()) return new int[]{toInt(m.group(1)), toInt(m.group(2))};
        int n = toInt(s);
        return n > 0 ? new int[]{n, n} : null;
    }

    private static String clean(String line) {
        String s = line == null ? "" : line.trim();
        if (s.startsWith("<!--")) s = s.substring(4);
        if (s.endsWith("-->")) s = s.substring(0, s.length() - 3);
        if (s.startsWith("/*")) s = s.substring(2);
        if (s.endsWith("*/")) s = s.substring(0, s.length() - 2);
        if (s.startsWith("//")) s = s.substring(2);
        if (s.startsWith("#") && s.indexOf("PM_") >= 0) s = s.substring(1);
        s = s.trim();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '@' || c == '#' || c == '>' || c == '*' || c == BT || c == ' '
                    || c == '\t' || c == ':' || c == '-') i++;
            else break;
        }
        return s.substring(i).trim();
    }

    private static String markerKey(String line) {
        String s = clean(line);
        if (s.length() < 5) return null;
        Matcher m = PAT.matcher(s);
        if (m.find() && m.start() <= 2) {
            String k = m.group(1).toUpperCase();
            return KEYS.contains(k) ? k : null;
        }
        return null;
    }

    private static String markerVal(String line) {
        String s = clean(line);
        Matcher m = PAT.matcher(s);
        if (m.find() && m.start() <= 2) {
            String v = m.group(2);
            return v == null ? "" : v.trim();
        }
        return "";
    }

    private static void fallbackMarkdown(String text, Result res) {
        res.usedFallback = true;
        res.warnings.add("Sin marcadores @@PM: se han detectado bloques de codigo con su ruta.");
        String[] lines = text.replace("\r\n", "\n").split("\n", -1);
        int i = 0;
        while (i < lines.length) {
            String t = lines[i].trim();
            if (isFence(t)) {
                String lang = t.substring(3).trim();
                StringBuilder body = new StringBuilder();
                int j = i + 1;
                while (j < lines.length && !isFence(lines[j].trim())) {
                    body.append(lines[j]).append("\n");
                    j++;
                }
                String path = pathNear(lines, i, j);
                if (path != null && body.length() > 0) {
                    Action a = new Action();
                    a.kind = Action.CREATE;
                    a.path = path;
                    a.lang = lang;
                    a.content = body.toString();
                    a.note = "detectado desde bloque markdown";
                    res.actions.add(a);
                }
                i = j + 1;
            } else {
                i++;
            }
        }
    }

    private static String pathNear(String[] lines, int start, int end) {
        for (int k = start - 1; k >= 0 && k >= start - 3; k--) {
            String p = pickPath(lines[k]);
            if (p != null) return p;
        }
        for (int k = end + 1; k < lines.length && k <= end + 2; k++) {
            String p = pickPath(lines[k]);
            if (p != null) return p;
        }
        return null;
    }

    private static String pickPath(String line) {
        if (line == null || line.length() > 160) return null;
        Matcher m = PATHY.matcher(line);
        if (m.find()) {
            String p = Utils.normPath(m.group(1));
            if (Utils.isSafePath(p) && (p.indexOf('/') >= 0 || p.indexOf('.') > 0)) return p;
        }
        return null;
    }
}
