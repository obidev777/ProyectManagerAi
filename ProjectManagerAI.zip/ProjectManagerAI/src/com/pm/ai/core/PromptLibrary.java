package com.pm.ai.core;

import android.content.Context;
import com.pm.ai.util.Utils;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Historial global de prompts generados: listar, buscar, editar, renombrar,
 * duplicar y borrar. Se guarda en <raiz>/.pm_library/prompts/<id>.json
 */
public class PromptLibrary {

    public static class Entry {
        public String id = "";
        public String title = "";
        public String project = "";
        public String mode = "";
        public long created = 0L;
        public long updated = 0L;
        public int chars = 0;
        public String preview = "";
        public File file;
    }

    public static File dir(Context c) {
        File f = new File(Storage.get(c).libraryDir(), "prompts");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public static String newId() {
        return Utils.stamp() + "_" + (int) (System.currentTimeMillis() % 10000);
    }

    private static String nameOf(File f) {
        String n = f.getName();
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(0, i) : n;
    }

    private static String preview(String content) {
        List<String> ls = Utils.splitLines(content);
        StringBuilder s = new StringBuilder();
        int n = 0;
        for (int i = 0; i < ls.size() && n < 3; i++) {
            String t = ls.get(i).trim();
            if (t.length() == 0) continue;
            if (s.length() > 0) s.append("  |  ");
            s.append(t);
            n++;
        }
        return s.length() > 220 ? s.substring(0, 220) + "..." : s.toString();
    }

    public static String defaultTitle(String mode, String content) {
        String base = PromptBuilder.modeLabel(mode);
        String t = Utils.firstLine(content, 44);
        return t.length() == 0 ? base : base + " - " + t;
    }

    public static Entry load(File f) {
        try {
            String raw = Utils.readText(f);
            if (raw.trim().length() == 0) return null;
            JSONObject o = new JSONObject(raw);
            Entry e = new Entry();
            e.file = f;
            e.id = o.optString("id", nameOf(f));
            e.project = o.optString("project", "");
            e.mode = o.optString("mode", "");
            e.created = o.optLong("created", f.lastModified());
            e.updated = o.optLong("updated", e.created);
            String content = o.optString("content", "");
            e.chars = o.optInt("chars", content.length());
            e.title = o.optString("title", "");
            if (e.title.length() == 0) e.title = defaultTitle(e.mode, content);
            e.preview = preview(content);
            return e;
        } catch (Throwable t) {
            return null;
        }
    }

    public static List<Entry> all(Context c) {
        List<Entry> out = new ArrayList<Entry>();
        File[] kids = dir(c).listFiles();
        if (kids == null) return out;
        for (int i = 0; i < kids.length; i++) {
            if (!kids[i].getName().endsWith(".json")) continue;
            Entry e = load(kids[i]);
            if (e != null) out.add(e);
        }
        Collections.sort(out, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                if (a.updated < b.updated) return 1;
                if (a.updated > b.updated) return -1;
                return b.id.compareTo(a.id);
            }
        });
        return out;
    }

    public static List<String> projects(Context c) {
        List<Entry> all = all(c);
        List<String> out = new ArrayList<String>();
        for (int i = 0; i < all.size(); i++) {
            String p = all.get(i).project;
            if (p.length() > 0 && !out.contains(p)) out.add(p);
        }
        Collections.sort(out);
        return out;
    }

    public static Entry get(Context c, String id) {
        if (id == null || id.length() == 0) return null;
        File f = new File(dir(c), id + ".json");
        return f.isFile() ? load(f) : null;
    }

    public static String content(Context c, String id) {
        Entry e = get(c, id);
        if (e == null || e.file == null) return "";
        try {
            return new JSONObject(Utils.readText(e.file)).optString("content", "");
        } catch (Throwable t) {
            return "";
        }
    }

    public static Entry save(Context c, String id, String title, String project,
                             String mode, String content) {
        String useId = id == null || id.length() == 0 ? newId() : id;
        File f = new File(dir(c), useId + ".json");
        long created = System.currentTimeMillis();
        try {
            if (f.isFile()) created = new JSONObject(Utils.readText(f)).optLong("created", created);
        } catch (Throwable t) {
            // ignorado
        }
        String body = content == null ? "" : content;
        JSONObject o = new JSONObject();
        try {
            o.put("id", useId);
            o.put("title", title == null || title.length() == 0 ? defaultTitle(mode, body) : title);
            o.put("project", project == null ? "" : project);
            o.put("mode", mode == null ? "" : mode);
            o.put("created", created);
            o.put("updated", System.currentTimeMillis());
            o.put("chars", body.length());
            o.put("content", body);
        } catch (Throwable t) {
            // ignorado
        }
        Utils.writeText(f, o.toString());
        return load(f);
    }

    public static boolean update(Context c, String id, String title, String content) {
        Entry e = get(c, id);
        if (e == null) return false;
        return save(c, id, title, e.project, e.mode, content) != null;
    }

    public static boolean rename(Context c, String id, String title) {
        Entry e = get(c, id);
        if (e == null) return false;
        return save(c, id, title, e.project, e.mode, content(c, id)) != null;
    }

    public static Entry duplicate(Context c, String id) {
        Entry e = get(c, id);
        if (e == null) return null;
        return save(c, "", e.title + " (copia)", e.project, e.mode, content(c, id));
    }

    public static boolean delete(Context c, String id) {
        File f = new File(dir(c), id + ".json");
        return f.isFile() && f.delete();
    }

    public static int deleteAll(Context c) {
        File[] kids = dir(c).listFiles();
        if (kids == null) return 0;
        int n = 0;
        for (int i = 0; i < kids.length; i++) {
            if (kids[i].getName().endsWith(".json") && kids[i].delete()) n++;
        }
        return n;
    }

    public static int count(Context c) {
        return all(c).size();
    }
}
