package com.pm.ai.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import com.pm.ai.util.Utils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Genera imagenes REALES dentro de la app, a partir de comandos del modelo.
 * Formatos de entrada: SPEC (JSON dibujable), VECTOR (path data), SVG y BASE64.
 * Formatos de salida: png, jpg/jpeg, webp, svg (texto) y xml (VectorDrawable).
 */
public class ImageGen {

    public static class Out {
        public boolean ok = false;
        public String msg = "";
        public int w = 0;
        public int h = 0;
    }

    private static final Pattern P_NUM = Pattern.compile("(-?\\d+(?:\\.\\d+)?)");
    private static final Pattern P_PATH = Pattern.compile("<path[^>]*?/>", Pattern.DOTALL);
    private static final Pattern P_CIRCLE = Pattern.compile("<circle[^>]*?/>", Pattern.DOTALL);
    private static final Pattern P_RECT = Pattern.compile("<rect[^>]*?/>", Pattern.DOTALL);

    public static Out create(File outFile, String format, String body, String relPath) {
        Out o = new Out();
        try {
            String fmt = format == null ? "" : format.trim().toUpperCase();
            String ext = extOf(outFile.getName());
            String content = AssetFactory.stripFences(body);
            if (fmt.length() == 0) fmt = guessFormat(content, ext);

            if (fmt.equals("BASE64") || fmt.equals("B64")) {
                byte[] data = AssetFactory.decodeBase64(content);
                if (data.length == 0) {
                    o.msg = "base64 vacio o invalido";
                    return o;
                }
                AssetFactory.writeBytes(outFile, data);
                o.ok = true;
                o.msg = data.length + " bytes binarios";
                return o;
            }
            if (fmt.equals("SPEC") || fmt.equals("JSON")) {
                JSONObject spec = new JSONObject(content);
                Bitmap bm = renderSpec(spec);
                o.w = bm.getWidth();
                o.h = bm.getHeight();
                o.ok = saveBitmap(outFile, bm, ext);
                bm.recycle();
                o.msg = o.w + "x" + o.h + " " + ext;
                return o;
            }
            if (fmt.equals("VECTOR")) {
                if (ext.equals("xml")) {
                    Utils.writeText(outFile, vectorXml(content));
                    o.ok = true;
                    o.msg = "VectorDrawable xml";
                } else {
                    Bitmap bm = rasterVector(content, 256);
                    o.w = bm.getWidth();
                    o.h = bm.getHeight();
                    o.ok = saveBitmap(outFile, bm, ext);
                    bm.recycle();
                    o.msg = o.w + "x" + o.h + " " + ext;
                }
                return o;
            }
            if (fmt.equals("SVG")) {
                if (ext.equals("svg")) {
                    Utils.writeText(outFile, content);
                    o.ok = true;
                    o.msg = content.length() + " caracteres svg";
                } else if (ext.equals("xml")) {
                    Utils.writeText(outFile, svgToVector(content));
                    o.ok = true;
                    o.msg = "svg -> VectorDrawable";
                } else {
                    Bitmap bm = rasterSvg(content, 512);
                    o.w = bm.getWidth();
                    o.h = bm.getHeight();
                    o.ok = saveBitmap(outFile, bm, ext);
                    bm.recycle();
                    o.msg = o.w + "x" + o.h + " " + ext;
                }
                return o;
            }
            Utils.writeText(outFile, content);
            o.ok = true;
            o.msg = "texto/" + ext;
        } catch (Throwable t) {
            o.msg = t.getClass().getSimpleName() + ": " + t.getMessage();
        }
        return o;
    }

    public static String extOf(String name) {
        int i = name == null ? -1 : name.lastIndexOf('.');
        return i < 0 ? "png" : name.substring(i + 1).toLowerCase();
    }

    private static String guessFormat(String body, String ext) {
        String t = body == null ? "" : body.trim();
        if (t.startsWith("{") || t.startsWith("[")) return "SPEC";
        if (t.startsWith("<svg") || t.indexOf("<svg") >= 0) return "SVG";
        if (ext.equals("svg")) return "SVG";
        if (ext.equals("xml")) return "VECTOR";
        if (t.length() > 60 && t.replaceAll("[A-Za-z0-9+/=\\s]", "").length() == 0) return "BASE64";
        return "VECTOR";
    }

    public static boolean saveBitmap(File f, Bitmap bm, String ext) {
        Bitmap.CompressFormat fmt = Bitmap.CompressFormat.PNG;
        if (ext.equals("jpg") || ext.equals("jpeg")) fmt = Bitmap.CompressFormat.JPEG;
        else if (ext.equals("webp")) fmt = Bitmap.CompressFormat.WEBP;
        FileOutputStream fos = null;
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            fos = new FileOutputStream(f);
            return bm.compress(fmt, 95, fos);
        } catch (Throwable t) {
            return false;
        } finally {
            Utils.close(fos);
        }
    }

    /** Miniatura para la lista de acciones. */
    public static Bitmap thumb(String absPath, int px) {
        try {
            File f = new File(absPath);
            if (!f.isFile()) return null;
            BitmapFactory.Options op = new BitmapFactory.Options();
            op.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(absPath, op);
            int sample = 1;
            while (op.outWidth / sample > px * 2 || op.outHeight / sample > px * 2) sample *= 2;
            BitmapFactory.Options op2 = new BitmapFactory.Options();
            op2.inSampleSize = sample;
            return BitmapFactory.decodeFile(absPath, op2);
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ SPEC
    public static Bitmap renderSpec(JSONObject spec) throws Exception {
        int w = spec.optInt("w", 512);
        int h = spec.optInt("h", 512);
        w = Math.max(1, Math.min(2048, w));
        h = Math.max(1, Math.min(2048, h));
        Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Object bg = spec.opt("bg");
        if (bg != null) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            applyFill(p, bg, w, h, 0, 0, w, h);
            c.drawRect(0, 0, w, h, p);
        }
        JSONArray shapes = spec.optJSONArray("shapes");
        if (shapes == null) shapes = new JSONArray();
        for (int i = 0; i < shapes.length(); i++) {
            JSONObject sh = shapes.optJSONObject(i);
            if (sh != null) drawShape(c, sh, w, h);
        }
        return bm;
    }

    private static float dim(JSONObject o, String key, float frac, float total) {
        double v = o.optDouble(key, Double.NaN);
        if (Double.isNaN(v)) v = 0;
        if (Math.abs(v) <= 1.0) return (float) (v * total);
        return (float) v;
    }

    private static void drawShape(Canvas c, JSONObject sh, int W, int H) {
        String type = sh.optString("type", "rect");
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL);
        float alpha = (float) sh.optDouble("alpha", 1.0);
        paint.setAlpha((int) (Math.max(0, Math.min(1, alpha)) * 255));
        Object fill = sh.opt("fill");
        Object stroke = sh.opt("stroke");
        float sw = (float) sh.optDouble("strokeWidth", 0);
        if (sw <= 0) sw = (float) sh.optDouble("stroke_width", 0);
        RectF box = new RectF();
        if (type.equals("circle")) {
            float cx = dim(sh, "cx", 0.5f, W);
            float cy = dim(sh, "cy", 0.5f, H);
            float r = dim(sh, "r", 0.1f, Math.min(W, H));
            box.set(cx - r, cy - r, cx + r, cy + r);
        } else if (type.equals("ellipse")) {
            float cx = dim(sh, "cx", 0.5f, W);
            float cy = dim(sh, "cy", 0.5f, H);
            float rx = dim(sh, "rx", 0.1f, W);
            float ry = dim(sh, "ry", 0.1f, H);
            box.set(cx - rx, cy - ry, cx + rx, cy + ry);
        } else {
            float x = dim(sh, "x", 0f, W);
            float y = dim(sh, "y", 0f, H);
            float wd = sh.has("w") ? dim(sh, "w", 1f, W) : dim(sh, "width", 1f, W);
            float hh = sh.has("h") ? dim(sh, "h", 1f, H) : dim(sh, "height", 1f, H);
            box.set(x, y, x + wd, y + hh);
        }
        if (type.equals("text")) {
            String txt = sh.optString("text", "");
            float size = dim(sh, "size", 0.1f, H);
            if (size <= 0) size = H * 0.1f;
            paint.setTextSize(size);
            paint.setColor(parseColor(sh.opt("color"), 0xFFFFFFFF));
            boolean bold = sh.optBoolean("bold", false);
            String fam = sh.optString("font", "sans");
            paint.setTypeface(fam.equals("mono") || fam.equals("monospace")
                    ? Typeface.MONOSPACE
                    : (bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT));
            String align = sh.optString("align", "center");
            float tx = dim(sh, "x", 0.5f, W);
            float ty = dim(sh, "y", 0.5f, H);
            float tw = paint.measureText(txt);
            if (align.equals("center")) tx -= tw / 2f;
            else if (align.equals("right")) tx -= tw;
            if (!sh.has("baseline")) ty += size * 0.35f;
            c.drawText(txt, tx, ty, paint);
            return;
        }
        if (type.equals("line")) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(sw > 0 ? sw : Math.max(1f, W / 200f));
            paint.setColor(parseColor(stroke != null ? stroke : fill, 0xFFFFFFFF));
            paint.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(box.left, box.top, box.right, box.bottom, paint);
            return;
        }
        if (type.equals("path")) {
            String d = sh.optString("d", "");
            float vp = (float) sh.optDouble("viewport", 24);
            if (vp <= 0) vp = 24f;
            Path path = PathParser.parse(d);
            float kx = W / vp;
            float ky = H / vp;
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.setScale(kx, ky);
            Path scaled = new Path();
            path.transform(m, scaled);
            if (fill != null && !isNone(fill)) {
                paint.setStyle(Paint.Style.FILL);
                applyFill(paint, fill, W, H, box.left, box.top, box.width(), box.height());
                c.drawPath(scaled, paint);
            }
            if (stroke != null && !isNone(stroke)) {
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                sp.setStyle(Paint.Style.STROKE);
                sp.setStrokeCap(Paint.Cap.ROUND);
                sp.setStrokeJoin(Paint.Join.ROUND);
                sp.setStrokeWidth((sw > 0 ? sw : 1.9f) * Math.max(kx, ky));
                sp.setColor(parseColor(stroke, 0xFFFFFFFF));
                sp.setAlpha((int) (Math.max(0, Math.min(1, alpha)) * 255));
                c.drawPath(scaled, sp);
            }
            return;
        }
        if (fill != null && !isNone(fill)) {
            paint.setStyle(Paint.Style.FILL);
            applyFill(paint, fill, W, H, box.left, box.top, box.width(), box.height());
            if (type.equals("circle") || type.equals("ellipse")) c.drawOval(box, paint);
            else if (type.equals("rrect") || type.equals("roundrect")) {
                float r = dim(sh, "r", 0.1f, Math.min(box.width(), box.height()));
                c.drawRoundRect(box, r, r, paint);
            } else c.drawRect(box, paint);
        }
        if (stroke != null && !isNone(stroke)) {
            Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeWidth(sw > 0 ? sw : Math.max(1f, W / 200f));
            sp.setColor(parseColor(stroke, 0xFFFFFFFF));
            sp.setAlpha((int) (Math.max(0, Math.min(1, alpha)) * 255));
            if (type.equals("circle") || type.equals("ellipse")) c.drawOval(box, sp);
            else if (type.equals("rrect") || type.equals("roundrect")) {
                float r = dim(sh, "r", 0.1f, Math.min(box.width(), box.height()));
                c.drawRoundRect(box, r, r, sp);
            } else c.drawRect(box, sp);
        }
    }

    private static boolean isNone(Object v) {
        return v == null || "none".equals(String.valueOf(v)) || "transparent".equals(String.valueOf(v));
    }

    private static void applyFill(Paint p, Object fill, int W, int H,
                                  float x, float y, float w, float h) {
        if (fill instanceof JSONObject) {
            JSONObject g = (JSONObject) fill;
            String type = g.optString("type", "linear");
            JSONArray cols = g.optJSONArray("colors");
            int[] cs = new int[Math.max(2, cols == null ? 2 : cols.length())];
            if (cols == null || cols.length() < 2) {
                cs = new int[]{0xFF7C5CFF, 0xFF22D3EE};
            } else {
                cs = new int[cols.length()];
                for (int i = 0; i < cols.length(); i++) cs[i] = parseColor(cols.opt(i), 0xFFFFFFFF);
            }
            if (type.equals("radial")) {
                float cx = x + w / 2f;
                float cy = y + h / 2f;
                float r = Math.max(w, h) / 2f;
                p.setShader(new RadialGradient(cx, cy, r <= 0 ? 1 : r, cs, null, Shader.TileMode.CLAMP));
            } else {
                double ang = Math.toRadians(g.optDouble("angle", 135));
                float dx = (float) Math.cos(ang);
                float dy = (float) Math.sin(ang);
                p.setShader(new LinearGradient(x, y, x + w * dx, y + h * dy, cs, null,
                        Shader.TileMode.CLAMP));
            }
            p.setColor(0xFFFFFFFF);
            return;
        }
        p.setShader(null);
        p.setColor(parseColor(fill, 0xFFFFFFFF));
    }

    public static int parseColor(Object v, int def) {
        if (v == null) return def;
        if (v instanceof Integer) return ((Integer) v).intValue();
        String s = String.valueOf(v).trim();
        if (s.length() == 0 || s.equals("none")) return def;
        try {
            if (s.startsWith("#")) {
                if (s.length() == 4) {
                    s = "#FF" + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2)
                            + s.charAt(3) + s.charAt(3);
                } else if (s.length() == 7) {
                    s = "#FF" + s.substring(1);
                }
                return Color.parseColor(s.toUpperCase());
            }
            return Color.parseColor(s);
        } catch (Throwable t) {
            return def;
        }
    }

    // ---------------------------------------------------------------- VECTOR
    /** path data por linea; prefijos S: (stroke), F: (fill), M: (mixto). */
    public static String vectorXml(String body) {
        StringBuilder x = new StringBuilder();
        x.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        x.append("<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"\n");
        x.append("    android:width=\"24dp\" android:height=\"24dp\"\n");
        x.append("    android:viewportWidth=\"24\" android:viewportHeight=\"24\">\n");
        java.util.List<String> ls = Utils.splitLines(body);
        for (int i = 0; i < ls.size(); i++) {
            String line = ls.get(i).trim();
            if (line.length() == 0) continue;
            if (line.startsWith("W:")) continue;
            String d = line;
            String stroke = "#FFFFFF";
            String fill = "#00000000";
            if (line.startsWith("S:")) d = line.substring(2).trim();
            else if (line.startsWith("F:")) {
                d = line.substring(2).trim();
                fill = "#FFFFFF";
                stroke = "#00000000";
            } else if (line.startsWith("M:")) {
                d = line.substring(2).trim();
                fill = "#FFFFFF";
            }
            x.append("    <path android:pathData=\"").append(d).append("\"");
            x.append(" android:fillColor=\"").append(fill).append("\"");
            if (!fill.equals("#FFFFFF") || stroke.equals("#FFFFFF")) {
                x.append(" android:strokeColor=\"").append(stroke).append("\"");
                x.append(" android:strokeWidth=\"1.9\"");
                x.append(" android:strokeLineCap=\"round\" android:strokeLineJoin=\"round\"");
            }
            x.append(" />\n");
        }
        x.append("</vector>\n");
        return x.toString();
    }

    public static Bitmap rasterVector(String body, int size) {
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        float k = size / 24f;
        java.util.List<String> ls = Utils.splitLines(body);
        for (int i = 0; i < ls.size(); i++) {
            String line = ls.get(i).trim();
            if (line.length() == 0 || line.startsWith("W:")) continue;
            boolean fillIt = line.startsWith("F:") || line.startsWith("M:");
            boolean strokeIt = !line.startsWith("F:");
            String d = line.length() > 2 && line.charAt(1) == ':' ? line.substring(2) : line;
            Path path = PathParser.parse(d);
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.setScale(k, k);
            Path sc = new Path();
            path.transform(m, sc);
            if (fillIt) {
                Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
                fp.setColor(0xFFFFFFFF);
                fp.setStyle(Paint.Style.FILL);
                c.drawPath(sc, fp);
            }
            if (strokeIt) {
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                sp.setColor(0xFFFFFFFF);
                sp.setStyle(Paint.Style.STROKE);
                sp.setStrokeWidth(1.9f * k);
                sp.setStrokeCap(Paint.Cap.ROUND);
                sp.setStrokeJoin(Paint.Join.ROUND);
                c.drawPath(sc, sp);
            }
        }
        return bm;
    }

    // ------------------------------------------------------------------- SVG
    public static String svgToVector(String svg) {
        StringBuilder x = new StringBuilder();
        x.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        x.append("<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"\n");
        x.append("    android:width=\"24dp\" android:height=\"24dp\"\n");
        x.append("    android:viewportWidth=\"24\" android:viewportHeight=\"24\">\n");
        Matcher mp = P_PATH.matcher(svg == null ? "" : svg);
        while (mp.find()) {
            String tag = mp.group();
            String d = attr(tag, "d");
            String fill = attr(tag, "fill");
            String stroke = attr(tag, "stroke");
            String sw = attr(tag, "stroke-width");
            if (d.length() == 0) continue;
            x.append("    <path android:pathData=\"").append(d.replace("\"", "")).append("\"");
            x.append(" android:fillColor=\"").append(fill.length() == 0 || "none".equals(fill)
                    ? "#00000000" : fill).append("\"");
            if (stroke.length() > 0 && !"none".equals(stroke)) {
                x.append(" android:strokeColor=\"").append(stroke).append("\"");
                x.append(" android:strokeWidth=\"").append(sw.length() == 0 ? "1" : sw).append("\"");
                x.append(" android:strokeLineCap=\"round\" android:strokeLineJoin=\"round\"");
            }
            x.append(" />\n");
        }
        x.append("</vector>\n");
        return x.toString();
    }

    public static Bitmap rasterSvg(String svg, int size) {
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        float vp = 24f;
        String vb = attr(svg, "viewBox");
        java.util.List<String> ns = nums(vb);
        if (ns.size() >= 4) vp = Float.parseFloat(ns.get(2));
        if (vp <= 0) vp = 24f;
        float k = size / vp;
        Matcher mp = P_PATH.matcher(svg == null ? "" : svg);
        while (mp.find()) {
            String tag = mp.group();
            String d = attr(tag, "d");
            if (d.length() == 0) continue;
            Path sc = new Path();
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.setScale(k, k);
            PathParser.parse(d).transform(m, sc);
            String fill = attr(tag, "fill");
            String stroke = attr(tag, "stroke");
            String sw = attr(tag, "stroke-width");
            if (fill.length() > 0 && !"none".equals(fill)) {
                Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
                fp.setStyle(Paint.Style.FILL);
                fp.setColor(parseColor(fill, 0xFFFFFFFF));
                c.drawPath(sc, fp);
            }
            if (stroke.length() > 0 && !"none".equals(stroke)) {
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                sp.setStyle(Paint.Style.STROKE);
                sp.setStrokeCap(Paint.Cap.ROUND);
                sp.setStrokeJoin(Paint.Join.ROUND);
                float w = 1.9f;
                java.util.List<String> wn = nums(sw);
                if (wn.size() > 0) w = Float.parseFloat(wn.get(0));
                sp.setStrokeWidth(w * k);
                sp.setColor(parseColor(stroke, 0xFFFFFFFF));
                c.drawPath(sc, sp);
            }
        }
        Matcher mc = P_CIRCLE.matcher(svg == null ? "" : svg);
        while (mc.find()) {
            String tag = mc.group();
            java.util.List<String> cx = nums(attr(tag, "cx"));
            java.util.List<String> cy = nums(attr(tag, "cy"));
            java.util.List<String> r = nums(attr(tag, "r"));
            if (cx.size() == 0 || cy.size() == 0 || r.size() == 0) continue;
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(parseColor(attr(tag, "fill"), 0xFFFFFFFF));
            c.drawCircle(Float.parseFloat(cx.get(0)) * k, Float.parseFloat(cy.get(0)) * k,
                    Float.parseFloat(r.get(0)) * k, p);
        }
        Matcher mr = P_RECT.matcher(svg == null ? "" : svg);
        while (mr.find()) {
            String tag = mr.group();
            java.util.List<String> x = nums(attr(tag, "x"));
            java.util.List<String> y = nums(attr(tag, "y"));
            java.util.List<String> w = nums(attr(tag, "width"));
            java.util.List<String> h = nums(attr(tag, "height"));
            if (x.size() == 0 || y.size() == 0 || w.size() == 0 || h.size() == 0) continue;
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(parseColor(attr(tag, "fill"), 0xFFFFFFFF));
            c.drawRect(Float.parseFloat(x.get(0)) * k, Float.parseFloat(y.get(0)) * k,
                    (Float.parseFloat(x.get(0)) + Float.parseFloat(w.get(0))) * k,
                    (Float.parseFloat(y.get(0)) + Float.parseFloat(h.get(0))) * k, p);
        }
        return bm;
    }

    private static String attr(String tag, String name) {
        Matcher m = Pattern.compile(name + "\\s*=\\s*\"([^\"]*)\"").matcher(tag == null ? "" : tag);
        return m.find() ? m.group(1).trim() : "";
    }

    private static java.util.List<String> nums(String s) {
        java.util.List<String> out = new java.util.ArrayList<String>();
        Matcher m = P_NUM.matcher(s == null ? "" : s);
        while (m.find()) out.add(m.group(1));
        return out;
    }
}
