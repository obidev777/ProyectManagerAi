package com.pm.ai.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Portada (imagen) por proyecto y conversion de esa imagen en el icono real
 * de la app para compilar en AIDE.
 */
public class CoverManager {

    private static final String[] CAND = {
            "img/cover.png", "img/cover.jpg", "img/cover.webp", "assets/cover.png",
            "cover.png", "img/logo.png", "img/icon.png", "assets/icon.png"
    };

    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(24);

    public static File coverFile(Project p) {
        if (p == null || p.dir == null) return null;
        if (p.cover != null && p.cover.length() > 0) {
            File f = new File(p.dir, Utils.normPath(p.cover));
            if (f.isFile()) return f;
        }
        return null;
    }

    /** Adopta una portada por defecto si el proyecto ya tiene una imagen conocida. */
    public static void ensure(Storage st, Project p) {
        if (p == null || p.dir == null) return;
        if (coverFile(p) != null) return;
        boolean had = p.cover != null && p.cover.length() > 0;
        p.cover = "";
        for (int i = 0; i < CAND.length; i++) {
            if (new File(p.dir, CAND[i]).isFile()) {
                p.cover = CAND[i];
                st.save(p);
                return;
            }
        }
        if (had) st.save(p);
    }

    public static void ensureAll(Storage st) {
        List<Project> ps = st.list();
        for (int i = 0; i < ps.size(); i++) ensure(st, ps.get(i));
    }

    public static void set(Storage st, Project p, String rel) {
        p.cover = rel == null ? "" : Utils.normPath(rel);
        st.save(p);
    }

    public static void clear(Storage st, Project p) {
        p.cover = "";
        st.save(p);
    }

    /** Miniatura con cache en memoria. */
    public static Bitmap thumb(Project p, int px) {
        File f = coverFile(p);
        if (f == null) return null;
        String key = f.getAbsolutePath() + "|" + px + "|" + f.lastModified();
        Bitmap hit = CACHE.get(key);
        if (hit != null) return hit;
        try {
            BitmapFactory.Options op = new BitmapFactory.Options();
            op.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), op);
            int sample = 1;
            while (op.outWidth / sample > px * 2 || op.outHeight / sample > px * 2) sample *= 2;
            BitmapFactory.Options op2 = new BitmapFactory.Options();
            op2.inSampleSize = sample;
            Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath(), op2);
            if (bm != null) CACHE.put(key, bm);
            return bm;
        } catch (Throwable t) {
            return null;
        }
    }

    public static List<String> imageFiles(Storage st, Project p) {
        List<String> out = new ArrayList<String>();
        List<String> fs = st.files(p);
        for (int i = 0; i < fs.size(); i++) {
            String e = ImageGen.extOf(fs.get(i));
            if (e.equals("png") || e.equals("jpg") || e.equals("jpeg") || e.equals("webp")) {
                out.add(fs.get(i));
            }
        }
        return out;
    }

    /**
     * Escribe la imagen elegida como icono de la app: la escala a las 5
     * densidades (res/mipmap-mdpi a xxxhdpi, ic_launcher.png) y la declara en el Manifest.
     * Al compilar en AIDE, el APK sale con ese icono.
     */
    public static boolean applyAsAppIcon(Storage st, Project p, String rel) {
        File srcFile = st.file(p, rel);
        if (!srcFile.isFile()) return false;
        Bitmap base = BitmapFactory.decodeFile(srcFile.getAbsolutePath());
        if (base == null) return false;
        int[] px = {48, 72, 96, 144, 192};
        String[] names = {"mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"};
        for (int i = 0; i < px.length; i++) {
            Bitmap sc = Bitmap.createScaledBitmap(base, px[i], px[i], true);
            boolean ok = ImageGen.saveBitmap(
                    new File(p.dir, "res/mipmap-" + names[i] + "/ic_launcher.png"), sc, "png");
            if (sc != base) sc.recycle();
            if (!ok) {
                base.recycle();
                return false;
            }
        }
        base.recycle();
        File man = new File(p.dir, "AndroidManifest.xml");
        if (!man.isFile()) return true;
        String txt = Utils.readText(man);
        if (txt.indexOf("android:icon=") >= 0) {
            txt = txt.replaceFirst("android:icon=\"[^\"]*\"", "android:icon=\"@mipmap/ic_launcher\"");
        } else {
            txt = txt.replaceFirst("<application",
                    "<application\n        android:icon=\"@mipmap/ic_launcher\"");
        }
        return Utils.writeText(man, txt);
    }
}
