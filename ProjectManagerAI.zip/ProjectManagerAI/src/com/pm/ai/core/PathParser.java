package com.pm.ai.core;

import android.graphics.Path;

/**
 * Convierte path data de SVG / VectorDrawable a android.graphics.Path.
 * Soporta M L H V C S Q T Z (relativas y absolutas) y aproxima los arcos A.
 */
public class PathParser {

    private String s;
    private int i;
    private int n;

    public static Path parse(String d) {
        return new PathParser(d).run();
    }

    private PathParser(String d) {
        s = d == null ? "" : d;
        n = s.length();
        i = 0;
    }

    private static boolean isCmd(char c) {
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }

    private void skipSep() {
        while (i < n) {
            char c = s.charAt(i);
            if (c == ',' || c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
            else break;
        }
    }

    private boolean hasNum() {
        skipSep();
        if (i >= n) return false;
        char c = s.charAt(i);
        return c == '-' || c == '+' || c == '.' || (c >= '0' && c <= '9');
    }

    private float num() {
        skipSep();
        int start = i;
        if (i < n && (s.charAt(i) == '-' || s.charAt(i) == '+')) i++;
        boolean dot = false;
        while (i < n) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                i++;
            } else if (c == '.' && !dot) {
                dot = true;
                i++;
            } else {
                break;
            }
        }
        if (start == i) return 0f;
        try {
            return Float.parseFloat(s.substring(start, i));
        } catch (Exception e) {
            return 0f;
        }
    }

    private Path run() {
        Path p = new Path();
        float cx = 0f;
        float cy = 0f;
        float sx = 0f;
        float sy = 0f;
        float px = 0f;
        float py = 0f;
        char last = 0;
        while (i < n) {
            skipSep();
            if (i >= n) break;
            char c = s.charAt(i);
            boolean rel = false;
            if (isCmd(c)) {
                i++;
                rel = c >= 'a' && c <= 'z';
                c = Character.toUpperCase(c);
                last = c;
            } else {
                c = last;
                if (c == 0) break;
                if (c == 'M') c = 'L';
            }
            float ox = rel ? cx : 0f;
            float oy = rel ? cy : 0f;
            px = cx;
            py = cy;
            if (c == 'Z') {
                p.close();
                cx = sx;
                cy = sy;
                continue;
            }
            if (!hasNum()) continue;
            if (c == 'M') {
                float x = num() + ox;
                float y = num() + oy;
                p.moveTo(x, y);
                cx = x;
                cy = y;
                sx = x;
                sy = y;
                last = 'L';
            } else if (c == 'L') {
                float x = num() + ox;
                float y = num() + oy;
                p.lineTo(x, y);
                cx = x;
                cy = y;
            } else if (c == 'H') {
                cx = num() + ox;
                p.lineTo(cx, cy);
            } else if (c == 'V') {
                cy = num() + oy;
                p.lineTo(cx, cy);
            } else if (c == 'C') {
                float x1 = num() + ox;
                float y1 = num() + oy;
                float x2 = num() + ox;
                float y2 = num() + oy;
                float x = num() + ox;
                float y = num() + oy;
                p.cubicTo(x1, y1, x2, y2, x, y);
                px = x2;
                py = y2;
                cx = x;
                cy = y;
            } else if (c == 'S') {
                float x1 = 2 * cx - px;
                float y1 = 2 * cy - py;
                float x2 = num() + ox;
                float y2 = num() + oy;
                float x = num() + ox;
                float y = num() + oy;
                p.cubicTo(x1, y1, x2, y2, x, y);
                px = x2;
                py = y2;
                cx = x;
                cy = y;
            } else if (c == 'Q') {
                float x1 = num() + ox;
                float y1 = num() + oy;
                float x = num() + ox;
                float y = num() + oy;
                p.quadTo(x1, y1, x, y);
                px = x1;
                py = y1;
                cx = x;
                cy = y;
            } else if (c == 'T') {
                float x1 = 2 * cx - px;
                float y1 = 2 * cy - py;
                float x = num() + ox;
                float y = num() + oy;
                p.quadTo(x1, y1, x, y);
                px = x1;
                py = y1;
                cx = x;
                cy = y;
            } else if (c == 'A') {
                float rx = Math.abs(num());
                float ry = Math.abs(num());
                num();
                float large = num();
                float sweep = num();
                float x = num() + ox;
                float y = num() + oy;
                arcTo(p, cx, cy, rx, ry, large, sweep, x, y);
                cx = x;
                cy = y;
            } else {
                break;
            }
        }
        return p;
    }

    /** Arco SVG por muestreo angular (suficiente para iconos). */
    private static void arcTo(Path p, float x0, float y0, float rx, float ry,
                              float large, float sweep, float x1, float y1) {
        if (rx <= 0f || ry <= 0f) {
            p.lineTo(x1, y1);
            return;
        }
        if (x0 == x1 && y0 == y1) return;
        double dx = (x0 - x1) / 2.0;
        double dy = (y0 - y1) / 2.0;
        double x1p = dx;
        double y1p = dy;
        double rx2 = rx * rx;
        double ry2 = ry * ry;
        double lambda = (x1p * x1p) / rx2 + (y1p * y1p) / ry2;
        if (lambda > 1.0) {
            double k = Math.sqrt(lambda);
            rx = (float) (rx * k);
            ry = (float) (ry * k);
            rx2 = rx * rx;
            ry2 = ry * ry;
        }
        double num = rx2 * ry2 - rx2 * y1p * y1p - ry2 * x1p * x1p;
        double den = rx2 * y1p * y1p + ry2 * x1p * x1p;
        double co = den == 0 ? 0 : Math.sqrt(Math.max(0, num / den));
        if (large == sweep) co = -co;
        double cxp = co * (rx * y1p / ry);
        double cyp = -co * (ry * x1p / rx);
        double cx = cxp + (x0 + x1) / 2.0;
        double cy = cyp + (y0 + y1) / 2.0;
        double a0 = Math.atan2((y0 - cy) / ry, (x0 - cx) / rx);
        double a1 = Math.atan2((y1 - cy) / ry, (x1 - cx) / rx);
        double da = a1 - a0;
        if (sweep > 0.5) {
            while (da < 0) da += Math.PI * 2;
        } else {
            while (da > 0) da -= Math.PI * 2;
        }
        int steps = Math.max(4, (int) Math.ceil(Math.abs(da) / (Math.PI / 24)));
        for (int k = 1; k <= steps; k++) {
            double a = a0 + da * k / steps;
            p.lineTo((float) (cx + rx * Math.cos(a)), (float) (cy + ry * Math.sin(a)));
        }
    }
}
