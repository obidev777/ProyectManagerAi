package com.pm.ai.core;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import com.pm.ai.R;
import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Puente con AIDE: le pasa la ruta del proyecto para que AIDE lo abra y el
 * usuario solo pulse Run. Prueba varias estrategias de Intent y siempre deja
 * la ruta copiada en el portapapeles.
 */
public class AideBridge {

    private static final String[] KNOWN = {
            "com.aide.ui", "com.aide.ui.premium", "com.aide.web",
            "com.droid.ide.ui", "com.aide.tutorial.ui"
    };

    public static List<String> installed(Context c) {
        List<String> out = new ArrayList<String>();
        for (int i = 0; i < KNOWN.length; i++) {
            if (Utils.hasApp(c, KNOWN[i])) out.add(KNOWN[i]);
        }
        try {
            List<PackageInfo> ps = c.getPackageManager().getInstalledPackages(0);
            for (int i = 0; i < ps.size(); i++) {
                String n = ps.get(i).packageName;
                if (n == null || out.contains(n)) continue;
                String low = n.toLowerCase();
                if (low.indexOf("aide") < 0 && low.indexOf("droid.ide") < 0) continue;
                if (c.getPackageManager().getLaunchIntentForPackage(n) != null) out.add(n);
            }
        } catch (Throwable t) {
            // ignorado
        }
        return out;
    }

    public static String preferred(Context c) {
        String p = Prefs.aidePkg(c);
        List<String> all = installed(c);
        if (p != null && p.length() > 0 && all.contains(p)) return p;
        return all.size() > 0 ? all.get(0) : null;
    }

    public static boolean isInstalled(Context c) {
        return preferred(c) != null;
    }

    public static void open(final Activity a, final Project p) {
        if (a == null || p == null || p.dir == null) return;
        Utils.allowFileUri();
        final File dir = p.dir;
        Utils.copy(a, "ruta", dir.getAbsolutePath());
        final String pkg = preferred(a);
        if (pkg == null) {
            new AlertDialog.Builder(a)
                    .setTitle("AIDE no esta instalado")
                    .setMessage(noAideText(p))
                    .setPositiveButton(R.string.act_export, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            File z = Storage.get(a).exportZip(p);
                            if (z == null) Utils.toast(a, "No se pudo crear el ZIP");
                            else Utils.shareFile(a, z);
                        }
                    })
                    .setNegativeButton(R.string.act_cancel, null)
                    .show();
            return;
        }
        boolean ok = launch(a, pkg, dir);
        showDialog(a, p, pkg, ok);
    }

    private static boolean launch(Activity a, String pkg, File dir) {
        Uri uri = Uri.fromFile(dir);
        List<Intent> tries = new ArrayList<Intent>();
        try {
            Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
            i1.setDataAndType(uri, "vnd.android.cursor.dir/*");
            tries.add(i1);
            Intent i2 = new Intent(Intent.ACTION_EDIT, uri);
            i2.setDataAndType(uri, "vnd.android.cursor.dir/*");
            tries.add(i2);
            File man = new File(dir, "AndroidManifest.xml");
            if (man.isFile()) {
                Uri mu = Uri.fromFile(man);
                Intent i3 = new Intent(Intent.ACTION_VIEW, mu);
                i3.setDataAndType(mu, "text/xml");
                tries.add(i3);
            }
        } catch (Throwable t) {
            // ignorado
        }
        try {
            Intent i4 = a.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i4 != null) tries.add(i4);
        } catch (Throwable t) {
            // ignorado
        }
        for (int i = 0; i < tries.size(); i++) {
            Intent it = tries.get(i);
            if (it == null) continue;
            try {
                it.setPackage(pkg);
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                it.putExtra(Intent.EXTRA_STREAM, uri);
                it.putExtra("projectPath", dir.getAbsolutePath());
                it.putExtra("path", dir.getAbsolutePath());
                it.putExtra("android.intent.extra.TEXT", dir.getAbsolutePath());
                a.startActivity(it);
                return true;
            } catch (Throwable t) {
                // siguiente estrategia
            }
        }
        return false;
    }

    private static void showDialog(final Activity a, final Project p, final String pkg,
                                   boolean launched) {
        String msg = launched
                ? "AIDE lanzado: " + pkg + "\n\n"
                : "He abierto AIDE, pero puede que tengas que elegir la carpeta a mano.\n\n";
        msg += "Ruta del proyecto, ya copiada al portapapeles:\n" + p.dir.getAbsolutePath()
                + "\n\nEn AIDE: Project > Open > elige esa carpeta > Run.\n"
                + "Ajustes recomendados: SDK API 27 o 28 y Java 1.7.\n"
                + "Si AIDE se queja de build.gradle, borralo: no hace falta.";
        new AlertDialog.Builder(a)
                .setTitle("Abrir en AIDE")
                .setMessage(msg)
                .setPositiveButton("Reintentar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String pk = preferred(a);
                        if (pk != null) launch(a, pk, p.dir);
                    }
                })
                .setNeutralButton(R.string.act_copy, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        Utils.copy(a, "ruta", p.dir.getAbsolutePath());
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    public static String noAideText(Project p) {
        return "No se ha detectado AIDE en el telefono.\n\n"
                + "Ruta del proyecto, copiada al portapapeles:\n" + p.dir.getAbsolutePath()
                + "\n\nPasos: instala AIDE 3.2.2, Project > Open, elige esa carpeta y pulsa Run.\n"
                + "Tambien puedes exportar el proyecto como ZIP.";
    }
}
