package com.pm.ai.core;

import com.pm.ai.util.Utils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Genera AUDIO real dentro de la app a partir de comandos del modelo.
 * SPEC sintetiza un WAV (PCM 16 bits) con notas, acordes, melodias, barridos
 * y ruido; BASE64 escribe cualquier binario (mp3, ogg, wav).
 */
public class AudioGen {

    public static class Out {
        public boolean ok = false;
        public String msg = "";
        public int ms = 0;
    }

    private static final int MAX_SECONDS = 120;

    public static Out create(File outFile, String format, String body, String relPath) {
        Out o = new Out();
        try {
            String fmt = format == null ? "" : format.trim().toUpperCase();
            String ext = ImageGen.extOf(outFile.getName());
            String content = AssetFactory.stripFences(body);
            if (fmt.length() == 0) {
                String t = content.trim();
                if (t.startsWith("{") || t.startsWith("[")) fmt = "SPEC";
                else if (t.replaceAll("[A-Za-z0-9+/=\\s]", "").length() == 0 && t.length() > 60) fmt = "BASE64";
                else fmt = "SPEC";
            }
            if (fmt.equals("BASE64") || fmt.equals("B64")) {
                byte[] data = AssetFactory.decodeBase64(content);
                if (data.length == 0) {
                    o.msg = "base64 vacio o invalido";
                    return o;
                }
                AssetFactory.writeBytes(outFile, data);
                o.ok = true;
                o.msg = data.length + " bytes binarios";
                return o;
            }
            if (!ext.equals("wav") && !ext.equals("pcm")) {
                o.msg = "SPEC solo puede generar .wav (usa BASE64 para ." + ext + ")";
                return o;
            }
            JSONObject spec = new JSONObject(content);
            int rate = spec.optInt("sampleRate", 44100);
            if (rate < 8000) rate = 8000;
            if (rate > 48000) rate = 48000;
            int channels = spec.optInt("channels", 1);
            if (channels < 1) channels = 1;
            if (channels > 2) channels = 2;
            double master = spec.optDouble("volume", 0.9);
            double total = spec.optDouble("duration", 0);
            JSONArray notes = spec.optJSONArray("notes");
            JSONArray tones = spec.optJSONArray("tones");
            String melody = spec.optString("melody", "");
            double bpm = spec.optDouble("bpm", 0);
            if (total <= 0) {
                total = spanOf(notes, tones, melody, bpm);
            }
            if (total <= 0) total = 1.0;
            if (total > MAX_SECONDS) total = MAX_SECONDS;
            int frames = (int) Math.ceil(total * rate);
            float[] mix = new float[frames * channels];
            if (tones != null) {
                for (int i = 0; i < tones.length(); i++) addTone(mix, rate, channels, tones.optJSONObject(i), 0, bpm);
            }
            if (notes != null) {
                double t = 0;
                for (int i = 0; i < notes.length(); i++) {
                    JSONObject n = notes.optJSONObject(i);
                    if (n == null) continue;
                    t += addTone(mix, rate, channels, n, t, bpm);
                }
            }
            if (melody.length() > 0) {
                double t = 0;
                String[] parts = melody.trim().split("\\s+");
                for (int i = 0; i < parts.length; i++) {
                    String[] kv = parts[i].split(":");
                    String name = kv[0];
                    double dur = kv.length > 1 ? parseDouble(kv[1]) : 0.25;
                    if (bpm > 0) dur = dur * 60.0 / bpm;
                    if (dur <= 0) dur = 0.25;
                    if (!name.equalsIgnoreCase("R") && !name.equals("-") && !name.equals(".")) {
                        JSONObject n = new JSONObject();
                        n.put("note", name);
                        n.put("dur", dur);
                        addTone(mix, rate, channels, n, t, 0);
                    }
                    t += dur;
                }
            }
            short[] pcm = toPcm(mix, master);
            writeWav(outFile, pcm, rate, channels);
            o.ok = true;
            o.ms = (int) (total * 1000);
            o.msg = Utils.humanSize(outFile.length()) + " wav " + rate + "Hz "
                    + channels + "ch " + o.ms + "ms";
        } catch (Throwable t) {
            o.msg = t.getClass().getSimpleName() + ": " + t.getMessage();
        }
        return o;
    }

    private static double parseDouble(String s) {
        try {
            return Double.parseDouble(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private static double spanOf(JSONArray notes, JSONArray tones, String melody, double bpm) {
        double end = 0;
        if (tones != null) {
            for (int i = 0; i < tones.length(); i++) {
                JSONObject n = tones.optJSONObject(i);
                if (n == null) continue;
                double st = n.optDouble("start", 0);
                double du = n.optDouble("dur", n.optDouble("duration", 0.5));
                if (bpm > 0) du = du * 60.0 / bpm;
                if (st + du > end) end = st + du;
            }
        }
        if (notes != null) {
            double t = 0;
            for (int i = 0; i < notes.length(); i++) {
                JSONObject n = notes.optJSONObject(i);
                if (n == null) continue;
                double du = n.optDouble("dur", n.optDouble("duration", 0.25));
                if (bpm > 0) du = du * 60.0 / bpm;
                t += du;
            }
            if (t > end) end = t;
        }
        if (melody != null && melody.trim().length() > 0) {
            double t = 0;
            String[] parts = melody.trim().split("\\s+");
            for (int i = 0; i < parts.length; i++) {
                String[] kv = parts[i].split(":");
                double dur = kv.length > 1 ? parseDouble(kv[1]) : 0.25;
                if (bpm > 0) dur = dur * 60.0 / bpm;
                t += dur;
            }
            if (t > end) end = t;
        }
        return end;
    }

    /** Anade un tono/nota al buffer. Devuelve su duracion en segundos. */
    private static double addTone(float[] mix, int rate, int channels, JSONObject n,
                                  double startAt, double bpm) {
        if (n == null) return 0;
        try {
            double dur = n.optDouble("dur", n.optDouble("duration", 0.3));
            if (bpm > 0) dur = dur * 60.0 / bpm;
            if (dur <= 0) dur = 0.3;
            if (dur > MAX_SECONDS) dur = MAX_SECONDS;
            double start = startAt + n.optDouble("start", n.optDouble("delay", 0));
            double vol = n.optDouble("vol", n.optDouble("volume", 0.8));
            double attack = n.optDouble("attack", 0.01);
            double release = n.optDouble("release", Math.min(0.12, dur / 3.0));
            String wave = n.optString("wave", n.optString("type", "sine"));
            double f0 = freqOf(n);
            double f1 = n.optDouble("freq2", n.optDouble("to", f0));
            if (f1 <= 0) f1 = f0;
            JSONArray chord = n.optJSONArray("chord");
            int offs = (int) Math.max(0, Math.round(start * rate));
            int len = (int) Math.round(dur * rate);
            for (int s = 0; s < len; s++) {
                int idx = offs + s;
                if (idx >= mix.length / channels) break;
                double t = (double) s / rate;
                double prog = len <= 1 ? 0 : (double) s / (len - 1);
                double f = f0 + (f1 - f0) * prog;
                double env = 1.0;
                if (attack > 0 && t < attack) env *= t / attack;
                double relStart = dur - release;
                if (release > 0 && t > relStart) env *= Math.max(0, (dur - t) / release);
                double sample = 0;
                if (chord != null && chord.length() > 0) {
                    for (int c = 0; c < chord.length(); c++) {
                        double cf = noteFreq(String.valueOf(chord.opt(c)));
                        sample += wave(wave, cf, t + c * 0.0007) / chord.length();
                    }
                } else {
                    sample = wave(wave, f, t);
                }
                sample *= env * vol;
                for (int ch = 0; ch < channels; ch++) {
                    int p = idx * channels + ch;
                    if (p < mix.length) mix[p] += (float) sample;
                }
            }
            return dur;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static double freqOf(JSONObject n) {
        if (n.has("freq")) return n.optDouble("freq", 440);
        if (n.has("note")) return noteFreq(n.optString("note", "A4"));
        if (n.has("midi")) {
            int m = n.optInt("midi", 69);
            return 440.0 * Math.pow(2, (m - 69) / 12.0);
        }
        return 440;
    }

    /** "A4", "C#5", "Bb3", "440", "R" -> Hz. */
    public static double noteFreq(String s) {
        if (s == null) return 440;
        String v = s.trim();
        if (v.length() == 0) return 440;
        try {
            return Double.parseDouble(v);
        } catch (Exception e) {
            // es nombre de nota
        }
        char c = Character.toUpperCase(v.charAt(0));
        int base;
        if (c == 'C') base = 0;
        else if (c == 'D') base = 2;
        else if (c == 'E') base = 4;
        else if (c == 'F') base = 5;
        else if (c == 'G') base = 7;
        else if (c == 'A') base = 9;
        else if (c == 'B') base = 11;
        else return 440;
        int i = 1;
        if (i < v.length() && (v.charAt(i) == '#' || v.charAt(i) == '+')) {
            base += 1;
            i++;
        } else if (i < v.length() && (v.charAt(i) == 'b' || v.charAt(i) == '-')) {
            base -= 1;
            i++;
        }
        int oct = 4;
        if (i < v.length()) {
            try {
                oct = Integer.parseInt(v.substring(i).trim());
            } catch (Exception e) {
                oct = 4;
            }
        }
        int semi = (oct - 4) * 12 + (base - 9);
        return 440.0 * Math.pow(2, semi / 12.0);
    }

    private static double wave(String w, double freq, double t) {
        if (freq <= 0) return 0;
        double ph = freq * t;
        double frac = ph - Math.floor(ph);
        String k = w == null ? "sine" : w.toLowerCase();
        if (k.equals("square") || k.equals("rect")) return frac < 0.5 ? 0.7 : -0.7;
        if (k.equals("saw") || k.equals("sawtooth")) return 2 * frac - 1;
        if (k.equals("tri") || k.equals("triangle")) return 4 * Math.abs(frac - 0.5) - 1;
        if (k.equals("noise") || k.equals("white")) return Math.random() * 2 - 1;
        if (k.equals("bell")) {
            return Math.sin(2 * Math.PI * ph) * 0.7 + Math.sin(2 * Math.PI * ph * 2.7) * 0.3;
        }
        return Math.sin(2 * Math.PI * ph);
    }

    private static short[] toPcm(float[] mix, double master) {
        short[] out = new short[mix.length];
        for (int i = 0; i < mix.length; i++) {
            double v = mix[i] * master;
            if (v > 1) v = 1;
            if (v < -1) v = -1;
            out[i] = (short) Math.round(v * 32767);
        }
        return out;
    }

    public static boolean writeWav(File f, short[] pcm, int rate, int channels) {
        FileOutputStream fos = null;
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            int bytes = pcm.length * 2;
            bos.write("RIFF".getBytes("US-ASCII"));
            writeIntLE(bos, 36 + bytes);
            bos.write("WAVE".getBytes("US-ASCII"));
            bos.write("fmt ".getBytes("US-ASCII"));
            writeIntLE(bos, 16);
            writeShortLE(bos, (short) 1);
            writeShortLE(bos, (short) channels);
            writeIntLE(bos, rate);
            writeIntLE(bos, rate * channels * 2);
            writeShortLE(bos, (short) (channels * 2));
            writeShortLE(bos, (short) 16);
            bos.write("data".getBytes("US-ASCII"));
            writeIntLE(bos, bytes);
            for (int i = 0; i < pcm.length; i++) writeShortLE(bos, pcm[i]);
            fos = new FileOutputStream(f);
            fos.write(bos.toByteArray());
            fos.flush();
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            Utils.close(fos);
        }
    }

    private static void writeIntLE(ByteArrayOutputStream b, int v) {
        b.write(v & 0xFF);
        b.write((v >> 8) & 0xFF);
        b.write((v >> 16) & 0xFF);
        b.write((v >> 24) & 0xFF);
    }

    private static void writeShortLE(ByteArrayOutputStream b, short v) {
        b.write(v & 0xFF);
        b.write((v >> 8) & 0xFF);
    }

    /** Duracion en ms de un WAV ya escrito (para el log). */
    public static int wavMillis(File f) {
        try {
            long len = f.length();
            if (len < 44) return 0;
            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r");
            raf.seek(24);
            int rate = raf.readInt();
            raf.close();
            rate = Integer.reverseBytes(rate);
            if (rate <= 0) return 0;
            return (int) (((len - 44) * 1000L) / (rate * 2L));
        } catch (Throwable t) {
            return 0;
        }
    }
}
