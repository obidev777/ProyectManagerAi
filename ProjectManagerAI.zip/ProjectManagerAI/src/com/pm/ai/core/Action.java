package com.pm.ai.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Una accion de ficheros devuelta por el modelo (Protocolo PM v2.1).
 * Incluye ediciones por rango de lineas y generacion de imagenes/audios.
 */
public class Action {

    public static final int CREATE = 0;
    public static final int REPLACE = 1;
    public static final int EDIT = 2;
    public static final int DELETE = 3;
    public static final int RENAME = 4;
    public static final int CONTINUE = 5;
    public static final int APPEND = 6;
    public static final int EDIT_RANGE = 7;
    public static final int INSERT_AFTER = 8;
    public static final int UNKNOWN = 9;
    public static final int DELETE_LINES = 10;
    public static final int CREATE_IMAGE = 11;
    public static final int CREATE_AUDIO = 12;

    public int kind = UNKNOWN;
    public String path = "";
    public String target = "";
    public String lang = "";
    public String note = "";
    public String content = "";
    public String status = "COMPLETE";
    public List<String[]> edits = new ArrayList<String[]>();
    /** Rango de lineas (1-based, inclusivo) para EDIT_RANGE / DELETE_LINES. */
    public int fromLine = 0;
    public int toLine = 0;
    /** Linea tras la que insertar en INSERT_AFTER. */
    public int afterLine = 0;
    public String anchor = "";
    /** SPEC | SVG | VECTOR | BASE64 | TEXT (solo assets). */
    public String format = "";
    public boolean selected = true;
    public String result = "";
    /** Ruta absoluta del archivo escrito (para miniaturas y logs). */
    public String absPath = "";

    public static int kindFrom(String s) {
        if (s == null) return UNKNOWN;
        String v = s.trim().toUpperCase();
        int sp = v.indexOf(' ');
        if (sp > 0) v = v.substring(0, sp);
        if (v.equals("CREATE_IMAGE") || v.equals("IMAGE") || v.equals("IMG")
                || v.equals("BITMAP") || v.equals("PICTURE") || v.equals("ICON")
                || v.equals("DRAW_IMAGE") || v.equals("PNG")) return CREATE_IMAGE;
        if (v.equals("CREATE_AUDIO") || v.equals("AUDIO") || v.equals("SOUND")
                || v.equals("MUSIC") || v.equals("TONE") || v.equals("WAV")
                || v.equals("SFX")) return CREATE_AUDIO;
        if (v.equals("EDIT_RANGE") || v.equals("RANGE") || v.equals("REPLACE_RANGE")
                || v.equals("PATCH_LINES") || v.equals("LINES") || v.equals("EDIT_LINES")
                || v.equals("REPLACE_LINES")) return EDIT_RANGE;
        if (v.equals("INSERT_AFTER") || v.equals("INSERT_AFTER_LINE") || v.equals("AFTER_LINE")
                || v.equals("INSERT_LINE") || v.equals("INSERT_AT") || v.equals("INSERT")) return INSERT_AFTER;
        if (v.equals("DELETE_LINES") || v.equals("REMOVE_LINES") || v.equals("DEL_LINES")) return DELETE_LINES;
        if (v.startsWith("CREAT") || v.equals("NEW") || v.startsWith("ADD")) return CREATE;
        if (v.startsWith("REPLAC") || v.equals("OVERWRITE") || v.equals("WRITE")
                || v.startsWith("REWRITE")) return REPLACE;
        if (v.startsWith("EDIT") || v.equals("MODIFY") || v.equals("PATCH")
                || v.startsWith("UPDATE")) return EDIT;
        if (v.startsWith("DELET") || v.startsWith("REMOV")) return DELETE;
        if (v.startsWith("RENAM") || v.equals("MOVE")) return RENAME;
        if (v.startsWith("CONTINU") || v.equals("RESUME")) return CONTINUE;
        if (v.startsWith("APPEND")) return APPEND;
        return UNKNOWN;
    }

    public String kindLabel() {
        switch (kind) {
            case CREATE: return "CREAR";
            case REPLACE: return "REEMPLAZAR";
            case EDIT: return "EDITAR";
            case EDIT_RANGE: return "RANGO";
            case INSERT_AFTER: return "INSERTAR";
            case DELETE_LINES: return "BORRAR LIN.";
            case DELETE: return "BORRAR";
            case RENAME: return "RENOMBRAR";
            case CONTINUE: return "CONTINUAR";
            case APPEND: return "ANADIR";
            case CREATE_IMAGE: return "IMAGEN";
            case CREATE_AUDIO: return "AUDIO";
            default: return "ESCRIBIR";
        }
    }

    public boolean incomplete() {
        return status != null && status.toUpperCase().indexOf("INCOMPLETE") >= 0;
    }

    public boolean isRange() {
        return kind == EDIT_RANGE || kind == INSERT_AFTER || kind == DELETE_LINES;
    }

    public boolean isAsset() {
        return kind == CREATE_IMAGE || kind == CREATE_AUDIO;
    }

    public String rangeLabel() {
        if (kind == INSERT_AFTER) {
            int n = afterLine > 0 ? afterLine : fromLine;
            return n > 0 ? "tras linea " + n : "insercion";
        }
        if (fromLine <= 0) return "";
        if (toLine <= 0 || toLine == fromLine) return "linea " + fromLine;
        return "lineas " + fromLine + "-" + toLine;
    }

    public boolean validRange() {
        if (kind == INSERT_AFTER) return afterLine >= 0;
        if (kind == DELETE_LINES || kind == EDIT_RANGE) return fromLine >= 1 && toLine >= fromLine;
        return true;
    }

    public int size() {
        return content == null ? 0 : content.length();
    }

    public int lines() {
        if (content == null || content.length() == 0) return 0;
        return content.split("\n", -1).length;
    }
}
