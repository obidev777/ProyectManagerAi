package com.pm.ai.core;

import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Ejecuta sobre disco las acciones del modelo, con backup.
 * V2: rangos de lineas + creacion de imagenes y audios.
 */
public class ActionApplier {

    public static class Report {
        public List<String> log = new ArrayList<String>();
        public int ok = 0;
        public int fail = 0;
        public int skipped = 0;
        public int partial = 0;
        public int ranged = 0;
        public int assets = 0;
        public String backupPath = "";

        public String text() {
            return Utils.join(log, "\n");
        }
    }

    public static Report apply(Storage st, Project p, List<Action> actions, boolean backup) {
        Report rep = new Report();
        File bdir = backup ? new File(p.pm(), "backups/" + Utils.stamp()) : null;
        rep.log.add("=== Aplicado " + Utils.dateLong(System.currentTimeMillis()) + " ===");
        rep.log.add("Proyecto: " + p.name + "  (" + p.dir.getAbsolutePath() + ")");
        for (int i = 0; i < actions.size(); i++) {
            Action a = actions.get(i);
            a.absPath = "";
            if (!a.selected) {
                rep.skipped++;
                continue;
            }
            String rel = Utils.normPath(a.path);
            if (!Utils.isSafePath(rel)) {
                a.result = "ruta no valida";
                rep.fail++;
                rep.log.add("[FALLO] ruta no valida: " + a.path);
                continue;
            }
            File f = st.file(p, rel);
            a.absPath = f.getAbsolutePath();
            try {
                if (a.isAsset()) doAsset(p, a, f, rel, bdir, rep);
                else if (a.kind == Action.DELETE) doDelete(a, f, rel, rep);
                else if (a.kind == Action.RENAME) doRename(st, p, a, f, rel, rep);
                else if (a.kind == Action.EDIT) doEdit(a, f, rel, bdir, p, rep);
                else if (a.isRange()) doRange(p, a, f, rel, bdir, rep);
                else if (a.kind == Action.CONTINUE || a.kind == Action.APPEND) {
                    doContinue(p, a, f, rel, bdir, rep);
                } else doWrite(p, a, f, rel, bdir, rep);
            } catch (Throwable e) {
                rep.fail++;
                a.result = e.getClass().getSimpleName();
                rep.log.add("[ERROR] " + rel + " : " + e.getClass().getSimpleName()
                        + " " + e.getMessage());
            }
        }
        if (bdir != null && bdir.exists() && rep.ok > 0) {
            rep.backupPath = bdir.getAbsolutePath();
            rep.log.add("Backup: " + rep.backupPath);
        }
        rep.log.add("Resumen: " + rep.ok + " ok, " + rep.fail + " fallos, " + rep.partial
                + " parciales, " + rep.ranged + " por rango, " + rep.assets + " assets, "
                + rep.skipped + " omitidos");
        st.touch(p);
        st.save(p);
        return rep;
    }

    /** NUEVO: imagenes y audios generados por la propia app. */
    private static void doAsset(Project p, Action a, File f, String rel, File bdir, Report rep) {
        String problem = AssetFactory.validate(a);
        if (problem.length() > 0) rep.log.add("[AVISO] " + rel + ": " + problem);
        if (f.isFile()) backupFile(p, bdir, rel, f);
        AssetFactory.Result r = AssetFactory.create(a, f);
        if (r.ok && f.isFile()) {
            rep.ok++;
            rep.assets++;
            a.result = r.msg;
            PendingManager.remove(p, rel);
            String tag = a.kind == Action.CREATE_IMAGE ? "[IMAGEN]" : "[AUDIO]";
            rep.log.add(tag + " " + rel + " -> " + r.msg);
        } else {
            rep.fail++;
            a.result = r.msg;
            rep.log.add("[FALLO] asset " + rel + ": " + r.msg);
        }
    }

    private static void doDelete(Action a, File f, String rel, Report rep) {
        if (!f.exists()) {
            rep.skipped++;
            a.result = "no existe";
            rep.log.add("[SKIP]  " + rel + " (no existe)");
            return;
        }
        boolean d = f.isFile() ? f.delete() : Utils.deleteRecursive(f);
        if (d) {
            rep.ok++;
            a.result = "borrado";
            rep.log.add("[BORRA] " + rel);
        } else {
            rep.fail++;
            a.result = "no se pudo borrar";
            rep.log.add("[FALLO] no se pudo borrar " + rel);
        }
    }

    private static void doRename(Storage st, Project p, Action a, File f, String rel, Report rep) {
        String to = Utils.normPath(a.target);
        if (!Utils.isSafePath(to) || !f.exists()) {
            rep.fail++;
            a.result = "renombrado invalido";
            rep.log.add("[FALLO] renombrado invalido: " + rel + " -> " + a.target);
            return;
        }
        File dst = st.file(p, to);
        File pd = dst.getParentFile();
        if (pd != null && !pd.exists()) pd.mkdirs();
        if (f.renameTo(dst)) {
            rep.ok++;
            a.result = "renombrado";
            a.absPath = dst.getAbsolutePath();
            rep.log.add("[MOVE]  " + rel + " -> " + to);
        } else {
            rep.fail++;
            a.result = "no se pudo mover";
            rep.log.add("[FALLO] no se pudo mover " + rel);
        }
    }

    private static void doEdit(Action a, File f, String rel, File bdir, Project p, Report rep) {
        if (!f.isFile()) {
            rep.fail++;
            a.result = "el archivo no existe";
            rep.log.add("[FALLO] EDIT sobre archivo inexistente: " + rel);
            return;
        }
        String src = Utils.readText(f);
        StringBuilder detail = new StringBuilder();
        String out = applyEdits(src, a.edits, detail);
        backupFile(p, bdir, rel, f);
        if (Utils.writeText(f, out)) {
            rep.ok++;
            a.result = a.edits.size() + " ediciones";
            rep.log.add("[EDITA] " + rel + "\n" + detail.toString());
        } else {
            rep.fail++;
            a.result = "error de escritura";
            rep.log.add("[FALLO] no se pudo escribir " + rel);
        }
    }

    private static void doRange(Project p, Action a, File f, String rel, File bdir, Report rep) {
        String body = ResponseParser.stripLineNumbers(a.content == null ? "" : a.content);
        if (a.kind == Action.DELETE_LINES) body = "";
        if (!f.isFile()) {
            if (a.kind == Action.INSERT_AFTER && a.afterLine <= 0 && body.length() > 0) {
                backupFile(p, bdir, rel, f);
                if (Utils.writeText(f, body)) {
                    rep.ok++;
                    a.result = "creado (" + body.length() + " chars)";
                    rep.log.add("[CREA]  " + rel + " (insercion sobre archivo nuevo)");
                    return;
                }
            }
            rep.fail++;
            a.result = "el archivo no existe";
            rep.log.add("[FALLO] rango sobre archivo inexistente: " + rel);
            return;
        }
        String src = Utils.readText(f);
        int total = Utils.countLines(src);
        if (total == 0) total = 1;
        int from;
        int to;
        if (a.kind == Action.INSERT_AFTER) {
            int after = a.afterLine > 0 ? a.afterLine : a.fromLine;
            if (after < 0) after = 0;
            if (after > total) after = total;
            from = after + 1;
            to = after;
        } else {
            from = a.fromLine < 1 ? 1 : a.fromLine;
            if (from > total + 1) from = total + 1;
            to = a.toLine < from ? from : a.toLine;
            if (to > total) to = total;
        }
        if (body.length() == 0 && a.kind == Action.EDIT_RANGE) {
            rep.fail++;
            a.result = "sin contenido";
            rep.log.add("[FALLO] EDIT_RANGE sin contenido: " + rel);
            return;
        }
        backupFile(p, bdir, rel, f);
        String out = spliceLines(src, from, to, body);
        if (Utils.writeText(f, out)) {
            PendingManager.remove(p, rel);
            rep.ok++;
            rep.ranged++;
            int removed = to >= from ? (to - from + 1) : 0;
            int nl = body.length() == 0 ? 0 : Utils.countLines(body);
            a.result = removed + " lineas -> " + nl;
            rep.log.add("[RANGO] " + rel + " lineas " + from + "-" + to + " fuera (" + removed
                    + "), " + nl + " nuevas | " + total + " -> " + Utils.countLines(out));
        } else {
            rep.fail++;
            a.result = "error de escritura";
            rep.log.add("[FALLO] no se pudo escribir " + rel);
        }
    }

    private static void doContinue(Project p, Action a, File f, String rel, File bdir, Report rep) {
        String prev = PendingManager.get(p, rel);
        if (prev == null) prev = f.isFile() ? Utils.readText(f) : "";
        String merged = prev + (a.content == null ? "" : a.content);
        if (a.incomplete()) {
            PendingManager.put(p, rel, merged, a.lang);
            rep.partial++;
            a.result = "parcial " + merged.length() + " chars";
            rep.log.add("[PARC]  " + rel + " incompleto (" + merged.length()
                    + " chars guardados). Usa CONTINUAR.");
            return;
        }
        if (f.isFile()) backupFile(p, bdir, rel, f);
        if (Utils.writeText(f, merged)) {
            PendingManager.remove(p, rel);
            rep.ok++;
            a.result = "continuado (" + merged.length() + " chars)";
            rep.log.add("[CONT]  " + rel + " completado (" + merged.length() + " chars)");
        } else {
            rep.fail++;
            a.result = "error de escritura";
            rep.log.add("[FALLO] no se pudo escribir " + rel);
        }
    }

    private static void doWrite(Project p, Action a, File f, String rel, File bdir, Report rep) {
        String content = a.content == null ? "" : a.content;
        if (content.length() == 0) {
            rep.fail++;
            a.result = "sin contenido";
            rep.log.add("[FALLO] bloque sin contenido: " + rel);
            return;
        }
        if (a.incomplete()) {
            PendingManager.put(p, rel, content, a.lang);
            rep.partial++;
            a.result = "parcial " + content.length() + " chars";
            rep.log.add("[PARC]  " + rel + " incompleto (" + content.length()
                    + " chars). Usa CONTINUAR.");
            return;
        }
        if (f.isFile()) backupFile(p, bdir, rel, f);
        if (Utils.writeText(f, content)) {
            PendingManager.remove(p, rel);
            rep.ok++;
            a.result = "escrito " + content.length() + " chars";
            rep.log.add((a.kind == Action.REPLACE ? "[REEMP] " : "[CREA]  ") + rel
                    + " (" + content.length() + " chars, " + a.lines() + " lineas)");
        } else {
            rep.fail++;
            a.result = "error de escritura";
            rep.log.add("[FALLO] no se pudo escribir " + rel);
        }
    }

    /** Sustituye las lineas [from..to] (1-based) por 'body'. */
    public static String spliceLines(String src, int from, int to, String body) {
        List<String> ls = Utils.splitLines(src == null ? "" : src.replace("\r\n", "\n"));
        List<String> out = new ArrayList<String>();
        for (int i = 1; i < from && i - 1 < ls.size(); i++) out.add(ls.get(i - 1));
        if (body != null && body.length() > 0) {
            List<String> bl = Utils.splitLines(body.replace("\r\n", "\n"));
            while (bl.size() > 1 && bl.get(bl.size() - 1).length() == 0) bl.remove(bl.size() - 1);
            for (int i = 0; i < bl.size(); i++) out.add(bl.get(i));
        }
        for (int i = to + 1; i <= ls.size(); i++) out.add(ls.get(i - 1));
        return Utils.join(out, "\n");
    }

    private static void backupFile(Project p, File bdir, String rel, File f) {
        if (bdir == null || f == null || !f.isFile()) return;
        Utils.copyFile(f, new File(bdir, rel));
    }

    private static String applyEdits(String src, List<String[]> edits, StringBuilder log) {
        String text = src == null ? "" : src.replace("\r\n", "\n");
        if (edits == null) return text;
        for (int i = 0; i < edits.size(); i++) {
            String find = edits.get(i)[0] == null ? "" : edits.get(i)[0].replace("\r\n", "\n");
            String repl = edits.get(i)[1] == null ? "" : edits.get(i)[1].replace("\r\n", "\n");
            if (find.trim().length() == 0) {
                log.append("    ! bloque FIND vacio\n");
                continue;
            }
            if (text.indexOf(find) >= 0) {
                int n = Utils.countOccurrences(text, find);
                text = text.replace(find, repl);
                log.append("    ok reemplazo exacto x").append(n).append("\n");
                continue;
            }
            String tf = find.trim();
            if (text.trim().equals(tf)) {
                text = repl;
                log.append("    ok archivo reemplazado completo\n");
                continue;
            }
            int[] range = fuzzyRange(text, tf);
            if (range != null) {
                text = spliceLines(text, range[0] + 1, range[1] + 1, repl);
                log.append("    ok reemplazo tolerante (lineas ").append(range[0] + 1)
                        .append("-").append(range[1] + 1).append(")\n");
                continue;
            }
            log.append("    ! FIND no localizado (usa texto literal del archivo actual)\n");
        }
        return text;
    }

    private static int[] fuzzyRange(String text, String find) {
        List<String> tl = Utils.splitLines(text);
        List<String> fl = Utils.splitLines(find);
        while (fl.size() > 0 && fl.get(0).trim().length() == 0) fl.remove(0);
        while (fl.size() > 0 && fl.get(fl.size() - 1).trim().length() == 0) fl.remove(fl.size() - 1);
        if (fl.size() == 0) return null;
        for (int i = 0; i + fl.size() <= tl.size(); i++) {
            boolean ok = true;
            for (int j = 0; j < fl.size(); j++) {
                if (!tl.get(i + j).trim().equals(fl.get(j).trim())) {
                    ok = false;
                    break;
                }
            }
            if (ok) return new int[]{i, i + fl.size() - 1};
        }
        return null;
    }
}
