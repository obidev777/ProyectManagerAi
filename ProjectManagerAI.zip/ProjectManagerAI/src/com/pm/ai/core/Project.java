package com.pm.ai.core;

import org.json.JSONObject;

import java.io.File;

/** Metadatos del proyecto. Se guardan en <proyecto>/.pm/project.json */
public class Project {

    public String name = "";
    public String type = Types.HTML;
    public String description = "";
    public String features = "";
    public String model = "Qwen3-Max";
    public String docsLang = "Espanol";
    public String notes = "";
    public long created = 0L;
    public long updated = 0L;
        public String cover = "";
public File dir;

    public Project() {
    }

    public Project(File dir) {
        this.dir = dir;
        this.name = dir == null ? "" : dir.getName();
    }

    public File pm() {
        File f = new File(dir, ".pm");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public File metaFile() {
        return new File(pm(), "project.json");
    }

    public String typeLabel() {
        return Types.label(type);
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("name", name);
            o.put("type", type);
            o.put("description", description);
            o.put("features", features);
            o.put("model", model);
            o.put("docsLang", docsLang);
            o.put("notes", notes);
                    o.put("cover", cover == null ? "" : cover);
o.put("created", created);
            o.put("updated", updated);
        } catch (Exception e) {
            // ignorado
        }
        return o;
    }

    public static Project fromJson(String json, File dir) {
        Project p = new Project(dir);
        try {
            JSONObject o = new JSONObject(json);
            p.name = o.optString("name", dir.getName());
            p.type = o.optString("type", Types.HTML);
            p.description = o.optString("description", "");
            p.features = o.optString("features", "");
            p.model = o.optString("model", "Qwen3-Max");
            p.docsLang = o.optString("docsLang", "Espanol");
            p.notes = o.optString("notes", "");
                    p.cover = o.optString("cover", "");
p.created = o.optLong("created", 0L);
            p.updated = o.optLong("updated", 0L);
        } catch (Exception e) {
            p.name = dir.getName();
        }
        if (p.name == null || p.name.length() == 0) p.name = dir.getName();
        return p;
    }
}
