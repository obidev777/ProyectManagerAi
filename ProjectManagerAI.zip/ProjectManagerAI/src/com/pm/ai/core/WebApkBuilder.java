package com.pm.ai.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.pm.ai.util.Utils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.List;

/**
 * Convierte un proyecto web en un proyecto Android (WebView + assets/www)
 * listo para compilar en AIDE 3.2.2, con paquete, orientacion, pantalla
 * completa e icono configurables.
 */
public class WebApkBuilder {

    public static class Config {
        public String appName = "";
        public String pkg = "";
        public String outName = "";
        public String entry = "";
        public String iconPath = "";
        public int orient = 0;
        public boolean fullscreen = false;
        public boolean keepOn = false;
    }

    private static final String[] DENS_NAMES = {"mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"};
    private static final int[] DENS_PX = {48, 72, 96, 144, 192};

    public static String defaultPackage(String name) {
        String s = Utils.safeName(name == null ? "web" : name);
        s = s.replace('-', '_').replace('.', '_').toLowerCase();
        if (s.length() == 0) s = "web";
        if (s.length() > 30) s = s.substring(0, 30);
        return "com.web." + s;
    }

    public static String detectEntry(Storage st, Project p) {
        if (st.file(p, "index.html").isFile()) return "index.html";
        List<String> fs = st.files(p);
        for (int i = 0; i < fs.size(); i++) {
            String e = Utils.ext(fs.get(i));
            if (e.equals("html") || e.equals("htm")) return fs.get(i);
        }
        return "index.html";
    }

    /** Crea el proyecto wrapper y devuelve el Project nuevo (o null). */
    public static Project build(Storage st, Project src, Config cfg) {
        if (st == null || src == null || cfg == null) return null;
        String entry = cfg.entry == null || cfg.entry.length() == 0
                ? detectEntry(st, src) : Utils.normPath(cfg.entry);
        if (!st.file(src, entry).isFile()) return null;
        String out = cfg.outName == null || cfg.outName.length() == 0
                ? src.name + "-apk" : cfg.outName;
        String n = st.freeName(out);
        File d = st.dirOf(n);
        if (!d.mkdirs()) return null;
        String pkg = cfg.pkg == null || cfg.pkg.length() == 0
                ? defaultPackage(src.name) : cfg.pkg.trim();
        if (pkg.indexOf('.') < 0) pkg = pkg + ".app";
        String app = cfg.appName == null || cfg.appName.length() == 0 ? src.name : cfg.appName;
        String pkgPath = pkg.replace('.', '/');

        List<String> fs = st.files(src);
        for (int i = 0; i < fs.size(); i++) {
            Utils.copyFile(st.file(src, fs.get(i)), new File(d, "assets/www/" + fs.get(i)));
        }
        Utils.writeText(new File(d, "AndroidManifest.xml"), manifest(pkg, cfg));
        Utils.writeText(new File(d, "src/" + pkgPath + "/MainActivity.java"),
                mainJava(pkg, entry, cfg));
        Utils.writeText(new File(d, "res/values/strings.xml"), strings(app));
        Utils.writeText(new File(d, "res/values/styles.xml"), styles(cfg));
        Utils.writeText(new File(d, "project.properties"), "target=android-28\n");
        Utils.writeText(new File(d, "README.md"), readme(src, pkg, entry, cfg));
        icons(st, src, d, cfg);

        Project np = st.open(n);
        np.description = "APK WebView de " + src.name + " (entrada: " + entry + ")";
        np.type = Types.ANDROID;
        st.save(np);
        return np;
    }

    private static String manifest(String pkg, Config cfg) {
        String orient = cfg.orient == 1 ? "portrait"
                : cfg.orient == 2 ? "landscape" : "unspecified";
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                + "    package=\"" + pkg + "\"\n"
                + "    android:versionCode=\"1\"\n"
                + "    android:versionName=\"1.0\">\n\n"
                + "    <uses-sdk android:minSdkVersion=\"21\" android:targetSdkVersion=\"28\" />\n"
                + "    <uses-permission android:name=\"android.permission.INTERNET\" />\n\n"
                + "    <application\n"
                + "        android:allowBackup=\"true\"\n"
                + "        android:hardwareAccelerated=\"true\"\n"
                + "        android:icon=\"@mipmap/ic_launcher\"\n"
                + "        android:label=\"@string/app_name\"\n"
                + "        android:largeHeap=\"true\"\n"
                + "        android:theme=\"@style/AppTheme\">\n"
                + "        <activity\n"
                + "            android:name=\".MainActivity\"\n"
                + "            android:label=\"@string/app_name\"\n"
                + "            android:configChanges=\"orientation|screenSize|keyboardHidden\"\n"
                + "            android:screenOrientation=\"" + orient + "\">\n"
                + "            <intent-filter>\n"
                + "                <action android:name=\"android.intent.action.MAIN\" />\n"
                + "                <category android:name=\"android.intent.category.LAUNCHER\" />\n"
                + "            </intent-filter>\n"
                + "        </activity>\n"
                + "    </application>\n\n"
                + "</manifest>\n";
    }

    private static String mainJava(String pkg, String entry, Config cfg) {
        StringBuilder s = new StringBuilder();
        s.append("package ").append(pkg).append(";\n\n");
        s.append("import android.app.Activity;\n");
        s.append("import android.content.Intent;\n");
        s.append("import android.net.Uri;\n");
        s.append("import android.os.Bundle;\n");
        s.append("import android.webkit.WebSettings;\n");
        s.append("import android.webkit.WebView;\n");
        s.append("import android.webkit.WebViewClient;\n\n");
        s.append("/** Wrapper WebView generado por Project Manager AI. */\n");
        s.append("public class MainActivity extends Activity {\n\n");
        s.append("    private WebView web;\n\n");
        s.append("    protected void onCreate(Bundle b) {\n");
        s.append("        super.onCreate(b);\n");
        if (cfg.keepOn) {
            s.append("        getWindow().addFlags(")
                    .append("android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);\n");
        }
        if (cfg.fullscreen) {
            s.append("        getWindow().setFlags(")
                    .append("android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,\n")
                    .append("                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);\n");
        }
        s.append("        web = new WebView(this);\n");
        s.append("        setContentView(web);\n");
        s.append("        WebSettings s = web.getSettings();\n");
        s.append("        s.setJavaScriptEnabled(true);\n");
        s.append("        s.setDomStorageEnabled(true);\n");
        s.append("        s.setAllowFileAccess(true);\n");
        s.append("        s.setAllowContentAccess(true);\n");
        s.append("        s.setLoadWithOverviewMode(true);\n");
        s.append("        s.setUseWideViewPort(true);\n");
        s.append("        s.setSupportZoom(true);\n");
        s.append("        s.setBuiltInZoomControls(true);\n");
        s.append("        s.setDisplayZoomControls(false);\n");
        s.append("        web.setBackgroundColor(0xFF0A0E1C);\n");
        s.append("        web.setWebViewClient(new WebViewClient() {\n");
        s.append("            public boolean shouldOverrideUrlLoading(WebView view, String url) {\n");
        s.append("                if (url != null && url.startsWith(\"file://\")) return false;\n");
        s.append("                try {\n");
        s.append("                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));\n");
        s.append("                } catch (Exception e) {\n");
        s.append("                    // ignorado\n");
        s.append("                }\n");
        s.append("                return true;\n");
        s.append("            }\n");
        s.append("        });\n");
        s.append("        web.loadUrl(\"file:///android_asset/www/").append(entry).append("\");\n");
        s.append("    }\n\n");
        s.append("    public void onBackPressed() {\n");
        s.append("        if (web != null && web.canGoBack()) {\n");
        s.append("            web.goBack();\n");
        s.append("            return;\n");
        s.append("        }\n");
        s.append("        super.onBackPressed();\n");
        s.append("    }\n");
        s.append("}\n");
        return s.toString();
    }

    private static String strings(String app) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n"
                + "    <string name=\"app_name\">" + app.replace("&", "&amp;")
                .replace("<", "&lt;").replace(">", "&gt;") + "</string>\n"
                + "</resources>\n";
    }

    private static String styles(Config cfg) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n"
                + "    <style name=\"AppTheme\" parent=\"android:Theme.Material.NoActionBar\">\n"
                + "        <item name=\"android:colorPrimary\">#7C5CFF</item>\n"
                + "        <item name=\"android:colorAccent\">#22D3EE</item>\n"
                + "        <item name=\"android:windowBackground\">#0A0E1C</item>\n"
                + "        <item name=\"android:statusBarColor\">#05070F</item>\n"
                + "        <item name=\"android:windowFullscreen\">"
                + (cfg.fullscreen ? "true" : "false") + "</item>\n"
                + "    </style>\n</resources>\n";
    }

    private static String readme(Project src, String pkg, String entry, Config cfg) {
        return "# " + src.name + " (APK WebView)\n\n"
                + "Proyecto Android generado por Project Manager AI que empaqueta el\n"
                + "proyecto web '" + src.name + "' dentro de un WebView.\n\n"
                + "- Paquete: " + pkg + "\n"
                + "- Entrada: assets/www/" + entry + "\n"
                + "- Orientacion: " + (cfg.orient == 1 ? "portrait"
                        : cfg.orient == 2 ? "landscape" : "auto") + "\n"
                + "- Pantalla completa: " + (cfg.fullscreen ? "si" : "no") + "\n"
                + "- Pantalla siempre encendida: " + (cfg.keepOn ? "si" : "no") + "\n\n"
                + "Compilar: AIDE 3.2.2 > Project > Open > esta carpeta > Run.\n"
                + "(Java 1.7, API 27/28, sin dependencias externas.)\n";
    }

    private static void icons(Storage st, Project src, File dst, Config cfg) {
        Bitmap base = null;
        if (cfg.iconPath != null && cfg.iconPath.length() > 0) {
            File f = st.file(src, cfg.iconPath);
            if (f.isFile()) base = BitmapFactory.decodeFile(f.getAbsolutePath());
        }
        if (base == null) {
            File cover = CoverManager.coverFile(src);
            if (cover != null) base = BitmapFactory.decodeFile(cover.getAbsolutePath());
        }
        if (base == null) base = defaultIcon(src);
        if (base == null) return;
        for (int i = 0; i < DENS_PX.length; i++) {
            Bitmap sc = Bitmap.createScaledBitmap(base, DENS_PX[i], DENS_PX[i], true);
            ImageGen.saveBitmap(new File(dst,
                    "res/mipmap-" + DENS_NAMES[i] + "/ic_launcher.png"), sc, "png");
            if (sc != base) sc.recycle();
        }
        base.recycle();
    }

    /** Icono por defecto: degradado + inicial del proyecto, dibujado por la app. */
    private static Bitmap defaultIcon(Project src) {
        try {
            String initial = src.name.length() == 0 ? "W"
                    : src.name.substring(0, 1).toUpperCase();
            JSONObject o = new JSONObject();
            o.put("w", 512);
            o.put("h", 512);
            JSONObject bg = new JSONObject();
            bg.put("type", "linear");
            bg.put("angle", 315);
            JSONArray cols = new JSONArray();
            cols.put("#5B28E0");
            cols.put("#0E7FA8");
            bg.put("colors", cols);
            o.put("bg", bg);
            JSONArray sh = new JSONArray();
            JSONObject t = new JSONObject();
            t.put("type", "text");
            t.put("text", initial);
            t.put("x", 0.5);
            t.put("y", 0.56);
            t.put("size", 0.44);
            t.put("color", "#FFFFFF");
            t.put("align", "center");
            t.put("bold", true);
            sh.put(t);
            o.put("shapes", sh);
            return ImageGen.renderSpec(o);
        } catch (Throwable t) {
            return null;
        }
    }
}
