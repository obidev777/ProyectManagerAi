package com.pm.ai.core;

/** Plantillas iniciales por tipo. Devuelve pares {ruta, contenido}. */
public class ProjectTemplates {

    public static String[][] files(Project p, String name) {
        String t = p.type == null ? Types.TEXT : p.type;
        if (Types.HTML.equals(t)) return html(p, name);
        if (Types.PYTHON.equals(t)) return python(p, name);
        if (Types.ANDROID.equals(t)) return android(p, name);
        if (Types.JAVA.equals(t)) return java(p, name);
        if (Types.NODE.equals(t)) return node(p, name);
        if (Types.CPP.equals(t)) return cpp(p, name);
        return text(p, name);
    }

    private static String desc(Project p) {
        String d = p.description == null ? "" : p.description.trim();
        if (d.length() == 0) d = p.name;
        return d;
    }

    private static String id(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) sb.append(c);
            else sb.append('_');
        }
        String r = sb.toString().toLowerCase();
        while (r.startsWith("_")) r = r.substring(1);
        if (r.length() == 0) r = "app";
        if (r.length() > 24) r = r.substring(0, 24);
        return r;
    }

    private static String[][] html(Project p, String name) {
        return new String[][]{
            {"index.html", "<!DOCTYPE html>\n<html lang=\"es\">\n<head>\n  <meta charset=\"UTF-8\">\n"
                + "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                + "  <title>" + name + "</title>\n  <link rel=\"stylesheet\" href=\"css/styles.css\">\n</head>\n<body>\n"
                + "  <header class=\"top\">\n    <h1>" + name + "</h1>\n    <p>" + desc(p) + "</p>\n  </header>\n"
                + "  <main id=\"app\"></main>\n  <script src=\"js/app.js\"></script>\n</body>\n</html>\n"},
            {"css/styles.css", ":root { --bg:#0a0e1c; --card:#151d38; --txt:#eaf0ff; --acc:#7c5cff; --acc2:#22d3ee; }\n"
                + "* { box-sizing:border-box; margin:0; padding:0; }\n"
                + "body { font-family:system-ui,Roboto,sans-serif; background:var(--bg); color:var(--txt); min-height:100vh; }\n"
                + ".top { padding:28px 20px; background:linear-gradient(135deg,#5b28e0,#0e7fa8); border-radius:0 0 24px 24px; }\n"
                + ".top h1 { font-size:24px; }\n.top p { opacity:.8; font-size:13px; margin-top:6px; }\n#app { padding:20px; }\n"},
            {"js/app.js", "(function () {\n  'use strict';\n  var app = document.getElementById('app');\n"
                + "  app.innerHTML = '<p>Listo. Edita este proyecto con Qwen3-Max.</p>';\n})();\n"},
            {"README.md", "# " + name + "\n\n" + desc(p) + "\n\nAbre index.html con el boton Ejecutar.\n"}
        };
    }

    private static String[][] python(Project p, String name) {
        return new String[][]{
            {"main.py", "#!/usr/bin/env python3\n# -*- coding: utf-8 -*-\n# " + name + "\n# " + desc(p) + "\n\n\n"
                + "def main():\n    print('Hola desde " + name + "')\n\n\nif __name__ == '__main__':\n    main()\n"},
            {"requirements.txt", "# dependencias (una por linea)\n"},
            {"README.md", "# " + name + "\n\n" + desc(p) + "\n\nEjecutar: python3 main.py\n"}
        };
    }

    private static String[][] android(Project p, String name) {
        String pkg = "com.app." + id(name);
        String pkgPath = pkg.replace('.', '/');
        return new String[][]{
            {"AndroidManifest.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                + "    package=\"" + pkg + "\"\n    android:versionCode=\"1\"\n    android:versionName=\"1.0\">\n\n"
                + "    <uses-sdk android:minSdkVersion=\"21\" android:targetSdkVersion=\"28\" />\n\n"
                + "    <application android:allowBackup=\"true\" android:label=\"@string/app_name\"\n"
                + "        android:theme=\"@style/AppTheme\">\n"
                + "        <activity android:name=\".MainActivity\">\n"
                + "            <intent-filter>\n"
                + "                <action android:name=\"android.intent.action.MAIN\" />\n"
                + "                <category android:name=\"android.intent.category.LAUNCHER\" />\n"
                + "            </intent-filter>\n        </activity>\n    </application>\n\n</manifest>\n"},
            {"project.properties", "target=android-28\n"},
            {"src/" + pkgPath + "/MainActivity.java", "package " + pkg + ";\n\n"
                + "import android.app.Activity;\nimport android.os.Bundle;\nimport android.widget.TextView;\n\n"
                + "public class MainActivity extends Activity {\n\n"
                + "    protected void onCreate(Bundle savedInstanceState) {\n"
                + "        super.onCreate(savedInstanceState);\n"
                + "        setContentView(R.layout.activity_main);\n"
                + "        TextView tv = (TextView) findViewById(R.id.tvHello);\n"
                + "        if (tv != null) tv.setText(\"" + name + "\");\n    }\n}\n"},
            {"res/layout/activity_main.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                + "    android:layout_width=\"match_parent\" android:layout_height=\"match_parent\"\n"
                + "    android:background=\"#0A0E1C\" android:gravity=\"center\" android:orientation=\"vertical\">\n\n"
                + "    <TextView android:id=\"@+id/tvHello\" android:layout_width=\"wrap_content\"\n"
                + "        android:layout_height=\"wrap_content\" android:text=\"@string/app_name\"\n"
                + "        android:textColor=\"#EAF0FF\" android:textSize=\"22sp\" android:textStyle=\"bold\" />\n\n"
                + "</LinearLayout>\n"},
            {"res/values/strings.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n"
                + "    <string name=\"app_name\">" + name + "</string>\n</resources>\n"},
            {"res/values/styles.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n"
                + "    <style name=\"AppTheme\" parent=\"android:Theme.Material.NoActionBar\">\n"
                + "        <item name=\"android:colorPrimary\">#7C5CFF</item>\n"
                + "        <item name=\"android:colorAccent\">#22D3EE</item>\n"
                + "        <item name=\"android:windowBackground\">#0A0E1C</item>\n"
                + "        <item name=\"android:statusBarColor\">#05070F</item>\n"
                + "    </style>\n</resources>\n"},
            {"README.md", "# " + name + " (Android / AIDE)\n\n" + desc(p) + "\n\nPaquete: " + pkg + "\n"}
        };
    }

    private static String[][] java(Project p, String name) {
        return new String[][]{
            {"src/Main.java", "public class Main {\n    public static void main(String[] args) {\n"
                + "        System.out.println(\"" + name + "\");\n    }\n}\n"},
            {"README.md", "# " + name + "\n\n" + desc(p) + "\n\nCompilar: javac -d bin src/Main.java\n"}
        };
    }

    private static String[][] node(Project p, String name) {
        return new String[][]{
            {"package.json", "{\n  \"name\": \"" + id(name) + "\",\n  \"version\": \"1.0.0\",\n"
                + "  \"main\": \"index.js\",\n  \"scripts\": { \"start\": \"node index.js\" }\n}\n"},
            {"index.js", "'use strict';\n\nconsole.log('" + name + " iniciado');\n"},
            {"README.md", "# " + name + "\n\n" + desc(p) + "\n\nEjecutar: npm start\n"}
        };
    }

    private static String[][] cpp(Project p, String name) {
        return new String[][]{
            {"main.cpp", "#include <iostream>\n\nint main() {\n    std::cout << \"" + name + "\" << std::endl;\n    return 0;\n}\n"},
            {"Makefile", "CXX = g++\nCXXFLAGS = -std=c++11 -Wall -O2\n\nall: app\n\napp: main.cpp\n\t$(CXX) $(CXXFLAGS) -o app main.cpp\n\nclean:\n\trm -f app\n"},
            {"README.md", "# " + name + "\n\n" + desc(p) + "\n\nCompilar: make && ./app\n"}
        };
    }

    private static String[][] text(Project p, String name) {
        return new String[][]{
            {"README.md", "# " + name + "\n\n" + desc(p) + "\n"}
        };
    }
}
