package com.pm.ai.core;

import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Construye los mega-prompts para Qwen3-Max con el PROTOCOLO PM v2.1.
 * El modelo NO crea archivos: devuelve texto con marcadores que la app
 * interpreta y materializa, incluidas IMAGENES y AUDIOS generados en el movil.
 */
public class PromptBuilder {

    public static final String MODE_CREATE = "CREATE";
    public static final String MODE_UPDATE = "UPDATE";
    public static final String MODE_FIX = "FIX";
    public static final String MODE_RANGE = "RANGE";
    public static final String MODE_CONTINUE = "CONTINUE";
    public static final String MODE_REFACTOR = "REFACTOR";
    public static final String MODE_ASSET = "ASSET";
    public static final String[] MODES = {MODE_CREATE, MODE_UPDATE, MODE_FIX, MODE_RANGE,
            MODE_CONTINUE, MODE_REFACTOR, MODE_ASSET};

    public static String modeLabel(String m) {
        if (MODE_UPDATE.equals(m)) return "MEJORAR";
        if (MODE_FIX.equals(m)) return "CORREGIR";
        if (MODE_RANGE.equals(m)) return "PUNTUAL";
        if (MODE_CONTINUE.equals(m)) return "CONTINUAR";
        if (MODE_REFACTOR.equals(m)) return "REFACTOR";
        if (MODE_ASSET.equals(m)) return "ASSETS";
        return "CREAR";
    }

    public static String modeHint(String m) {
        if (MODE_FIX.equals(m)) {
            return "Pega el error completo (log de AIDE, consola, traceback) y que esperabas.";
        }
        if (MODE_RANGE.equals(m)) {
            return "Elige archivo y rango: Qwen devolvera SOLO esas lineas nuevas.";
        }
        if (MODE_UPDATE.equals(m)) {
            return "Describe el cambio o la nueva funcionalidad. Se pedira parche minimo.";
        }
        if (MODE_CONTINUE.equals(m)) {
            return "Elige el archivo cortado: se enviara su cola para retomarlo sin repetir.";
        }
        if (MODE_REFACTOR.equals(m)) {
            return "Describe la reestructuracion: mismo comportamiento, mejor codigo.";
        }
        if (MODE_ASSET.equals(m)) {
            return "Describe las imagenes y sonidos: la app los DIBUJA y SINTETIZA en el movil.";
        }
        return "Describe el proyecto completo: pantallas, funciones, datos, estilo y restricciones.";
    }

    public static String protocol() {
        StringBuilder s = new StringBuilder();
        s.append("================ PROTOCOLO PM v2.1 (SALIDA OBLIGATORIA) ================\n\n");
        s.append("[REGLAS ABSOLUTAS]\n");
        s.append("R1. NO tienes acceso a ningun sistema de archivos ni herramienta. NO crees,\n");
        s.append("    abras ni ejecutes archivos. Tu UNICA salida es TEXTO PLANO con marcadores.\n");
        s.append("R2. PROHIBIDO anadir texto fuera de los marcadores (solo PLAN, DIAGNOSIS,\n");
        s.append("    SUMMARY y NEXT).\n");
        s.append("R3. Cada archivo va en un bloque @@PM_FILE ... @@PM_END_FILE con @@PM_PATH\n");
        s.append("    RELATIVO a la raiz del proyecto y con barras '/'.\n");
        s.append("R4. REGLA DE ORO = MINIMA INTERVENCION. Si el archivo existe y solo cambia una\n");
        s.append("    parte, NO lo reescribas: usa EDIT_RANGE (lineas) o EDIT (FIND/REPLACE).\n");
        s.append("R5. El contenido entre @@PM_CODE_START y @@PM_CODE_END va EXACTO y COMPLETO,\n");
        s.append("    sin '...', sin '// resto igual', sin vallas markdown y SIN los numeros de\n");
        s.append("    linea del contexto.\n");
        s.append("R6. ORDEN: configuracion/manifest, recursos e imagenes, codigo por capas\n");
        s.append("    (modelo -> nucleo -> interfaz), audio y documentacion al final.\n");
        s.append("R7. Si se te acaba el espacio a mitad de un archivo: @@PM_STATUS: INCOMPLETE,\n");
        s.append("    cierra con @@PM_END_FILE y DETENTE. No resumas ni inventes lo que falta.\n");
        s.append("R8. No repitas archivos que no cambian.\n");
        s.append("R9. Empieza SIEMPRE con @@PM_START y termina SIEMPRE con @@PM_END.\n\n");
        s.append("[MARCADORES]\n");
        s.append("@@PM_START\n@@PM_PROJECT: <nombre>\n");
        s.append("@@PM_MODE: CREATE | UPDATE | FIX | RANGE | CONTINUE | REFACTOR | ASSET\n");
        s.append("@@PM_DIAGNOSIS: <causa raiz, solo en FIX>\n");
        s.append("@@PM_PLAN\n1. <paso y archivo>\n@@PM_END_PLAN\n\n");
        s.append("@@PM_FILE\n");
        s.append("@@PM_ACTION: CREATE | REPLACE | EDIT | EDIT_RANGE | INSERT_AFTER | DELETE_LINES\n");
        s.append("             | DELETE | RENAME | CONTINUE | APPEND | CREATE_IMAGE | CREATE_AUDIO\n");
        s.append("@@PM_PATH: ruta/relativa\n@@PM_TARGET: <solo RENAME>\n");
        s.append("@@PM_LANG / @@PM_NOTE / @@PM_STATUS / @@PM_END_FILE\n");
        s.append("@@PM_FORMAT: SPEC | VECTOR | SVG | BASE64 | TEXT   (solo assets)\n");
        s.append("@@PM_FROM_LINE / @@PM_TO_LINE / @@PM_AFTER_LINE   (solo rangos)\n\n");
        s.append("[A] ARCHIVO NUEVO O COMPLETO\n");
        s.append("@@PM_ACTION: CREATE (nuevo) o REPLACE (reescribir entero)\n");
        s.append("@@PM_CODE_START <contenido completo> @@PM_CODE_END\n\n");
        s.append("[B] EDICION POR RANGO DE LINEAS  <- la que ahorra tokens\n");
        s.append("@@PM_ACTION: EDIT_RANGE\n@@PM_PATH: js/app.js\n");
        s.append("@@PM_FROM_LINE: 42\n@@PM_TO_LINE: 57\n");
        s.append("@@PM_CODE_START <solo las lineas nuevas, sin numerar> @@PM_CODE_END\n");
        s.append("Puedes emitir varios EDIT_RANGE del mismo archivo si los rangos NO se solapan.\n\n");
        s.append("[C] INSERTAR / BORRAR LINEAS\n");
        s.append("@@PM_ACTION: INSERT_AFTER + @@PM_AFTER_LINE: 41 + CODE_START/END\n");
        s.append("@@PM_ACTION: DELETE_LINES + @@PM_FROM_LINE: 88 + @@PM_TO_LINE: 95 (sin codigo)\n\n");
        s.append("[D] EDICION LITERAL (si no conoces los numeros de linea)\n");
        s.append("@@PM_ACTION: EDIT\n@@PM_EDIT_START\n@@PM_FIND_START <texto exacto> @@PM_FIND_END\n");
        s.append("@@PM_REPLACE_START <texto nuevo> @@PM_REPLACE_END\n@@PM_EDIT_END\n\n");
        s.append("[E] CONTINUAR UN ARCHIVO CORTADO\n");
        s.append("@@PM_ACTION: CONTINUE + CODE_START con SOLO lo que falta.\n\n");
        s.append(assetProtocol());
        s.append("@@PM_SUMMARY\n<que se ha hecho y como verificarlo>\n");
        s.append("@@PM_NEXT\n<que pedirme en la siguiente iteracion>\n@@PM_END\n");
        s.append("========================================================================\n");
        return s.toString();
    }

    /** Seccion del protocolo dedicada a imagenes y audios generados en la app. */
    public static String assetProtocol() {
        StringBuilder s = new StringBuilder();
        s.append("[F] IMAGENES GENERADAS POR LA APP  (no puedes enviar binarios)\n");
        s.append("Tienes 4 formatos. Elige con @@PM_FORMAT y pon el contenido en CODE_START.\n\n");
        s.append("F1) SPEC  -> JSON que la app DIBUJA con Canvas. Ideal para iconos, logos,\n");
        s.append("    fondos, splash, botones, texturas. Salida .png .jpg .webp\n");
        s.append("@@PM_FILE\n@@PM_ACTION: CREATE_IMAGE\n@@PM_PATH: assets/logo.png\n");
        s.append("@@PM_FORMAT: SPEC\n@@PM_NOTE: logo con degradado\n@@PM_CODE_START\n");
        s.append("{\n");
        s.append("  \"w\": 512, \"h\": 512,\n");
        s.append("  \"bg\": {\"type\":\"linear\",\"angle\":315,\"colors\":[\"#5B28E0\",\"#22D3EE\"]},\n");
        s.append("  \"shapes\": [\n");
        s.append("    {\"type\":\"rrect\",\"x\":0.08,\"y\":0.08,\"w\":0.84,\"h\":0.84,\"r\":0.16,\n");
        s.append("     \"fill\":\"#FFFFFF\",\"alpha\":0.18},\n");
        s.append("    {\"type\":\"circle\",\"cx\":0.5,\"cy\":0.42,\"r\":0.18,\"fill\":\"#22D3EE\"},\n");
        s.append("    {\"type\":\"path\",\"viewport\":24,\"d\":\"M6,18 L12,6 L18,18 Z\",\n");
        s.append("     \"stroke\":\"#FFFFFF\",\"strokeWidth\":2,\"fill\":\"none\"},\n");
        s.append("    {\"type\":\"text\",\"text\":\"PM AI\",\"x\":0.5,\"y\":0.78,\"size\":0.11,\n");
        s.append("     \"color\":\"#FFFFFF\",\"align\":\"center\",\"bold\":true}\n");
        s.append("  ]\n}\n@@PM_CODE_END\n@@PM_STATUS: COMPLETE\n@@PM_END_FILE\n\n");
        s.append("    Reglas del SPEC: w/h en pixeles (max 2048). bg puede ser \"#RRGGBB\" o\n");
        s.append("    {\"type\":\"linear\"|\"radial\",\"angle\":0-360,\"colors\":[...]}. En shapes:\n");
        s.append("    type = rect | rrect | circle | ellipse | line | path | text.\n");
        s.append("    COORDENADAS: si el valor es <= 1 es fraccion del ancho/alto; si es > 1 son\n");
        s.append("    pixeles. fill/stroke = \"#RRGGBB\", \"#AARRGGBB\", nombre CSS o \"none\";\n");
        s.append("    tambien aceptan {\"type\":\"linear\",...}. alpha 0..1. r = radio/esquina.\n");
        s.append("    path: \"d\" con path data SVG (M L H V C S Q T A Z) y \"viewport\" (defecto 24).\n");
        s.append("    text: text, size, color, align (left|center|right), bold, font (sans|mono).\n\n");
        s.append("F2) VECTOR -> path data, una por linea, para iconos. Salida .xml (VectorDrawable)\n");
        s.append("    o .png (la app lo rasteriza). Prefijos: S: trazo blanco, F: relleno,\n");
        s.append("    M: ambas. Viewport 24x24.\n");
        s.append("@@PM_ACTION: CREATE_IMAGE\n@@PM_PATH: res/drawable/ic_star.xml\n");
        s.append("@@PM_FORMAT: VECTOR\n@@PM_CODE_START\n");
        s.append("S:M12,3.6 L14.6,9.4 L21,10.1 L16.2,14.4 L17.6,20.6 L12,17.4 L6.4,20.6 L7.8,14.4 L3,10.1 L9.4,9.4 Z\n");
        s.append("@@PM_CODE_END\n\n");
        s.append("F3) SVG -> documento SVG completo. Salida .svg (texto), .xml (VectorDrawable)\n");
        s.append("    o .png (rasterizado; soporta path, circle y rect).\n");
        s.append("@@PM_ACTION: CREATE_IMAGE\n@@PM_PATH: img/ola.svg\n@@PM_FORMAT: SVG\n\n");
        s.append("F4) BASE64 -> si te dan datos en base64, reenvialos tal cual.\n");
        s.append("@@PM_ACTION: CREATE_IMAGE\n@@PM_PATH: assets/foto.png\n@@PM_FORMAT: BASE64\n\n");
        s.append("[G] AUDIOS GENERADOS POR LA APP\n");
        s.append("G1) SPEC -> JSON que la app SINTETIZA a WAV real (PCM 16 bits).\n");
        s.append("@@PM_FILE\n@@PM_ACTION: CREATE_AUDIO\n@@PM_PATH: assets/click.wav\n");
        s.append("@@PM_FORMAT: SPEC\n@@PM_NOTE:??\n@@PM_CODE_START\n");
        s.append("{\n");
        s.append("  \"sampleRate\": 44100, \"channels\": 1, \"volume\": 0.85,\n");
        s.append("  \"notes\": [\n");
        s.append("    {\"note\":\"C5\",\"dur\":0.12,\"wave\":\"sine\",\"vol\":0.9,\"attack\":0.005},\n");
        s.append("    {\"note\":\"G5\",\"dur\":0.18,\"wave\":\"triangle\",\"vol\":0.7},\n");
        s.append("    {\"freq\":220,\"freq2\":880,\"dur\":0.4,\"wave\":\"saw\",\"vol\":0.4}\n");
        s.append("  ]\n}\n@@PM_CODE_END\n@@PM_STATUS: COMPLETE\n@@PM_END_FILE\n\n");
        s.append("    Campos: sampleRate (8000-48000), channels (1|2), volume (0..1), duration.\n");
        s.append("    \"notes\": secuencia; cada nota {note:\"A4\"|\"C#5\"|\"Bb3\"|freq:440|midi:69,\n");
        s.append("      dur (seg), wave: sine|square|saw|tri|noise|bell, vol, attack, release,\n");
        s.append("      freq2 (barrido), chord:[\"C4\",\"E4\",\"G4\"]}.\n");
        s.append("    \"tones\": igual pero con \"start\" absoluto (se solapan, para ambientes).\n");
        s.append("    \"melody\": \"C4:0.25 D4:0.25 E4:0.5 R:0.25\" (R = silencio) + \"bpm\":120\n");
        s.append("      (con bpm las duraciones son tiempos, no segundos).\n");
        s.append("    IMPORTANTE: SPEC solo genera .wav. Para mp3/ogg usa BASE64.\n");
        s.append("G2) BASE64 -> escribe el binario tal cual (.mp3 .ogg .wav .m4a).\n\n");
        s.append("[H] CUANDO USAR ASSETS\n");
        s.append("- Proyecto Android: iconos en res/drawable/*.xml (VECTOR) y PNG en res/mipmap-*.\n");
        s.append("- Proyecto web: imagenes en img/ o assets/ (.svg o .png) y sonidos en audio/.\n");
        s.append("- Referencia los archivos creados en el codigo con la MISMA ruta relativa.\n");
        s.append("- No inventes binarios: si no puedes describirlo con SPEC/VECTOR/SVG, dilo en\n");
        s.append("  @@PM_WARN y propone una alternativa dibujable.\n\n");
        return s.toString();
    }

    public static String numbered(String content, int from, int to) {
        List<String> ls = Utils.splitLines(content == null ? "" : content);
        if (ls.size() == 0) return "(archivo vacio)\n";
        int a = from < 1 ? 1 : from;
        int b = to <= 0 || to > ls.size() ? ls.size() : to;
        int w = String.valueOf(b).length();
        StringBuilder s = new StringBuilder();
        for (int i = a; i <= b; i++) {
            s.append(Utils.padLeft(String.valueOf(i), w)).append("| ").append(ls.get(i - 1)).append("\n");
        }
        return s.toString();
    }

    public static String tree(Storage st, Project p) {
        List<String> t = st.tree(p);
        if (t.size() == 0) return "(proyecto vacio)\n";
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < t.size(); i++) s.append(t.get(i)).append("\n");
        return s.toString();
    }

    public static String fileBlock(Storage st, Project p, String rel, int limit, boolean numbers) {
        File f = st.file(p, rel);
        if (!f.isFile()) return "";
        String c = Utils.readText(f);
        int total = Utils.countLines(c);
        boolean cut = false;
        if (limit > 0 && c.length() > limit) {
            c = c.substring(0, limit);
            cut = true;
        }
        StringBuilder s = new StringBuilder();
        s.append("----- ARCHIVO: ").append(rel).append("  (").append(total).append(" lineas) -----\n");
        if (numbers) s.append(numbered(c, 1, Utils.countLines(c)));
        else {
            s.append(c);
            if (!c.endsWith("\n")) s.append("\n");
        }
        if (cut) {
            s.append("... [RECORTADO: primeros ").append(limit).append(" caracteres de ")
                    .append(f.length()).append("] ...\n");
        }
        s.append("----- FIN: ").append(rel).append(" -----\n\n");
        return s.toString();
    }

    public static String contents(Storage st, Project p, List<String> paths, int limit,
                                  boolean numbers) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < paths.size(); i++) {
            s.append(fileBlock(st, p, paths.get(i), limit, numbers));
        }
        return s.toString();
    }

    private static void head(StringBuilder s, Project p, String mode, String modeText) {
        String model = p.model == null || p.model.length() == 0 ? "Qwen3-Max" : p.model;
        s.append("ROL: Eres un ingeniero de software senior experto en ")
                .append(Types.label(p.type)).append(".\n");
        s.append("MODELO DESTINO: ").append(model).append("\n");
        s.append("IDIOMA de comentarios, textos y documentacion: ").append(p.docsLang).append("\n");
        s.append("MODO: ").append(mode).append(" - ").append(modeText).append("\n\n");
        s.append("[PROYECTO]\n");
        s.append("nombre: ").append(p.name).append("\n");
        s.append("tipo:   ").append(Types.label(p.type)).append("\n");
        s.append("raiz:   ").append(p.dir == null ? "" : p.dir.getAbsolutePath()).append("\n\n");
    }

    private static void spec(StringBuilder s, Project p) {
        s.append("[FICHA TECNICA]\n");
        if (p.description != null && p.description.trim().length() > 0) {
            s.append("Descripcion: ").append(p.description.trim()).append("\n\n");
        }
        if (p.features != null && p.features.trim().length() > 0) {
            s.append("Caracteristicas:\n").append(p.features.trim()).append("\n\n");
        }
    }

    private static void rules(StringBuilder s, Project p) {
        s.append("[REGLAS TECNICAS OBLIGATORIAS PARA ESTE TIPO]\n");
        s.append(Types.constraints(p.type)).append("\n");
    }

    public static String build(Storage st, Project p, String mode, String task,
                               boolean withSpec, boolean withTree, boolean withContents,
                               List<String> picked, int limit) {
        return build(st, p, mode, task, withSpec, withTree, withContents, false, picked, limit);
    }

    public static String build(Storage st, Project p, String mode, String task,
                               boolean withSpec, boolean withTree, boolean withContents,
                               boolean numbers, List<String> picked, int limit) {
        StringBuilder s = new StringBuilder();
        String modeText = "CREAR el proyecto COMPLETO desde cero, archivo por archivo.";
        if (MODE_UPDATE.equals(mode)) {
            modeText = "MEJORAR / EDITAR un proyecto YA EXISTENTE. Entrega solo lo que cambia.";
        } else if (MODE_REFACTOR.equals(mode)) {
            modeText = "REFACTORIZAR sin cambiar el comportamiento visible.";
        } else if (MODE_ASSET.equals(mode)) {
            modeText = "GENERAR RECURSOS: imagenes y audios creados por la propia app.";
        }
        head(s, p, mode, modeText);
        if (withSpec) spec(s, p);
        rules(s, p);
        if (withTree) {
            s.append("[ESTADO ACTUAL] Arbol de archivos (raiz = carpeta del proyecto):\n");
            s.append(tree(st, p)).append("\n");
        }
        if (withContents) {
            List<String> paths = picked != null && picked.size() > 0 ? picked : st.files(p);
            s.append("[CONTENIDO ACTUAL]\n");
            if (numbers) {
                s.append("Archivos NUMERADOS: usa esos numeros en @@PM_FROM_LINE / @@PM_TO_LINE.\n");
            }
            s.append("Copia el texto LITERAL en los FIND cuando edites.\n\n");
            s.append(contents(st, p, paths, limit, numbers));
        }
        s.append("[TAREA]\n");
        if (task == null || task.trim().length() == 0) {
            s.append("Construye el proyecto completo segun la ficha tecnica y las reglas.\n\n");
        } else {
            s.append(task.trim()).append("\n\n");
        }
        if (MODE_UPDATE.equals(mode) || MODE_REFACTOR.equals(mode)) {
            s.append("[CRITERIO DE CAMBIO]\n");
            s.append("- Prioriza EDIT_RANGE o EDIT sobre REPLACE.\n");
            s.append("- Indica en @@PM_NOTE que lineas o funcion afecta cada bloque.\n\n");
        }
        if (MODE_ASSET.equals(mode)) {
            s.append("[RECURSOS]\n");
            s.append("- Genera TODAS las imagenes y sonidos con CREATE_IMAGE / CREATE_AUDIO.\n");
            s.append("- Indica la ruta exacta donde el codigo los va a referenciar.\n");
            s.append("- Coherencia visual: misma paleta y estilo en todos los assets.\n\n");
            s.append(assetProtocol());
        }
        s.append(protocol());
        s.append("\n[COMPLETITUD]\n");
        s.append("- Entrega TODO lo necesario para que funcione al primer intento.\n");
        s.append("- Antes de @@PM_END revisa que cada @@PM_FILE tenga PATH, accion y STATUS.\n\n");
        s.append("EMPIEZA TU RESPUESTA AHORA CON: @@PM_START\n");
        return s.toString();
    }

    public static String buildFix(Storage st, Project p, String task, String errorText,
                                  String symptom, String steps, boolean withSpec,
                                  boolean withTree, boolean withContents, boolean numbers,
                                  List<String> picked, int limit) {
        StringBuilder s = new StringBuilder();
        head(s, p, MODE_FIX, "CORREGIR UN ERROR. Diagnostica la causa raiz y entrega el parche minimo.");
        if (withSpec) spec(s, p);
        rules(s, p);
        s.append("[FICHA DEL ERROR]\n");
        if (symptom != null && symptom.trim().length() > 0) {
            s.append("Sintoma (que se ve / que pasa): ").append(symptom.trim()).append("\n\n");
        }
        if (steps != null && steps.trim().length() > 0) {
            s.append("Pasos para reproducirlo:\n").append(steps.trim()).append("\n\n");
        }
        if (errorText != null && errorText.trim().length() > 0) {
            s.append("ERROR / LOG LITERAL:\n----- LOG START -----\n").append(errorText.trim())
                    .append("\n----- LOG END -----\n\n");
        }
        if (task != null && task.trim().length() > 0) {
            s.append("Comentario del desarrollador:\n").append(task.trim()).append("\n\n");
        }
        if (withTree) {
            s.append("[ARBOL DEL PROYECTO]\n").append(tree(st, p)).append("\n");
        }
        if (withContents) {
            List<String> paths = picked != null && picked.size() > 0 ? picked : st.files(p);
            s.append("[ARCHIVOS SOSPECHOSOS, NUMERADOS]\n");
            s.append(contents(st, p, paths, limit, true));
        }
        s.append("[METODO OBLIGATORIO]\n");
        s.append("1. Localiza la causa raiz exacta (archivo + lineas) con el log y el codigo.\n");
        s.append("2. Rellena @@PM_DIAGNOSIS: causa, por que produce ese error y que se toca.\n");
        s.append("3. Entrega el PARCHE MINIMO: EDIT_RANGE con los numeros del contexto, o EDIT\n");
        s.append("   con FIND/REPLACE literal. PROHIBIDO reescribir archivos enteros salvo que\n");
        s.append("   cambie mas de la mitad.\n");
        s.append("4. No anadas funcionalidad nueva ni reordenes codigo que no interviene.\n");
        s.append("5. Si el log no basta, dilo en @@PM_WARN y pide el dato concreto en @@PM_NEXT.\n\n");
        s.append("[ESQUELETO DE RESPUESTA]\n");
        s.append("@@PM_START\n@@PM_MODE: FIX\n@@PM_DIAGNOSIS: <causa raiz>\n");
        s.append("@@PM_FILE\n@@PM_ACTION: EDIT_RANGE\n@@PM_PATH: <archivo>\n");
        s.append("@@PM_FROM_LINE: <n>\n@@PM_TO_LINE: <n>\n@@PM_NOTE: <por que>\n");
        s.append("@@PM_CODE_START\n<lineas nuevas>\n@@PM_CODE_END\n");
        s.append("@@PM_STATUS: COMPLETE\n@@PM_END_FILE\n");
        s.append("@@PM_SUMMARY\n<como verificar que ya no falla>\n@@PM_END\n\n");
        s.append(protocol());
        s.append("\nEMPIEZA TU RESPUESTA AHORA CON: @@PM_START\n");
        return s.toString();
    }

    public static String buildRange(Storage st, Project p, String task, String path,
                                    int from, int to, int ctxLines, boolean withTree, int limit) {
        File f = st.file(p, path);
        String content = f.isFile() ? Utils.readText(f) : "";
        int total = Utils.countLines(content);
        if (total == 0) total = 1;
        int a = from < 1 ? 1 : from;
        int b = to < a ? a : to;
        if (b > total) b = total;
        int ctx = ctxLines < 0 ? 0 : ctxLines;
        int wa = a - ctx < 1 ? 1 : a - ctx;
        int wb = b + ctx > total ? total : b + ctx;

        StringBuilder s = new StringBuilder();
        head(s, p, MODE_RANGE,
                "EDICION PUNTUAL POR RANGO DE LINEAS (prohibido devolver el archivo entero).");
        rules(s, p);
        if (p.description != null && p.description.trim().length() > 0) {
            s.append("[CONTEXTO DEL PROYECTO]\n").append(p.description.trim()).append("\n\n");
        }
        s.append("[OBJETIVO]\n");
        s.append("Archivo: ").append(path).append("  (").append(total).append(" lineas)\n");
        s.append("Sustituir EXACTAMENTE las lineas ").append(a).append(" a ").append(b).append(".\n");
        s.append("NO entregues el archivo completo. NO repitas lineas que no cambian.\n");
        s.append("NO incluyas los numeros de linea en el contenido devuelto.\n\n");
        s.append("[CAMBIO PEDIDO]\n");
        s.append(task == null || task.trim().length() == 0
                ? "(describe aqui el cambio exacto)" : task.trim()).append("\n\n");
        if (withTree) {
            s.append("[ARBOL DEL PROYECTO]\n").append(tree(st, p)).append("\n");
        }
        s.append("[ARCHIVO NUMERADO]  ventana mostrada: ").append(wa).append("-").append(wb).append("\n");
        s.append("----- ARCHIVO: ").append(path).append(" -----\n");
        s.append(numbered(content, wa, wb));
        s.append("----- FIN: ").append(path).append(" -----\n\n");
        s.append("[FORMATO EXACTO DE TU RESPUESTA]\n");
        s.append("@@PM_START\n@@PM_MODE: RANGE\n@@PM_FILE\n@@PM_ACTION: EDIT_RANGE\n");
        s.append("@@PM_PATH: ").append(path).append("\n");
        s.append("@@PM_FROM_LINE: ").append(a).append("\n@@PM_TO_LINE: ").append(b).append("\n");
        s.append("@@PM_NOTE: <una linea>\n@@PM_CODE_START\n");
        s.append("<solo las lineas nuevas que sustituyen a ").append(a).append("-").append(b).append(">\n");
        s.append("@@PM_CODE_END\n@@PM_STATUS: COMPLETE\n@@PM_END_FILE\n");
        s.append("(si hay que tocar otras lineas u otros archivos, anade mas bloques @@PM_FILE\n");
        s.append(" con sus propios rangos; nunca reescribas el archivo entero)\n");
        s.append("@@PM_SUMMARY\n<que cambia y como comprobarlo>\n@@PM_END\n\n");
        s.append(protocol());
        s.append("\nEMPIEZA TU RESPUESTA AHORA CON: @@PM_START\n");
        return s.toString();
    }

    public static String continuePrompt(Storage st, Project p, String path) {
        String partial = PendingManager.get(p, path);
        if (partial == null) {
            File f = st.file(p, path);
            partial = f.isFile() ? Utils.readText(f) : "";
        }
        int tailLines = 30;
        int total = Utils.countLines(partial);
        int firstShown = total - tailLines + 1;
        if (firstShown < 1) firstShown = 1;

        StringBuilder s = new StringBuilder();
        head(s, p, MODE_CONTINUE, "CONTINUAR UN ARCHIVO QUE SE QUEDO CORTADO.");
        rules(s, p);
        s.append("[SITUACION]\n");
        s.append("El archivo '").append(path).append("' se quedo a medias: ").append(partial.length())
                .append(" caracteres en ").append(total).append(" lineas.\n");
        s.append("ULTIMAS lineas ya escritas (").append(firstShown).append("-").append(total).append("):\n\n");
        s.append("@@PM_CONTEXT_START\n");
        s.append(numbered(partial, firstShown, total));
        s.append("@@PM_CONTEXT_END\n\n");
        s.append("[INSTRUCCIONES]\n");
        s.append("1. Continua EXACTAMENTE donde se corto. NO repitas ninguna linea mostrada.\n");
        s.append("2. Entrega SOLO el texto que falta, sin numeros de linea.\n");
        s.append("3. Formato: @@PM_START / @@PM_MODE: CONTINUE / @@PM_FILE / @@PM_ACTION: CONTINUE\n");
        s.append("   @@PM_PATH: ").append(path).append(" / CODE_START ... CODE_END / STATUS / END_FILE\n");
        s.append("4. Si vuelve a faltarte espacio, pon @@PM_STATUS: INCOMPLETE y para.\n\n");
        s.append("EMPIEZA AHORA CON: @@PM_START\n");
        return s.toString();
    }

    public static List<String> pendingPaths(Project p) {
        return PendingManager.paths(p);
    }
}
