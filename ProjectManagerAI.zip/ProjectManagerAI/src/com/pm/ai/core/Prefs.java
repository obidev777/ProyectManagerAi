package com.pm.ai.core;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferencias globales. */
public class Prefs {

    private static final String NAME = "pm_ai_prefs";

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static String str(Context c, String k, String d) {
        return sp(c).getString(k, d);
    }

    public static void setStr(Context c, String k, String v) {
        sp(c).edit().putString(k, v).apply();
    }

    public static boolean bool(Context c, String k, boolean d) {
        return sp(c).getBoolean(k, d);
    }

    public static void setBool(Context c, String k, boolean v) {
        sp(c).edit().putBoolean(k, v).apply();
    }

    public static int num(Context c, String k, int d) {
        return sp(c).getInt(k, d);
    }

    public static void setNum(Context c, String k, int v) {
        sp(c).edit().putInt(k, v).apply();
    }

    public static String model(Context c) {
        return str(c, "model", "Qwen3-Max");
    }

    public static String docsLang(Context c) {
        return str(c, "docsLang", "Espanol");
    }

    public static boolean backup(Context c) {
        return bool(c, "backup", true);
    }

    public static boolean highlight(Context c) {
        return bool(c, "highlight", true);
    }

    public static boolean gutter(Context c) {
        return bool(c, "gutter", true);
    }

    public static int limit(Context c) {
        return num(c, "limit", 4000);
    }

    // ==================== PATCH V2 ====================
    public static String rootPath(Context c) { return str(c, "rootPath", ""); }
    public static void rootPath(Context c, String v) { str(c, "rootPath", v == null ? "" : v); }
    public static boolean autoPrompts(Context c) { return bool(c, "autoPrompts", true); }
    public static void autoPrompts(Context c, boolean v) { bool(c, "autoPrompts", v); }
    public static boolean useAide(Context c) { return bool(c, "useAide", true); }
    public static void useAide(Context c, boolean v) { bool(c, "useAide", v); }
    public static String aidePkg(Context c) { return str(c, "aidePkg", ""); }
    public static void aidePkg(Context c, String v) { str(c, "aidePkg", v == null ? "" : v); }
    public static boolean previewFull(Context c) { return bool(c, "previewFull", false); }
    public static void previewFull(Context c, boolean v) { bool(c, "previewFull", v); }
    public static int previewOrient(Context c) { return num(c, "previewOrient", 0); }
    public static void previewOrient(Context c, int v) { num(c, "previewOrient", v); }
    public static int ctxLines(Context c) { return num(c, "ctxLines", 12); }
    public static void ctxLines(Context c, int v) { num(c, "ctxLines", v); }
    public static String lastMode(Context c) { return str(c, "lastMode", "CREATE"); }
    public static void lastMode(Context c, String v) { str(c, "lastMode", v == null ? "CREATE" : v); }
}
