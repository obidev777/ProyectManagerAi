package com.pm.ai.core;

import com.pm.ai.util.Utils;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Guarda los archivos que el modelo dejo INCOMPLETOS para poder continuarlos.
 * Fichero: <proyecto>/.pm/pending.json
 */
public class PendingManager {

    private static File file(Project p) {
        return new File(p.pm(), "pending.json");
    }

    public static JSONObject load(Project p) {
        try {
            return new JSONObject(Utils.readText(file(p)));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static void save(Project p, JSONObject o) {
        Utils.writeText(file(p), o.toString());
    }

    public static void put(Project p, String path, String content, String lang) {
        JSONObject o = load(p);
        try {
            JSONObject e = new JSONObject();
            e.put("path", path);
            e.put("lang", lang == null ? "" : lang);
            e.put("chars", content == null ? 0 : content.length());
            e.put("updated", System.currentTimeMillis());
            e.put("content", content == null ? "" : content);
            o.put(path, e);
        } catch (Exception ex) {
            // ignorado
        }
        save(p, o);
    }

    public static String get(Project p, String path) {
        JSONObject o = load(p);
        JSONObject e = o.optJSONObject(path);
        if (e == null) return null;
        return e.optString("content", "");
    }

    public static List<String> paths(Project p) {
        List<String> out = new ArrayList<String>();
        JSONObject o = load(p);
        Iterator<?> it = o.keys();
        while (it.hasNext()) out.add(String.valueOf(it.next()));
        return out;
    }

    public static void remove(Project p, String path) {
        JSONObject o = load(p);
        o.remove(path);
        save(p, o);
    }

    public static int count(Project p) {
        return paths(p).size();
    }
}
