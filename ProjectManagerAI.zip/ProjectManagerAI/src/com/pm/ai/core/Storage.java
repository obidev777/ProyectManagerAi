package com.pm.ai.core;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Gestiona la carpeta raiz de proyectos y su ciclo de vida.
 * V2: la raiz por defecto es una CARPETA PUBLICA NORMAL
 * (/storage/emulated/0/ProjectManagerAI) visible para AIDE, Termux o cualquier
 * explorador. Si el sistema no concede escritura, degrada a la carpeta privada.
 */
public class Storage {

    private static Storage INSTANCE;

    private final Context ctx;
    private File root;

    private Storage(Context c) {
        this.ctx = c.getApplicationContext();
        this.root = resolveRoot(this.ctx);
    }

    public static synchronized Storage get(Context c) {
        if (INSTANCE == null) INSTANCE = new Storage(c);
        return INSTANCE;
    }

    public Context context() {
        return ctx;
    }

    public File getRoot() {
        return root;
    }

    public String rootPath() {
        return root == null ? "" : root.getAbsolutePath();
    }

    public boolean isPublicRoot() {
        try {
            String pub = Environment.getExternalStorageDirectory().getAbsolutePath();
            return rootPath().startsWith(pub);
        } catch (Throwable t) {
            return false;
        }
    }

    public String rootLabel() {
        return isPublicRoot() ? "carpeta publica (visible para AIDE)" : "carpeta privada de la app";
    }

    /** Carpetas candidatas, de mas visible a mas privada. */
    public static File[] candidates(Context ctx) {
        List<File> out = new ArrayList<File>();
        try {
            File ext = Environment.getExternalStorageDirectory();
            if (ext != null) {
                out.add(new File(ext, "ProjectManagerAI"));
                out.add(new File(new File(ext, "Documents"), "ProjectManagerAI"));
            }
        } catch (Throwable t) {
            // ignorado
        }
        try {
            File ef = ctx.getExternalFilesDir(null);
            if (ef != null) out.add(new File(ef, "PM_Projects"));
        } catch (Throwable t) {
            // ignorado
        }
        try {
            out.add(new File(ctx.getFilesDir(), "PM_Projects"));
        } catch (Throwable t) {
            // ignorado
        }
        return out.toArray(new File[out.size()]);
    }

    private static File resolveRoot(Context ctx) {
        String custom = Prefs.rootPath(ctx);
        if (custom != null && custom.trim().length() > 0) {
            File f = new File(custom.trim());
            if (Utils.canWriteDir(f)) return f;
        }
        File[] cands = candidates(ctx);
        for (int i = 0; i < cands.length; i++) {
            if (Utils.canWriteDir(cands[i])) return cands[i];
        }
        File base = null;
        try {
            base = ctx.getExternalFilesDir(null);
        } catch (Throwable t) {
            base = null;
        }
        if (base == null) base = ctx.getFilesDir();
        File f = new File(base, "PM_Projects");
        f.mkdirs();
        return f;
    }

    public static void ensureAccess(Activity a) {
        if (a == null || Build.VERSION.SDK_INT >= 30) return;
        Utils.requestWritePermission(a);
    }

    public static boolean needsAllFilesAccess(Context c) {
        if (Build.VERSION.SDK_INT < 30 || Utils.allFilesAccess()) return false;
        try {
            String pub = Environment.getExternalStorageDirectory().getAbsolutePath();
            File[] cands = candidates(c);
            for (int i = 0; i < cands.length; i++) {
                if (cands[i].getAbsolutePath().startsWith(pub)) return true;
            }
        } catch (Throwable t) {
            return false;
        }
        return false;
    }

    public void reload() {
        root = resolveRoot(ctx);
    }

    public boolean setRoot(String path) {
        Prefs.rootPath(ctx, path == null ? "" : path.trim());
        File f = resolveRoot(ctx);
        boolean changed = !f.getAbsolutePath().equals(root.getAbsolutePath());
        root = f;
        return changed;
    }

    /** Copia todo el contenido de la raiz actual a 'dst' y cambia la raiz. */
    public int migrateTo(File dst) {
        if (dst == null || dst.getAbsolutePath().equals(root.getAbsolutePath())) return 0;
        if (!Utils.canWriteDir(dst)) return -1;
        int n = 0;
        File[] kids = root.listFiles();
        if (kids != null) {
            for (int i = 0; i < kids.length; i++) {
                File k = kids[i];
                File to = new File(dst, k.getName());
                if (k.isDirectory()) {
                    if (copyDir(k, to)) n++;
                } else if (Utils.copyFile(k, to)) {
                    n++;
                }
            }
        }
        Prefs.rootPath(ctx, dst.getAbsolutePath());
        root = dst;
        return n;
    }

    /** Carpeta de la biblioteca global (historial de prompts). */
    public File libraryDir() {
        File f = new File(root, ".pm_library");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public File dirOf(String name) {
        return new File(root, name);
    }

    public List<Project> list() {
        List<Project> out = new ArrayList<Project>();
        File[] kids = root == null ? null : root.listFiles();
        if (kids == null) return out;
        Arrays.sort(kids, new Comparator<File>() {
            public int compare(File a, File b) {
                long la = a.lastModified();
                long lb = b.lastModified();
                if (la < lb) return 1;
                if (la > lb) return -1;
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (int i = 0; i < kids.length; i++) {
            File d = kids[i];
            if (!d.isDirectory() || d.getName().startsWith(".")) continue;
            out.add(open(d.getName()));
        }
        return out;
    }

    public Project open(String name) {
        File d = dirOf(name);
        File meta = new File(new File(d, ".pm"), "project.json");
        Project p;
        if (meta.isFile()) {
            p = Project.fromJson(Utils.readText(meta), d);
            p.dir = d;
        } else {
            p = new Project(d);
            p.name = d.getName();
            p.type = guessType(d);
            p.created = d.lastModified();
            p.updated = d.lastModified();
            p.model = Prefs.model(ctx);
            p.docsLang = Prefs.docsLang(ctx);
        }
        return p;
    }

    private String guessType(File d) {
        if (new File(d, "AndroidManifest.xml").isFile()) return Types.ANDROID;
        if (new File(d, "index.html").isFile()) return Types.HTML;
        if (new File(d, "package.json").isFile()) return Types.NODE;
        if (new File(d, "main.py").isFile() || new File(d, "requirements.txt").isFile()) return Types.PYTHON;
        if (new File(d, "main.cpp").isFile() || new File(d, "Makefile").isFile()) return Types.CPP;
        return Types.TEXT;
    }

    public void save(Project p) {
        if (p == null || p.dir == null) return;
        p.updated = System.currentTimeMillis();
        Utils.writeText(p.metaFile(), p.toJson().toString());
        p.dir.setLastModified(p.updated);
    }

    public String freeName(String base) {
        String n = Utils.safeName(base);
        if (!dirOf(n).exists()) return n;
        int i = 2;
        while (dirOf(n + "-" + i).exists()) i++;
        return n + "-" + i;
    }

    public Project create(String name, String type, String desc, String feat, boolean withTemplate) {
        String n = freeName(name);
        File d = dirOf(n);
        d.mkdirs();
        Project p = new Project(d);
        p.name = n;
        p.type = type == null ? Types.TEXT : type;
        p.description = desc == null ? "" : desc;
        p.features = feat == null ? "" : feat;
        p.model = Prefs.model(ctx);
        p.docsLang = Prefs.docsLang(ctx);
        p.created = System.currentTimeMillis();
        p.updated = p.created;
        new File(d, ".pm").mkdirs();
        if (withTemplate) {
            String[][] t = ProjectTemplates.files(p, n);
            for (int i = 0; i < t.length; i++) Utils.writeText(new File(d, t[i][0]), t[i][1]);
        }
        save(p);
        return p;
    }

    public boolean delete(String name) {
        return Utils.deleteRecursive(dirOf(name));
    }

    public String rename(String oldName, String newName) {
        String n = Utils.safeName(newName);
        if (n.length() == 0) return null;
        File from = dirOf(oldName);
        File to = dirOf(n);
        if (to.exists() || !from.exists()) return null;
        if (!from.renameTo(to)) return null;
        Project p = open(n);
        p.name = n;
        save(p);
        return n;
    }

    public Project duplicate(String name) {
        Project src = open(name);
        String n = freeName(name + "-copia");
        File to = dirOf(n);
        if (!copyDir(src.dir, to)) return null;
        File oldMeta = new File(new File(to, ".pm"), "project.json");
        if (oldMeta.exists()) oldMeta.delete();
        Project p = open(n);
        p.name = n;
        p.created = System.currentTimeMillis();
        save(p);
        return p;
    }

    private boolean copyDir(File src, File dst) {
        if (!src.exists()) return false;
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) return false;
            File[] kids = src.listFiles();
            if (kids == null) return true;
            for (int i = 0; i < kids.length; i++) {
                if (!copyDir(kids[i], new File(dst, kids[i].getName()))) return false;
            }
            return true;
        }
        return Utils.copyFile(src, dst);
    }

    public File file(Project p, String rel) {
        return new File(p.dir, Utils.normPath(rel));
    }

    public String read(Project p, String rel) {
        return Utils.readText(file(p, rel));
    }

    public boolean write(Project p, String rel, String content) {
        boolean ok = Utils.writeText(file(p, rel), content);
        if (ok) touch(p);
        return ok;
    }

    public void touch(Project p) {
        p.updated = System.currentTimeMillis();
        if (p.dir != null) p.dir.setLastModified(p.updated);
    }

    public List<String> files(Project p) {
        List<String> out = new ArrayList<String>();
        walk(p.dir, "", out, false);
        Collections.sort(out);
        return out;
    }

    public List<String> tree(Project p) {
        List<String> out = new ArrayList<String>();
        walk(p.dir, "", out, true);
        Collections.sort(out);
        return out;
    }

    private void walk(File dir, String prefix, List<String> out, boolean dirs) {
        File[] kids = dir == null ? null : dir.listFiles();
        if (kids == null) return;
        for (int i = 0; i < kids.length; i++) {
            File f = kids[i];
            String n = f.getName();
            if (n.equals(".pm")) continue;
            String rel = prefix.length() == 0 ? n : prefix + "/" + n;
            if (f.isDirectory()) {
                if (dirs) out.add(rel + "/");
                walk(f, rel, out, dirs);
            } else {
                out.add(rel);
            }
        }
    }

    public int countFiles(Project p) {
        return files(p).size();
    }

    public File exportZip(Project p) {
        File dir = Utils.exportDir(ctx);
        if (!dir.exists()) dir.mkdirs();
        File zip = new File(dir, p.name + "_" + Utils.stamp() + ".zip");
        if (Utils.zipDir(p.dir, zip)) return zip;
        return null;
    }

    public void savePrompt(Project p, String text) {
        Utils.writeText(new File(p.pm(), "prompts/" + Utils.stamp() + ".txt"), text);
    }

    public void saveResponse(Project p, String text) {
        Utils.writeText(new File(p.pm(), "responses/" + Utils.stamp() + ".txt"), text);
    }

    public long totalSize() {
        return Utils.dirSize(root);
    }

    public int totalFiles() {
        int t = 0;
        List<Project> ps = list();
        for (int i = 0; i < ps.size(); i++) t += countFiles(ps.get(i));
        return t;
    }
}
