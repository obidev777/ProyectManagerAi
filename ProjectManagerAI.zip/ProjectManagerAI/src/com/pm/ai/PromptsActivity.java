package com.pm.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import com.pm.ai.core.PromptBuilder;
import com.pm.ai.core.PromptLibrary;
import com.pm.ai.core.Storage;
import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Historial global de prompts: buscar, filtrar, editar, duplicar y borrar. */
public class PromptsActivity extends Activity {

    private final List<PromptLibrary.Entry> all = new ArrayList<PromptLibrary.Entry>();
    private final List<PromptLibrary.Entry> shown = new ArrayList<PromptLibrary.Entry>();
    private Adapter adapter;
    private ListView lv;
    private LinearLayout emptyBox;
    private EditText etSearch;
    private Spinner spProject;
    private TextView tvSub;
    private String projectFilter = "";
    private boolean loadingFilter = false;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_prompts);
        lv = (ListView) findViewById(R.id.lvPrompts);
        emptyBox = (LinearLayout) findViewById(R.id.emptyBox);
        etSearch = (EditText) findViewById(R.id.etSearch);
        spProject = (Spinner) findViewById(R.id.spProject);
        tvSub = (TextView) findViewById(R.id.tvSub);
        adapter = new Adapter();
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) openEditor(shown.get(pos).id);
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.btnTrash).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                deleteAllDialog();
            }
        });
        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                filter();
            }

            public void afterTextChanged(Editable e) {
            }
        });
    }

    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        all.clear();
        all.addAll(PromptLibrary.all(this));
        buildFilter();
        filter();
    }

    private void buildFilter() {
        List<String> ps = PromptLibrary.projects(this);
        List<String> items = new ArrayList<String>();
        items.add("Todos los proyectos");
        for (int i = 0; i < ps.size(); i++) items.add(ps.get(i));
        if (projectFilter.length() > 0 && !items.contains(projectFilter)) projectFilter = "";
        loadingFilter = true;
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, items);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        spProject.setAdapter(ad);
        int pos = projectFilter.length() == 0 ? 0 : items.indexOf(projectFilter);
        spProject.setSelection(pos < 0 ? 0 : pos);
        spProject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                if (loadingFilter) {
                    loadingFilter = false;
                    return;
                }
                projectFilter = position <= 0 ? "" : String.valueOf(parent.getItemAtPosition(position));
                filter();
            }

            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        loadingFilter = false;
    }

    private void filter() {
        String q = etSearch.getText().toString().trim().toLowerCase(Locale.US);
        shown.clear();
        for (int i = 0; i < all.size(); i++) {
            PromptLibrary.Entry e = all.get(i);
            if (projectFilter.length() > 0 && !e.project.equals(projectFilter)) continue;
            if (q.length() > 0) {
                String hay = (e.title + " " + e.project + " " + e.mode + " " + e.preview)
                        .toLowerCase(Locale.US);
                if (hay.indexOf(q) < 0) continue;
            }
            shown.add(e);
        }
        adapter.notifyDataSetChanged();
        boolean empty = shown.size() == 0;
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        lv.setVisibility(empty ? View.GONE : View.VISIBLE);
        int totalChars = 0;
        for (int i = 0; i < shown.size(); i++) totalChars += shown.get(i).chars;
        tvSub.setText(shown.size() + " de " + all.size() + " prompts | "
                + Utils.humanSize(totalChars) + " | " + Storage.get(this).rootLabel());
    }

    private void openEditor(String id) {
        Intent i = new Intent(this, PromptEditActivity.class);
        i.putExtra("id", id);
        startActivity(i);
    }

    private void deleteAllDialog() {
        if (all.size() == 0) {
            Utils.toast(this, "El historial ya esta vacio");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Borrar historial")
                .setMessage("Se borraran " + all.size() + " prompts guardados. No se puede deshacer.")
                .setPositiveButton(R.string.act_delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        int n = PromptLibrary.deleteAll(PromptsActivity.this);
                        Utils.toast(PromptsActivity.this, n + " prompts borrados");
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void menu(final PromptLibrary.Entry e, View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Abrir / editar");
        pm.getMenu().add(0, 2, 0, "Copiar");
        pm.getMenu().add(0, 3, 0, "Compartir");
        pm.getMenu().add(0, 4, 0, "Renombrar");
        pm.getMenu().add(0, 5, 0, "Duplicar");
        pm.getMenu().add(0, 6, 0, "Cargar en el generador");
        pm.getMenu().add(0, 7, 0, "Eliminar");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                String content = PromptLibrary.content(PromptsActivity.this, e.id);
                if (id == 1) openEditor(e.id);
                else if (id == 2) Utils.copy(PromptsActivity.this, "prompt", content);
                else if (id == 3) Utils.share(PromptsActivity.this, e.title, content);
                else if (id == 4) renameDialog(e);
                else if (id == 5) {
                    PromptLibrary.duplicate(PromptsActivity.this, e.id);
                    Utils.toast(PromptsActivity.this, "Prompt duplicado");
                    reload();
                } else if (id == 6) loadInGenerator(e, content);
                else if (id == 7) deleteDialog(e);
                return true;
            }
        });
        pm.show();
    }

    private void renameDialog(final PromptLibrary.Entry e) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(e.title);
        new AlertDialog.Builder(this)
                .setTitle("Renombrar prompt")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        PromptLibrary.rename(PromptsActivity.this, e.id,
                                et.getText().toString().trim());
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void deleteDialog(final PromptLibrary.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar prompt")
                .setMessage(e.title + "\n\n" + e.chars + " caracteres. No se puede deshacer.")
                .setPositiveButton(R.string.act_delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        PromptLibrary.delete(PromptsActivity.this, e.id);
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void loadInGenerator(PromptLibrary.Entry e, String content) {
        Storage st = Storage.get(this);
        File dir = st.dirOf(e.project);
        if (e.project.length() == 0 || !dir.isDirectory()) {
            Utils.toast(this, "El proyecto '" + e.project + "' ya no existe");
            return;
        }
        Intent i = new Intent(this, PromptActivity.class);
        i.putExtra("project", e.project);
        i.putExtra("mode", e.mode.length() == 0 ? PromptBuilder.MODE_CREATE : e.mode);
        i.putExtra("promptText", content);
        i.putExtra("promptId", e.id);
        startActivity(i);
    }

    private class Adapter extends BaseAdapter {

        public int getCount() {
            return shown.size();
        }

        public Object getItem(int i) {
            return shown.get(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int pos, View cv, ViewGroup parent) {
            View v = cv == null
                    ? LayoutInflater.from(PromptsActivity.this)
                        .inflate(R.layout.item_prompt, parent, false)
                    : cv;
            final PromptLibrary.Entry e = shown.get(pos);
            ((TextView) v.findViewById(R.id.tvTitle)).setText(e.title);
            TextView mode = (TextView) v.findViewById(R.id.tvMode);
            mode.setText(PromptBuilder.modeLabel(e.mode));
            int bg = R.drawable.bg_badge_acc;
            int fg = R.color.acc2;
            if ("FIX".equals(e.mode)) {
                bg = R.drawable.bg_badge_err;
                fg = R.color.err;
            } else if ("RANGE".equals(e.mode)) {
                bg = R.drawable.bg_badge_warn;
                fg = R.color.warn;
            } else if ("UPDATE".equals(e.mode) || "REFACTOR".equals(e.mode)) {
                bg = R.drawable.bg_badge_info;
                fg = R.color.info;
            } else if ("CONTINUE".equals(e.mode)) {
                bg = R.drawable.bg_badge_ok;
                fg = R.color.ok;
            } else if ("ASSET".equals(e.mode)) {
                bg = R.drawable.bg_badge_err;
                fg = R.color.acc;
            }
            mode.setBackgroundResource(bg);
            mode.setTextColor(Utils.color(PromptsActivity.this, fg));
            TextView pj = (TextView) v.findViewById(R.id.tvProject);
            pj.setText(e.project);
            pj.setVisibility(e.project.length() == 0 ? View.GONE : View.VISIBLE);
            ((TextView) v.findViewById(R.id.tvMeta)).setText(
                    Utils.dateShort(e.updated) + " | " + e.chars + " chars");
            ((TextView) v.findViewById(R.id.tvPreview)).setText(e.preview);
            ImageView more = (ImageView) v.findViewById(R.id.btnMore);
            more.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    menu(e, view);
                }
            });
            v.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View view) {
                    menu(e, view);
                    return true;
                }
            });
            return v;
        }
    }
}
