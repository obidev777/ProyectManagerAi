package com.pm.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import com.pm.ai.core.PendingManager;
import com.pm.ai.core.Prefs;
import com.pm.ai.core.Project;
import com.pm.ai.core.PromptBuilder;
import com.pm.ai.core.PromptLibrary;
import com.pm.ai.core.Storage;
import com.pm.ai.util.Utils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Generador de prompts avanzados (Protocolo PM v2.1). */
public class PromptActivity extends Activity {

    private Storage store;
    private Project p;
    private String mode = PromptBuilder.MODE_CREATE;
    private ScrollView paneConfig;
    private LinearLayout paneResult;
    private LinearLayout llRange;
    private LinearLayout llFix;
    private LinearLayout llAsset;
    private TextView tabConfig;
    private TextView tabResult;
    private TextView chipCreate;
    private TextView chipUpdate;
    private TextView chipFix;
    private TextView chipRange;
    private TextView chipContinue;
    private TextView chipRefactor;
    private TextView chipAsset;
    private EditText etTask;
    private EditText etPrompt;
    private EditText etModel;
    private EditText etError;
    private EditText etSymptom;
    private EditText etSteps;
    private EditText etFrom;
    private EditText etTo;
    private Spinner spLang;
    private SeekBar sbLimit;
    private SeekBar sbCtx;
    private TextView tvLimit;
    private TextView tvCtx;
    private TextView tvPicked;
    private TextView tvInfo;
    private TextView tvRangeFile;
    private TextView tvRangeInfo;
    private TextView tvTaskCount;
    private TextView tvSaved;
    private TextView btnEditToggle;
    private CheckBox cbTree;
    private CheckBox cbContents;
    private CheckBox cbSpec;
    private CheckBox cbNumbers;
    private List<String> picked = new ArrayList<String>();
    private String rangePath = "";
    private boolean editable = false;
    private String savedId = "";
    private final String[] langs = {"Espanol", "English", "Portugues", "Frances"};

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_prompt);
        store = Storage.get(this);
        p = store.open(getIntent().getStringExtra("project"));
        paneConfig = (ScrollView) findViewById(R.id.paneConfig);
        paneResult = (LinearLayout) findViewById(R.id.paneResult);
        llRange = (LinearLayout) findViewById(R.id.llRange);
        llFix = (LinearLayout) findViewById(R.id.llFix);
        llAsset = (LinearLayout) findViewById(R.id.llAsset);
        tabConfig = (TextView) findViewById(R.id.tabConfig);
        tabResult = (TextView) findViewById(R.id.tabResult);
        chipCreate = (TextView) findViewById(R.id.chipCreate);
        chipUpdate = (TextView) findViewById(R.id.chipUpdate);
        chipFix = (TextView) findViewById(R.id.chipFix);
        chipRange = (TextView) findViewById(R.id.chipRange);
        chipContinue = (TextView) findViewById(R.id.chipContinue);
        chipRefactor = (TextView) findViewById(R.id.chipRefactor);
        chipAsset = (TextView) findViewById(R.id.chipAsset);
        etTask = (EditText) findViewById(R.id.etTask);
        etPrompt = (EditText) findViewById(R.id.etPrompt);
        etModel = (EditText) findViewById(R.id.etModel);
        etError = (EditText) findViewById(R.id.etError);
        etSymptom = (EditText) findViewById(R.id.etSymptom);
        etSteps = (EditText) findViewById(R.id.etSteps);
        etFrom = (EditText) findViewById(R.id.etFrom);
        etTo = (EditText) findViewById(R.id.etTo);
        spLang = (Spinner) findViewById(R.id.spLang);
        sbLimit = (SeekBar) findViewById(R.id.sbLimit);
        sbCtx = (SeekBar) findViewById(R.id.sbCtx);
        tvLimit = (TextView) findViewById(R.id.tvLimit);
        tvCtx = (TextView) findViewById(R.id.tvCtx);
        tvPicked = (TextView) findViewById(R.id.tvPicked);
        tvInfo = (TextView) findViewById(R.id.tvPromptInfo);
        tvRangeFile = (TextView) findViewById(R.id.tvRangeFile);
        tvRangeInfo = (TextView) findViewById(R.id.tvRangeInfo);
        tvTaskCount = (TextView) findViewById(R.id.tvTaskCount);
        tvSaved = (TextView) findViewById(R.id.tvSaved);
        btnEditToggle = (TextView) findViewById(R.id.btnEditToggle);
        cbTree = (CheckBox) findViewById(R.id.cbTree);
        cbContents = (CheckBox) findViewById(R.id.cbContents);
        cbSpec = (CheckBox) findViewById(R.id.cbSpec);
        cbNumbers = (CheckBox) findViewById(R.id.cbNumbers);

        ((TextView) findViewById(R.id.tvSub)).setText(p.name + " | " + p.typeLabel()
                + " | " + store.rootLabel());
        etModel.setText(p.model == null || p.model.length() == 0 ? Prefs.model(this) : p.model);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, langs);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        spLang.setAdapter(ad);
        for (int i = 0; i < langs.length; i++) {
            if (langs[i].equals(p.docsLang)) {
                spLang.setSelection(i);
                break;
            }
        }
        int lim = Prefs.limit(this);
        sbLimit.setProgress(Math.max(1, lim / 500));
        tvLimit.setText(lim + " caracteres por archivo");
        sbLimit.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int progress, boolean user) {
                tvLimit.setText(Math.max(1, progress) * 500 + " caracteres por archivo");
            }

            public void onStartTrackingTouch(SeekBar sb) {
            }

            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        int ctx = Prefs.ctxLines(this);
        sbCtx.setProgress(Math.max(1, ctx / 2));
        tvCtx.setText(ctx + " lineas de contexto alrededor del rango");
        sbCtx.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int progress, boolean user) {
                tvCtx.setText(Math.max(1, progress) * 2
                        + " lineas de contexto alrededor del rango");
            }

            public void onStartTrackingTouch(SeekBar sb) {
            }

            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        etTask.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                tvTaskCount.setText(e.length() + " caracteres");
            }
        });

        String task = getIntent().getStringExtra("task");
        if (task != null) etTask.setText(task);
        String pk = getIntent().getStringExtra("picked");
        if (pk != null && pk.trim().length() > 0) {
            picked = Utils.splitLines(pk);
            cbContents.setChecked(true);
        }
        int from = getIntent().getIntExtra("from", 0);
        int to = getIntent().getIntExtra("to", 0);
        if (from > 0) {
            etFrom.setText(String.valueOf(from));
            etTo.setText(String.valueOf(to < from ? from : to));
        }
        String m = getIntent().getStringExtra("mode");
        setMode(m == null ? Prefs.lastMode(this) : m);
        String path = getIntent().getStringExtra("path");
        if (path != null && path.length() > 0) {
            if (PromptBuilder.MODE_CONTINUE.equals(mode)) {
                List<String> one = new ArrayList<String>();
                one.add(path);
                picked = one;
            } else {
                setMode(PromptBuilder.MODE_RANGE);
                setRangePath(path);
            }
        }
        if (picked.size() > 0) updatePicked();
        String pre = getIntent().getStringExtra("promptText");
        if (pre != null && pre.length() > 0) {
            String pid = getIntent().getStringExtra("promptId");
            savedId = pid == null ? "" : pid;
            etPrompt.setText(pre);
            updateInfo();
            tvSaved.setText(savedId.length() == 0
                    ? "Prompt cargado del historial (sin guardar)"
                    : "Editando un prompt del historial");
            showPane(false);
        } else {
            showPane(true);
        }

        tabConfig.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(true);
            }
        });
        tabResult.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPane(false);
            }
        });
        chipCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_CREATE);
            }
        });
        chipUpdate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_UPDATE);
            }
        });
        chipFix.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_FIX);
            }
        });
        chipRange.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_RANGE);
            }
        });
        chipContinue.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_CONTINUE);
            }
        });
        chipRefactor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_REFACTOR);
            }
        });
        chipAsset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setMode(PromptBuilder.MODE_ASSET);
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.btnHelp).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showHelp();
            }
        });
        findViewById(R.id.btnHistory).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(PromptActivity.this, PromptsActivity.class));
            }
        });
        findViewById(R.id.btnPick).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pickFiles();
            }
        });
        findViewById(R.id.btnPickFile).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pickRangeFile();
            }
        });
        findViewById(R.id.btnInsertTree).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etTask.setText(etTask.getText().toString() + "\n\nArbol actual:\n"
                        + PromptBuilder.tree(store, p));
            }
        });
        findViewById(R.id.btnInsertFile).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pickFileToInsert();
            }
        });
        findViewById(R.id.btnTplImg).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etTask.setText(etTask.getText().toString() + TPL_IMAGE);
            }
        });
        findViewById(R.id.btnTplIcon).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etTask.setText(etTask.getText().toString() + TPL_ICON);
            }
        });
        findViewById(R.id.btnTplAudio).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etTask.setText(etTask.getText().toString() + TPL_AUDIO);
            }
        });
        findViewById(R.id.btnGenerate).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                generate();
            }
        });
        findViewById(R.id.btnCopy).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Utils.copy(PromptActivity.this, "prompt", etPrompt.getText().toString());
            }
        });
        findViewById(R.id.btnSharePrompt).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Utils.share(PromptActivity.this, currentTitle(), etPrompt.getText().toString());
            }
        });
        findViewById(R.id.btnSavePrompt).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                savePrompt(false);
            }
        });
        findViewById(R.id.btnOpenQwen).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Utils.copy(PromptActivity.this, "prompt", etPrompt.getText().toString());
                Utils.openUrl(PromptActivity.this, "https://chat.qwen.ai/");
            }
        });
        findViewById(R.id.btnToApply).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(PromptActivity.this, ApplyActivity.class);
                i.putExtra("project", p.name);
                startActivity(i);
            }
        });
        btnEditToggle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editable = !editable;
                etPrompt.setFocusable(editable);
                etPrompt.setFocusableInTouchMode(editable);
                etPrompt.setCursorVisible(editable);
                btnEditToggle.setText("Editable: " + (editable ? "ON" : "OFF"));
                if (editable) etPrompt.requestFocus();
            }
        });
        updateChips();
    }

    private static final String TPL_IMAGE = "\n\nIMAGENES QUE NECESITO (la app las dibuja):\n"
            + "- assets/logo.png 512x512, degradado violeta a cian, forma central y texto.\n"
            + "- assets/fondo.jpg 1080x1920, degradado radial oscuro.\n"
            + "Usa @@PM_ACTION: CREATE_IMAGE con @@PM_FORMAT: SPEC.";

    private static final String TPL_ICON = "\n\nICONOS QUE NECESITO (vectoriales):\n"
            + "- res/drawable/ic_home.xml, ic_add.xml, ic_trash.xml, trazo blanco, viewport 24.\n"
            + "Usa @@PM_ACTION: CREATE_IMAGE con @@PM_FORMAT: VECTOR.";

    private static final String TPL_AUDIO = "\n\nSONIDOS QUE NECESITO (la app los sintetiza):\n"
            + "- assets/click.wav corto y seco, assets/ok.wav dos notas ascendentes,\n"
            + "  assets/error.wav descendente, assets/loop.wav ambiente de 6 segundos.\n"
            + "Usa @@PM_ACTION: CREATE_AUDIO con @@PM_FORMAT: SPEC (WAV).";

    private void setMode(String m) {
        mode = m == null ? PromptBuilder.MODE_CREATE : m;
        Prefs.lastMode(this, mode);
        updateChips();
        if (PromptBuilder.MODE_CONTINUE.equals(mode)) {
            List<String> pend = PendingManager.paths(p);
            if (pend.size() > 0) {
                picked = pend;
                updatePicked();
            }
        }
        if (PromptBuilder.MODE_RANGE.equals(mode) && rangePath.length() == 0 && picked.size() > 0) {
            setRangePath(picked.get(0));
        }
    }

    private void updateChips() {
        chipCreate.setSelected(PromptBuilder.MODE_CREATE.equals(mode));
        chipUpdate.setSelected(PromptBuilder.MODE_UPDATE.equals(mode));
        chipFix.setSelected(PromptBuilder.MODE_FIX.equals(mode));
        chipRange.setSelected(PromptBuilder.MODE_RANGE.equals(mode));
        chipContinue.setSelected(PromptBuilder.MODE_CONTINUE.equals(mode));
        chipRefactor.setSelected(PromptBuilder.MODE_REFACTOR.equals(mode));
        chipAsset.setSelected(PromptBuilder.MODE_ASSET.equals(mode));
        etTask.setHint(PromptBuilder.modeHint(mode));
        llRange.setVisibility(PromptBuilder.MODE_RANGE.equals(mode) ? View.VISIBLE : View.GONE);
        llFix.setVisibility(PromptBuilder.MODE_FIX.equals(mode) ? View.VISIBLE : View.GONE);
        llAsset.setVisibility(PromptBuilder.MODE_ASSET.equals(mode) ? View.VISIBLE : View.GONE);
        if (PromptBuilder.MODE_RANGE.equals(mode) || PromptBuilder.MODE_FIX.equals(mode)) {
            cbNumbers.setChecked(true);
            cbContents.setChecked(true);
        }
    }

    private void showPane(boolean config) {
        paneConfig.setVisibility(config ? View.VISIBLE : View.GONE);
        paneResult.setVisibility(config ? View.GONE : View.VISIBLE);
        tabConfig.setSelected(config);
        tabResult.setSelected(!config);
    }

    private void updatePicked() {
        if (picked.size() == 0) tvPicked.setText("Ninguno seleccionado");
        else if (picked.size() <= 3) tvPicked.setText(Utils.join(picked, ", "));
        else {
            tvPicked.setText(picked.size() + " archivos: "
                    + Utils.join(picked.subList(0, 3), ", ") + " ...");
        }
    }

    private void setRangePath(String rel) {
        rangePath = rel == null ? "" : rel;
        if (rangePath.length() == 0) return;
        picked.clear();
        picked.add(rangePath);
        updatePicked();
        tvRangeFile.setText(rangePath);
        File f = store.file(p, rangePath);
        int total = Utils.countLines(Utils.readText(f));
        tvRangeInfo.setText(total + " lineas | " + Utils.humanSize(f.length())
                + " | escribe el rango exacto que quieres sustituir");
        cbContents.setChecked(true);
        cbNumbers.setChecked(true);
    }

    private void pickRangeFile() {
        final List<String> fs = store.files(p);
        if (fs.size() == 0) {
            Utils.toast(this, "El proyecto no tiene archivos");
            return;
        }
        String[] arr = new String[fs.size()];
        for (int i = 0; i < fs.size(); i++) {
            File f = store.file(p, fs.get(i));
            arr[i] = fs.get(i) + "   (" + Utils.countLines(Utils.readText(f)) + " lineas)";
        }
        new AlertDialog.Builder(this)
                .setTitle("Archivo a editar por lineas")
                .setItems(arr, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        setRangePath(fs.get(w));
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void pickFileToInsert() {
        final List<String> fs = store.files(p);
        if (fs.size() == 0) {
            Utils.toast(this, "El proyecto no tiene archivos");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Insertar archivo en la tarea")
                .setItems(fs.toArray(new String[fs.size()]), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String rel = fs.get(w);
                        etTask.setText(etTask.getText().toString() + "\n\n"
                                + PromptBuilder.fileBlock(store, p, rel, 4000, true));
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void pickFiles() {
        final List<String> files = store.files(p);
        if (files.size() == 0) {
            Utils.toast(this, "El proyecto no tiene archivos");
            return;
        }
        final String[] arr = files.toArray(new String[files.size()]);
        final boolean[] checks = new boolean[arr.length];
        for (int i = 0; i < arr.length; i++) checks[i] = picked.contains(arr[i]);
        new AlertDialog.Builder(this)
                .setTitle("Archivos de contexto")
                .setMultiChoiceItems(arr, checks, new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checks[which] = isChecked;
                    }
                })
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        picked.clear();
                        for (int i = 0; i < arr.length; i++) {
                            if (checks[i]) picked.add(arr[i]);
                        }
                        if (picked.size() == 1 && rangePath.length() == 0) rangePath = picked.get(0);
                        updatePicked();
                    }
                })
                .setNeutralButton("Todos", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        picked = new ArrayList<String>(files);
                        updatePicked();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private int parseInt(EditText et, int def) {
        try {
            String s = et.getText().toString().trim();
            return s.length() == 0 ? def : Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private void generate() {
        p.model = etModel.getText().toString().trim();
        int pos = spLang.getSelectedItemPosition();
        p.docsLang = pos < 0 ? "Espanol" : langs[pos];
        store.save(p);
        int limit = Math.max(1, sbLimit.getProgress()) * 500;
        int ctx = Math.max(1, sbCtx.getProgress()) * 2;
        Prefs.num(this, "limit", limit);
        Prefs.ctxLines(this, ctx);
        String task = etTask.getText().toString();
        boolean numbers = cbNumbers.isChecked();
        String prompt;

        if (PromptBuilder.MODE_RANGE.equals(mode)) {
            if (rangePath.length() == 0) {
                Utils.toast(this, "Elige el archivo a editar");
                return;
            }
            int from = parseInt(etFrom, 0);
            int to = parseInt(etTo, 0);
            if (from <= 0) {
                Utils.toast(this, "Indica la linea inicial del rango");
                return;
            }
            if (to < from) to = from;
            prompt = PromptBuilder.buildRange(store, p, task, rangePath, from, to, ctx,
                    cbTree.isChecked(), limit);
        } else if (PromptBuilder.MODE_FIX.equals(mode)) {
            String err = etError.getText().toString();
            if (err.trim().length() == 0 && task.trim().length() == 0) {
                Utils.toast(this, "Pega el error o describe el fallo");
                return;
            }
            prompt = PromptBuilder.buildFix(store, p, task, err,
                    etSymptom.getText().toString(), etSteps.getText().toString(),
                    cbSpec.isChecked(), cbTree.isChecked(), cbContents.isChecked(),
                    numbers, picked, limit);
        } else if (PromptBuilder.MODE_CONTINUE.equals(mode)) {
            String path = picked.size() > 0 ? picked.get(0) : null;
            if (path == null) {
                List<String> pend = PendingManager.paths(p);
                if (pend.size() == 0) {
                    Utils.toast(this, "No hay archivos cortados. Pega antes la respuesta en Aplicar.");
                    return;
                }
                path = pend.get(0);
            }
            prompt = PromptBuilder.continuePrompt(store, p, path);
        } else {
            prompt = PromptBuilder.build(store, p, mode, task, cbSpec.isChecked(),
                    cbTree.isChecked(), cbContents.isChecked(), numbers, picked, limit);
        }

        etPrompt.setText(prompt);
        savedId = "";
        updateInfo();
        store.savePrompt(p, prompt);
        if (Prefs.autoPrompts(this)) savePrompt(true);
        showPane(false);
        Utils.toast(this, "Prompt generado (" + prompt.length() + " caracteres)");
    }

    private void updateInfo() {
        String t = etPrompt.getText().toString();
        tvInfo.setText(t.length() + " caracteres | ~" + (t.length() / 4) + " tokens | "
                + Utils.countLines(t) + " lineas | modo " + PromptBuilder.modeLabel(mode));
    }

    private String currentTitle() {
        String t = etTask.getText().toString().trim();
        if (PromptBuilder.MODE_RANGE.equals(mode) && rangePath.length() > 0) {
            int from = parseInt(etFrom, 0);
            int to = parseInt(etTo, 0);
            t = rangePath + (from > 0 ? " lineas " + from + "-" + (to < from ? from : to) : "");
        }
        if (PromptBuilder.MODE_FIX.equals(mode) && t.length() == 0) {
            t = Utils.firstLine(etError.getText().toString(), 42);
        }
        String base = PromptBuilder.modeLabel(mode) + " - " + p.name;
        return t.length() == 0 ? base : base + " - " + Utils.firstLine(t, 40);
    }

    private void savePrompt(boolean quiet) {
        String text = etPrompt.getText().toString();
        if (text.trim().length() == 0) {
            if (!quiet) Utils.toast(this, "Nada que guardar: genera antes el prompt");
            return;
        }
        PromptLibrary.Entry e = PromptLibrary.save(this, savedId, currentTitle(), p.name, mode, text);
        if (e != null) {
            savedId = e.id;
            tvSaved.setText("Guardado en el historial: " + e.title);
            if (!quiet) Utils.toast(this, "Prompt guardado en el historial");
        }
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Como funciona (Protocolo PM v2.1)")
                .setMessage("MODOS\n"
                        + "  CREAR      proyecto completo desde cero\n"
                        + "  MEJORAR    cambia lo existente con parche minimo\n"
                        + "  CORREGIR   pegas el log y recibes diagnostico + parche\n"
                        + "  PUNTUAL    edita SOLO de la linea X a la Y de un archivo\n"
                        + "  CONTINUAR  retoma un archivo que se quedo cortado\n"
                        + "  REFACTOR   reestructura sin cambiar comportamiento\n"
                        + "  ASSETS     genera IMAGENES y AUDIOS dentro del movil\n\n"
                        + "FLUJO\n"
                        + "  1 Configura y pulsa GENERAR (el prompt se guarda en el historial).\n"
                        + "  2 COPIAR y pegarlo en Qwen3-Max (boton Abrir Qwen).\n"
                        + "  3 Qwen responde con marcadores @@PM_*: crear, reemplazar, editar,\n"
                        + "     editar lineas, insertar, borrar lineas, renombrar, continuar,\n"
                        + "     CREATE_IMAGE y CREATE_AUDIO.\n"
                        + "  4 Copia TODA la respuesta y pegala en APLICAR: se ejecuta con backup.\n\n"
                        + "IMAGENES Y AUDIO\n"
                        + "  La app DIBUJA las imagenes (SPEC JSON, VECTOR, SVG o BASE64) y\n"
                        + "  SINTETIZA los audios (SPEC -> WAV real, o BASE64 -> mp3/ogg).\n"
                        + "  Qwen solo envia los comandos; el movil hace el resto.\n\n"
                        + "TRUCO\n"
                        + "  Activa 'Enviar archivos NUMERADOS' y Qwen podra responderte con\n"
                        + "  EDIT_RANGE, ahorrando miles de caracteres.\n\n"
                        + PromptBuilder.modeHint(mode))
                .setPositiveButton(R.string.act_ok, null)
                .show();
    }
}
