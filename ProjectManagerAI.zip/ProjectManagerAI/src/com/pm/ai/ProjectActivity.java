package com.pm.ai;
import com.pm.ai.core.WebApkBuilder;
import com.pm.ai.core.CoverManager;
import android.graphics.Bitmap;
import android.widget.ImageView;
import android.widget.CheckBox;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import com.pm.ai.core.AideBridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.pm.ai.core.PendingManager;
import com.pm.ai.core.Project;
import com.pm.ai.core.Runner;
import com.pm.ai.core.Storage;
import com.pm.ai.core.Types;
import com.pm.ai.ui.TreeAdapter;
import com.pm.ai.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class ProjectActivity extends Activity implements TreeAdapter.Host {

    private Storage store;
    private Project p;
    private final List<TreeAdapter.Row> rows = new ArrayList<TreeAdapter.Row>();
    private final HashSet<String> collapsed = new HashSet<String>();
    private TreeAdapter adapter;
    private ListView lv;
    private LinearLayout emptyBox;
    private TextView tvStatus;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_project);
        store = Storage.get(this);
        String name = getIntent().getStringExtra("project");
        if (name == null) {
            finish();
            return;
        }
        p = store.open(name);

        ((TextView) findViewById(R.id.tvName)).setText(p.name);
        ((TextView) findViewById(R.id.tvSub)).setText(p.typeLabel() + " | " + p.dir.getAbsolutePath());

        lv = (ListView) findViewById(R.id.lvTree);
        emptyBox = (LinearLayout) findViewById(R.id.emptyBox);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        adapter = new TreeAdapter(this, rows, this);
        lv.setAdapter(adapter);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.btnPrompt).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                goPrompt("CREATE", null, null);
            }
        });
        findViewById(R.id.btnApply).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(ProjectActivity.this, ApplyActivity.class);
                i.putExtra("project", p.name);
                startActivity(i);
            }
        });
        findViewById(R.id.btnRun).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Runner.run(ProjectActivity.this, p);
            }
        });
        findViewById(R.id.btnNewFile).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                newFileDialog("");
            }
        });
        findViewById(R.id.btnNewDir).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                newDirDialog();
            }
        });
        findViewById(R.id.btnExport).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                exportZip();
            }
        });
                findViewById(R.id.btnAide).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AideBridge.open(ProjectActivity.this, p);
            }
        });
findViewById(R.id.btnInfo).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showInfo();
            }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showMenu(v);
            }
        });
    }

    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        p = store.open(p.name);
        ((TextView) findViewById(R.id.tvName)).setText(p.name);
        ((TextView) findViewById(R.id.tvSub)).setText(p.typeLabel() + " | " + p.dir.getAbsolutePath());
        rows.clear();
        List<String> all = store.tree(p);
        for (int i = 0; i < all.size(); i++) {
            String rel = all.get(i);
            boolean dir = rel.endsWith("/");
            String path = dir ? rel.substring(0, rel.length() - 1) : rel;
            String parent = Utils.parentPath(path);
            if (parent.length() > 0 && collapsed.contains(parent)) continue;
            TreeAdapter.Row r = new TreeAdapter.Row();
            r.path = path;
            r.dir = dir;
            r.name = Utils.baseName(path);
            r.depth = parent.length() == 0 ? 0 : countSlash(parent) + 1;
            r.expanded = !collapsed.contains(path);
            if (!dir) r.size = store.file(p, path).length();
            rows.add(r);
        }
                CoverManager.ensure(store, p);
        ImageView ivCover = (ImageView) findViewById(R.id.ivCover);
        Bitmap coverBm = CoverManager.thumb(p, 72);
        if (coverBm != null) {
            ivCover.setImageBitmap(coverBm);
            ivCover.setVisibility(View.VISIBLE);
        } else {
            ivCover.setImageDrawable(null);
            ivCover.setVisibility(View.GONE);
        }
adapter.notifyDataSetChanged();
        boolean empty = rows.size() == 0;
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        lv.setVisibility(empty ? View.GONE : View.VISIBLE);
        int pend = PendingManager.count(p);
        tvStatus.setText(rows.size() + " elementos | " + store.countFiles(p) + " archivos | "
                + Utils.humanSize(Utils.dirSize(p.dir))
                + (pend > 0 ? " | " + pend + " archivo(s) sin terminar (usa CONTINUAR)" : ""));
    }

    private int countSlash(String s) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '/') n++;
        return n;
    }

    public void onOpenFile(String path) {
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("path", path);
        startActivity(i);
    }

    public void onToggleDir(String path) {
        if (collapsed.contains(path)) collapsed.remove(path);
        else collapsed.add(path);
        reload();
    }

        public void onMore(final TreeAdapter.Row row, View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Abrir / Editar");
        pm.getMenu().add(0, 8, 0, "Cambio puntual (lineas)");
        pm.getMenu().add(0, 5, 0, "Pedir cambio a Qwen");
        pm.getMenu().add(0, 6, 0, "Ejecutar / previsualizar");
        pm.getMenu().add(0, 9, 0, "Abrir proyecto en AIDE");
        pm.getMenu().add(0, 2, 0, "Renombrar / mover");
        pm.getMenu().add(0, 3, 0, "Duplicar");
        pm.getMenu().add(0, 4, 0, "Copiar ruta");
        pm.getMenu().add(0, 7, 0, "Eliminar");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == 1) {
                    if (row.dir) onToggleDir(row.path);
                    else onOpenFile(row.path);
                } else if (id == 2) {
                    renameDialog(row.path);
                } else if (id == 3) {
                    duplicate(row.path);
                } else if (id == 4) {
                    Utils.copy(ProjectActivity.this, "ruta",
                            p.dir.getAbsolutePath() + "/" + row.path);
                } else if (id == 5) {
                    List<String> one = new ArrayList<String>();
                    one.add(row.path);
                    goPrompt("UPDATE", "Quiero modificar el archivo " + row.path + ": ", one);
                } else if (id == 6) {
                    Runner.runFile(ProjectActivity.this, p, row.path);
                } else if (id == 7) {
                    deleteDialog(row.path, row.dir);
                } else if (id == 8) {
                    List<String> one = new ArrayList<String>();
                    one.add(row.path);
                    goPrompt("RANGE", "Cambiar en " + row.path + " las lineas: ", one);
                } else if (id == 9) {
                    AideBridge.open(ProjectActivity.this, p);
                }
                return true;
            }
        });
        pm.show();
    }

            private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Prompt CREAR desde cero");
        pm.getMenu().add(0, 2, 0, "Prompt MEJORAR");
        pm.getMenu().add(0, 3, 0, "Prompt CORREGIR ERROR");
        pm.getMenu().add(0, 9, 0, "Prompt PUNTUAL (por lineas)");
        pm.getMenu().add(0, 10, 0, "Prompt REFACTOR");
        pm.getMenu().add(0, 13, 0, "Prompt ASSETS (imagenes y audio)");
        pm.getMenu().add(0, 15, 0, "Prompt IMAGEN del proyecto");
        pm.getMenu().add(0, 4, 0, "Prompt CONTINUAR archivo cortado");
        pm.getMenu().add(0, 5, 0, "Aplicar respuesta de Qwen");
        pm.getMenu().add(0, 14, 0, "Compilar web como APK (AIDE)");
        pm.getMenu().add(0, 12, 0, "Abrir en AIDE");
        pm.getMenu().add(0, 16, 0, "Elegir imagen de portada");
        pm.getMenu().add(0, 17, 0, "Usar portada como icono AIDE");
        pm.getMenu().add(0, 18, 0, "Quitar portada");
        pm.getMenu().add(0, 11, 0, "Historial de prompts");
        pm.getMenu().add(0, 6, 0, "Editar ficha tecnica");
        pm.getMenu().add(0, 7, 0, "Expandir todo");
        pm.getMenu().add(0, 8, 0, "Colapsar todo");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == 1) goPrompt("CREATE", null, null);
                else if (id == 2) goPrompt("UPDATE", null, null);
                else if (id == 3) goPrompt("FIX", null, null);
                else if (id == 9) goPrompt("RANGE", null, null);
                else if (id == 10) goPrompt("REFACTOR", null, null);
                else if (id == 13) goPrompt("ASSET", null, null);
                else if (id == 15) goImagePrompt();
                else if (id == 4) pickPending();
                else if (id == 5) {
                    Intent i = new Intent(ProjectActivity.this, ApplyActivity.class);
                    i.putExtra("project", p.name);
                    startActivity(i);
                } else if (id == 14) webApkDialog();
                else if (id == 12) AideBridge.open(ProjectActivity.this, p);
                else if (id == 16) pickCover();
                else if (id == 17) applyIcon();
                else if (id == 18) removeCover();
                else if (id == 11) {
                    startActivity(new Intent(ProjectActivity.this, PromptsActivity.class));
                } else if (id == 6) editSpec();
                else if (id == 7) {
                    collapsed.clear();
                    reload();
                } else if (id == 8) {
                    List<String> t = store.tree(p);
                    for (int i = 0; i < t.size(); i++) {
                        if (t.get(i).endsWith("/")) {
                            collapsed.add(t.get(i).substring(0, t.get(i).length() - 1));
                        }
                    }
                    reload();
                }
                return true;
            }
        });
        pm.show();
    }

    private void pickPending() {
        final List<String> paths = PendingManager.paths(p);
        if (paths.size() == 0) {
            Utils.toast(this, "No hay archivos a medias. Usa CONTINUAR tras pegar una respuesta cortada.");
            return;
        }
        final String[] arr = paths.toArray(new String[paths.size()]);
        new AlertDialog.Builder(this)
                .setTitle("Continuar archivo cortado")
                .setItems(arr, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        goPrompt("CONTINUE", null, null, arr[w]);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void goPrompt(String mode, String task, List<String> picked) {
        goPrompt(mode, task, picked, null);
    }

    private void goPrompt(String mode, String task, List<String> picked, String path) {
        Intent i = new Intent(this, PromptActivity.class);
        i.putExtra("project", p.name);
        i.putExtra("mode", mode);
        if (task != null) i.putExtra("task", task);
        if (picked != null) i.putExtra("picked", Utils.join(picked, "\n"));
        if (path != null) i.putExtra("path", path);
        startActivity(i);
    }

    private void newFileDialog(String prefix) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(prefix);
        et.setHint("ruta/nombre.ext");
        new AlertDialog.Builder(this)
                .setTitle("Nuevo archivo")
                .setView(et)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String rel = Utils.normPath(et.getText().toString());
                        if (!Utils.isSafePath(rel)) {
                            Utils.toast(ProjectActivity.this, "Ruta no valida");
                            return;
                        }
                        File f = store.file(p, rel);
                        if (f.exists()) {
                            Utils.toast(ProjectActivity.this, "Ya existe");
                            return;
                        }
                        store.write(p, rel, "");
                        reload();
                        onOpenFile(rel);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void newDirDialog() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("ruta/carpeta");
        new AlertDialog.Builder(this)
                .setTitle("Nueva carpeta")
                .setView(et)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String rel = Utils.normPath(et.getText().toString());
                        if (!Utils.isSafePath(rel)) {
                            Utils.toast(ProjectActivity.this, "Ruta no valida");
                            return;
                        }
                        store.file(p, rel).mkdirs();
                        store.touch(p);
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void renameDialog(final String path) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(path);
        new AlertDialog.Builder(this)
                .setTitle("Renombrar / mover")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String to = Utils.normPath(et.getText().toString());
                        if (!Utils.isSafePath(to)) {
                            Utils.toast(ProjectActivity.this, "Ruta no valida");
                            return;
                        }
                        File src = store.file(p, path);
                        File dst = store.file(p, to);
                        if (!src.exists() || dst.exists()) {
                            Utils.toast(ProjectActivity.this, "No se pudo renombrar");
                            return;
                        }
                        File pd = dst.getParentFile();
                        if (pd != null && !pd.exists()) pd.mkdirs();
                        if (src.renameTo(dst)) {
                            store.touch(p);
                            reload();
                        } else {
                            Utils.toast(ProjectActivity.this, "Error al renombrar");
                        }
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void duplicate(String path) {
        File src = store.file(p, path);
        if (!src.isFile()) {
            Utils.toast(this, "Solo se pueden duplicar archivos");
            return;
        }
        String base = path;
        String ext = "";
        int dot = path.lastIndexOf('.');
        if (dot > path.lastIndexOf('/')) {
            base = path.substring(0, dot);
            ext = path.substring(dot);
        }
        String to = base + "-copia" + ext;
        int i = 2;
        while (store.file(p, to).exists()) {
            to = base + "-copia" + i + ext;
            i++;
        }
        if (Utils.copyFile(src, store.file(p, to))) {
            store.touch(p);
            reload();
            Utils.toast(this, "Duplicado en " + to);
        } else {
            Utils.toast(this, "No se pudo duplicar");
        }
    }

    private void deleteDialog(final String path, final boolean dir) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + path + "?")
                .setMessage(dir ? "Se borrara la carpeta y todo su contenido." : "Se borrara el archivo.")
                .setPositiveButton(R.string.act_delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        Utils.deleteRecursive(store.file(p, path));
                        store.touch(p);
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void exportZip() {
        Utils.requestStorageIfNeeded(this);
        final File z = store.exportZip(p);
        if (z == null) {
            Utils.toast(this, "No se pudo crear el ZIP");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("ZIP creado")
                .setMessage(z.getAbsolutePath() + "\n\n" + Utils.humanSize(z.length()))
                .setPositiveButton(R.string.act_share, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        Utils.shareFile(ProjectActivity.this, z);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void showInfo() {
        int pend = PendingManager.count(p);
        String msg = "Nombre: " + p.name
                + "\nTipo: " + p.typeLabel()
                + "\nCarpeta: " + p.dir.getAbsolutePath()
                + "\nArchivos: " + store.countFiles(p)
                + "\nTamano: " + Utils.humanSize(Utils.dirSize(p.dir))
                + "\nCreado: " + Utils.dateLong(p.created)
                + "\nActualizado: " + Utils.dateLong(p.updated)
                + "\nModelo: " + p.model
                + "\nIdioma docs: " + p.docsLang
                + "\nSin terminar: " + pend
                + "\n\nDescripcion:\n" + (p.description == null ? "-" : p.description)
                + "\n\nCaracteristicas:\n" + (p.features == null ? "-" : p.features);
        new AlertDialog.Builder(this)
                .setTitle("Informacion del proyecto")
                .setMessage(msg)
                .setPositiveButton(R.string.act_copy, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        Utils.copy(ProjectActivity.this, "info", p.toJson().toString());
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void editSpec() {
        View v = getLayoutInflater().inflate(R.layout.dialog_new_project, null);
        final EditText etName = (EditText) v.findViewById(R.id.etName);
        final EditText etDesc = (EditText) v.findViewById(R.id.etDesc);
        final EditText etFeat = (EditText) v.findViewById(R.id.etFeat);
        etName.setText(p.name);
        etName.setEnabled(false);
        etDesc.setText(p.description);
        etFeat.setText(p.features);
        v.findViewById(R.id.spType).setVisibility(View.GONE);
        v.findViewById(R.id.cbTemplate).setVisibility(View.GONE);
        new AlertDialog.Builder(this)
                .setTitle("Ficha tecnica")
                .setView(v)
                .setPositiveButton(R.string.act_save, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        p.description = etDesc.getText().toString();
                        p.features = etFeat.getText().toString();
                        store.save(p);
                        reload();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    // ==================== PATCH V3: portadas, icono y web->apk ====================
    private void goImagePrompt() {
        String desc = p.description == null || p.description.trim().length() == 0
                ? p.name : p.description.trim();
        StringBuilder t = new StringBuilder();
        t.append("IMAGENES DEL PROYECTO '").append(p.name).append("' (")
                .append(p.typeLabel()).append("):\n");
        t.append("1) img/cover.png  1024x512  portada horizontal representativa del proyecto.\n");
        t.append("2) img/icon.png   512x512  icono cuadrado con simbolo central y degradado.\n");
        if (Types.ANDROID.equals(p.type)) {
            t.append("3) res/mipmap-xxxhdpi/ic_launcher.png  192x192  el mismo icono cuadrado.\n");
        }
        t.append("Usa @@PM_ACTION: CREATE_IMAGE con @@PM_FORMAT: SPEC en las tres.\n");
        t.append("Misma paleta y mismo estilo en todas. Evita texto pequeno ilegible.\n");
        t.append("Descripcion del proyecto:\n").append(desc).append("\n");
        if (p.features != null && p.features.trim().length() > 0) {
            t.append("Caracteristicas:\n").append(p.features.trim()).append("\n");
        }
        goPrompt("ASSET", t.toString(), null);
    }

    private void pickCover() {
        final List<String> imgs = CoverManager.imageFiles(store, p);
        if (imgs.size() == 0) {
            Utils.toast(this, "No hay imagenes en el proyecto. Genera una con 'Prompt IMAGEN'.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Imagen de portada del proyecto")
                .setItems(imgs.toArray(new String[imgs.size()]),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                CoverManager.set(store, p, imgs.get(w));
                                Utils.toast(ProjectActivity.this, "Portada: " + imgs.get(w));
                                reload();
                            }
                        })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void applyIcon() {
        String rel = p.cover == null ? "" : p.cover;
        if (rel.length() == 0) {
            Utils.toast(this, "Elige antes una portada (menu > Elegir imagen de portada)");
            return;
        }
        if (CoverManager.applyAsAppIcon(store, p, rel)) {
            Utils.toastLong(this, "Icono escrito en res/mipmap-*/ic_launcher.png y en el "
                    + "Manifest. Compila en AIDE para verlo en el APK.");
        } else {
            Utils.toast(this, "No se pudo aplicar el icono (imagen no valida)");
        }
    }

    private void removeCover() {
        CoverManager.clear(store, p);
        Utils.toast(this, "Portada quitada");
        reload();
    }

    private void webApkDialog() {
        View v = getLayoutInflater().inflate(R.layout.dialog_webapk, null);
        final EditText etApp = (EditText) v.findViewById(R.id.etApp);
        final EditText etPkg = (EditText) v.findViewById(R.id.etPkg);
        final EditText etOut = (EditText) v.findViewById(R.id.etOut);
        final Spinner spOrient = (Spinner) v.findViewById(R.id.spOrient);
        final CheckBox cbFull = (CheckBox) v.findViewById(R.id.cbFull);
        final CheckBox cbIcon = (CheckBox) v.findViewById(R.id.cbIcon);
        final CheckBox cbKeep = (CheckBox) v.findViewById(R.id.cbKeepOn);
        etApp.setText(p.name);
        etPkg.setText(WebApkBuilder.defaultPackage(p.name));
        etOut.setText(p.name + "-apk");
        String[] orients = {"Auto (gira)", "Vertical (portrait)", "Horizontal (landscape)"};
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.spinner_item, orients);
        ad.setDropDownViewResource(R.layout.spinner_dropdown);
        spOrient.setAdapter(ad);
        cbIcon.setChecked(p.cover != null && p.cover.length() > 0);
        new AlertDialog.Builder(this)
                .setTitle("Compilar web como APK")
                .setView(v)
                .setPositiveButton("Crear y abrir en AIDE", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        WebApkBuilder.Config cfg = new WebApkBuilder.Config();
                        cfg.appName = etApp.getText().toString().trim();
                        cfg.pkg = etPkg.getText().toString().trim();
                        cfg.outName = etOut.getText().toString().trim();
                        cfg.orient = spOrient.getSelectedItemPosition();
                        cfg.fullscreen = cbFull.isChecked();
                        cfg.keepOn = cbKeep.isChecked();
                        cfg.iconPath = cbIcon.isChecked() && p.cover != null ? p.cover : "";
                        if (cfg.appName.length() == 0) cfg.appName = p.name;
                        if (cfg.pkg.length() == 0) cfg.pkg = WebApkBuilder.defaultPackage(p.name);
                        Project np = WebApkBuilder.build(store, p, cfg);
                        if (np == null) {
                            Utils.toast(ProjectActivity.this,
                                    "No se pudo crear el proyecto APK (falta el html?)");
                            return;
                        }
                        reload();
                        Utils.toastLong(ProjectActivity.this,
                                "Creado: " + np.dir.getAbsolutePath()
                                        + "\nAbriendo en AIDE para compilar...");
                        AideBridge.open(ProjectActivity.this, np);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }
}
