package com.pm.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import com.pm.ai.core.PromptLibrary;
import com.pm.ai.core.ResponseParser;
import com.pm.ai.core.Storage;
import com.pm.ai.ui.CodeEditor;
import com.pm.ai.util.Utils;
import java.io.File;

/** Editor de un prompt guardado: modificar, renombrar, copiar, borrar. */
public class PromptEditActivity extends Activity {

    private String id = "";
    private PromptLibrary.Entry entry;
    private CodeEditor editor;
    private TextView tvTitle;
    private TextView tvSub;
    private TextView tvInfo;
    private TextView tvDirty;
    private String original = "";
    private boolean dirty = false;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_prompt_edit);
        id = getIntent().getStringExtra("id");
        editor = (CodeEditor) findViewById(R.id.editor);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvSub = (TextView) findViewById(R.id.tvSub);
        tvInfo = (TextView) findViewById(R.id.tvInfo);
        tvDirty = (TextView) findViewById(R.id.tvDirty);
        editor.setLang("txt");
        editor.setHighlightEnabled(false);
        editor.setListener(new CodeEditor.Listener() {
            public void onContentChanged() {
                dirty = !editor.content().equals(original);
                tvDirty.setText(dirty ? "sin guardar" : "");
                updateInfo();
            }

            public void onCursorMoved(int line, int col) {
                tvSub.setText("Ln " + line + ", Col " + col);
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                save();
            }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showMenu(v);
            }
        });
        load();
    }

    private void load() {
        entry = PromptLibrary.get(this, id);
        if (entry == null) {
            Utils.toast(this, "Prompt no encontrado");
            finish();
            return;
        }
        tvTitle.setText(entry.title);
        original = PromptLibrary.content(this, id);
        editor.load(original);
        dirty = false;
        tvDirty.setText("");
        updateInfo();
    }

    private void updateInfo() {
        String c = editor.content();
        tvInfo.setText(c.length() + " caracteres | ~" + (c.length() / 4) + " tokens | "
                + Utils.countLines(c) + " lineas");
    }

    private boolean save() {
        String title = entry == null ? "prompt" : entry.title;
        boolean ok = PromptLibrary.update(this, id, title, editor.content());
        if (ok) {
            original = editor.content();
            dirty = false;
            tvDirty.setText("");
            Utils.toast(this, "Prompt guardado");
        } else {
            Utils.toast(this, "No se pudo guardar");
        }
        return ok;
    }

    public void onBackPressed() {
        if (dirty) {
            new AlertDialog.Builder(this)
                    .setTitle("Guardar cambios?")
                    .setMessage(entry == null ? "" : entry.title)
                    .setPositiveButton(R.string.act_save, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            save();
                            finish();
                        }
                    })
                    .setNegativeButton("Descartar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            finish();
                        }
                    })
                    .setNeutralButton(R.string.act_cancel, null)
                    .show();
            return;
        }
        super.onBackPressed();
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Copiar prompt");
        pm.getMenu().add(0, 2, 0, "Compartir");
        pm.getMenu().add(0, 3, 0, "Renombrar");
        pm.getMenu().add(0, 4, 0, "Duplicar");
        pm.getMenu().add(0, 5, 0, "Cargar en el generador");
        pm.getMenu().add(0, 6, 0, "Ver protocolo PM v2.1");
        pm.getMenu().add(0, 7, 0, "Eliminar prompt");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int idm = item.getItemId();
                String content = editor.content();
                if (idm == 1) Utils.copy(PromptEditActivity.this, "prompt", content);
                else if (idm == 2) Utils.share(PromptEditActivity.this, entry.title, content);
                else if (idm == 3) renameDialog();
                else if (idm == 4) {
                    save();
                    PromptLibrary.Entry copy = PromptLibrary.duplicate(PromptEditActivity.this, id);
                    if (copy != null) {
                        Utils.toast(PromptEditActivity.this, "Duplicado: " + copy.title);
                        id = copy.id;
                        load();
                    }
                } else if (idm == 5) loadInGenerator(content);
                else if (idm == 6) showProtocol();
                else if (idm == 7) deleteDialog();
                return true;
            }
        });
        pm.show();
    }

    private void renameDialog() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(entry == null ? "" : entry.title);
        new AlertDialog.Builder(this)
                .setTitle("Renombrar prompt")
                .setView(et)
                .setPositiveButton(R.string.act_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String t = et.getText().toString().trim();
                        if (t.length() == 0) return;
                        save();
                        PromptLibrary.rename(PromptEditActivity.this, id, t);
                        tvTitle.setText(t);
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void deleteDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar prompt")
                .setMessage(entry == null ? "" : entry.title)
                .setPositiveButton(R.string.act_delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        PromptLibrary.delete(PromptEditActivity.this, id);
                        finish();
                    }
                })
                .setNegativeButton(R.string.act_cancel, null)
                .show();
    }

    private void showProtocol() {
        new AlertDialog.Builder(this)
                .setTitle("Protocolo PM v2.1")
                .setMessage(ResponseParser.PAT_HELP)
                .setPositiveButton(R.string.act_ok, null)
                .show();
    }

    private void loadInGenerator(String content) {
        Storage st = Storage.get(this);
        String project = entry == null ? "" : entry.project;
        File dir = st.dirOf(project);
        if (project.length() == 0 || !dir.isDirectory()) {
            Utils.toast(this, "El proyecto '" + project + "' ya no existe");
            return;
        }
        save();
        Intent i = new Intent(this, PromptActivity.class);
        i.putExtra("project", project);
        i.putExtra("mode", entry.mode);
        i.putExtra("promptText", content);
        i.putExtra("promptId", id);
        startActivity(i);
    }
}
