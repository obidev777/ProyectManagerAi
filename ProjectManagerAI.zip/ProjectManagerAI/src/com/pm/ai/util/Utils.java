package com.pm.ai.util;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Utilidades generales. Cero dependencias externas. */
public class Utils {

    public static void toast(Context c, String msg) {
        if (c == null || msg == null) return;
        Toast.makeText(c.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }

    public static void toastLong(Context c, String msg) {
        if (c == null || msg == null) return;
        Toast.makeText(c.getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }

    public static void copy(Context c, String label, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(label, text == null ? "" : text));
            toast(c, "Copiado al portapapeles");
        } catch (Exception e) {
            toast(c, "No se pudo copiar");
        }
    }

    public static String clipboard(Context c) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cm.getPrimaryClip();
            if (d == null || d.getItemCount() == 0) return "";
            CharSequence s = d.getItemAt(0).coerceToText(c);
            return s == null ? "" : s.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static void share(Context c, String title, String text) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, text);
            c.startActivity(Intent.createChooser(i, title));
        } catch (Exception e) {
            toast(c, "No hay apps para compartir");
        }
    }

    public static void shareFile(Context c, File f) {
        try {
            allowFileUri();
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
            c.startActivity(Intent.createChooser(i, "Compartir " + f.getName()));
        } catch (Exception e) {
            toast(c, "No se pudo compartir");
        }
    }

    /** Permite file:// en Android 7+ sin necesidad de FileProvider. */
    public static void allowFileUri() {
        try {
            StrictMode.VmPolicy policy = new StrictMode.VmPolicy.Builder().build();
            StrictMode.setVmPolicy(policy);
        } catch (Throwable t) {
            // ignorado
        }
    }

    public static void openUrl(Context c, String url) {
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast(c, "No se pudo abrir " + url);
        }
    }

    public static String readText(File f) {
        if (f == null || !f.isFile()) return "";
        StringBuilder sb = new StringBuilder();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) > 0) sb.append(buf, 0, n);
        } catch (Exception e) {
            return "";
        } finally {
            close(br);
        }
        return sb.toString();
    }

    public static boolean writeText(File f, String content) {
        if (f == null) return false;
        OutputStreamWriter w = null;
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
            w.write(content == null ? "" : content);
            w.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            close(w);
        }
    }

    public static boolean copyFile(File src, File dst) {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            File p = dst.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            in = new FileInputStream(src);
            out = new FileOutputStream(dst);
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            out.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            close(in);
            close(out);
        }
    }

    public static void close(java.io.Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (Exception e) {
            // ignorado
        }
    }

    public static boolean deleteRecursive(File f) {
        if (f == null || !f.exists()) return true;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (int i = 0; i < kids.length; i++) deleteRecursive(kids[i]);
            }
        }
        return f.delete();
    }

    public static long dirSize(File f) {
        long t = 0;
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        File[] kids = f.listFiles();
        if (kids != null) {
            for (int i = 0; i < kids.length; i++) t += dirSize(kids[i]);
        }
        return t;
    }

    public static String humanSize(long b) {
        if (b < 1024) return b + " B";
        double k = b / 1024.0;
        if (k < 1024) return trim(k) + " KB";
        double m = k / 1024.0;
        if (m < 1024) return trim(m) + " MB";
        return trim(m / 1024.0) + " GB";
    }

    private static String trim(double d) {
        long v = Math.round(d * 10);
        if (v % 10 == 0) return String.valueOf(v / 10);
        return String.valueOf(v / 10.0);
    }

    public static String ext(String path) {
        if (path == null) return "";
        int i = path.lastIndexOf('.');
        int s = path.lastIndexOf('/');
        if (i < 0 || i < s) return "";
        return path.substring(i + 1).toLowerCase(Locale.US);
    }

    public static String baseName(String path) {
        if (path == null) return "";
        int i = path.lastIndexOf('/');
        return i < 0 ? path : path.substring(i + 1);
    }

    public static String parentPath(String path) {
        if (path == null) return "";
        int i = path.lastIndexOf('/');
        return i < 0 ? "" : path.substring(0, i);
    }

    public static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    public static String dateLong(long ms) {
        if (ms <= 0) return "-";
        return new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(new Date(ms));
    }

    public static String dateShort(long ms) {
        if (ms <= 0) return "-";
        long diff = System.currentTimeMillis() - ms;
        if (diff < 60000) return "ahora";
        if (diff < 3600000) return (diff / 60000) + " min";
        if (diff < 86400000) return (diff / 3600000) + " h";
        if (diff < 604800000) return (diff / 86400000) + " d";
        return new SimpleDateFormat("dd/MM/yy", Locale.US).format(new Date(ms));
    }

    public static String safeName(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == '-' || c == '_' || c == '.';
            if (ok) sb.append(c);
            else if (c == ' ') sb.append('_');
        }
        String r = sb.toString();
        while (r.startsWith(".")) r = r.substring(1);
        if (r.length() == 0) r = "proyecto";
        if (r.length() > 60) r = r.substring(0, 60);
        return r;
    }

    public static String normPath(String p) {
        if (p == null) return "";
        String s = p.trim().replace('\\', '/');
        while (s.startsWith("./")) s = s.substring(2);
        while (s.startsWith("/")) s = s.substring(1);
        if (s.endsWith("\"") || s.endsWith("'")) s = s.substring(0, s.length() - 1);
        if (s.startsWith("\"") || s.startsWith("'")) s = s.substring(1);
        return s.trim();
    }

    public static boolean isSafePath(String p) {
        if (p == null || p.length() == 0) return false;
        if (p.startsWith("/")) return false;
        if (p.indexOf("..") >= 0) return false;
        if (p.indexOf(':') >= 0) return false;
        return true;
    }

    public static int dp(Context c, float v) {
        float d = c.getResources().getDisplayMetrics().density;
        return (int) (v * d + 0.5f);
    }

    public static List<String> splitLines(String s) {
        List<String> out = new ArrayList<String>();
        if (s == null || s.length() == 0) return out;
        String n = s.replace("\r\n", "\n").replace('\r', '\n');
        String[] a = n.split("\n", -1);
        for (int i = 0; i < a.length; i++) out.add(a[i]);
        return out;
    }

    public static String join(List<String> list, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(list.get(i));
        }
        return sb.toString();
    }

    public static boolean isEmpty(String s) {
        return s == null || s.trim().length() == 0;
    }

    public static int countOccurrences(String hay, String needle) {
        if (hay == null || needle == null || needle.length() == 0) return 0;
        int c = 0;
        int i = 0;
        while (true) {
            int k = hay.indexOf(needle, i);
            if (k < 0) break;
            c++;
            i = k + needle.length();
        }
        return c;
    }

    public static void hideKeyboard(Activity a) {
        try {
            View v = a.getCurrentFocus();
            if (v == null) return;
            InputMethodManager m = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
            m.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Exception e) {
            // ignorado
        }
    }

    public static boolean hasApp(Context c, String pkg) {
        try {
            c.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean launchApp(Context c, String pkg) {
        try {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void tint(View v, int color) {
        if (v instanceof ImageView) {
            Drawable d = ((ImageView) v).getDrawable();
            if (d != null) {
                d = d.mutate();
                d.setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);
                ((ImageView) v).setImageDrawable(d);
            }
        } else if (v instanceof TextView) {
            Drawable[] ds = ((TextView) v).getCompoundDrawables();
            for (int i = 0; i < ds.length; i++) {
                if (ds[i] != null) ds[i].mutate().setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);
            }
        }
    }

    /** Color desde recursos (compatibilidad API 21+). */
    public static int color(Context c, int res) {
        return c.getResources().getColor(res);
    }

    public static boolean zipDir(File srcDir, File zipFile) {
        ZipOutputStream zos = null;
        try {
            File p = zipFile.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            zos = new ZipOutputStream(new FileOutputStream(zipFile));
            zipRec(srcDir, "", zos);
            zos.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            close(zos);
        }
    }

    private static void zipRec(File dir, String base, ZipOutputStream zos) throws Exception {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (int i = 0; i < kids.length; i++) {
            File f = kids[i];
            String name = base.length() == 0 ? f.getName() : base + "/" + f.getName();
            if (f.isDirectory()) {
                zos.putNextEntry(new ZipEntry(name + "/"));
                zos.closeEntry();
                zipRec(f, name, zos);
            } else {
                zos.putNextEntry(new ZipEntry(name));
                FileInputStream in = new FileInputStream(f);
                try {
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) zos.write(b, 0, n);
                } finally {
                    close(in);
                }
                zos.closeEntry();
            }
        }
    }

    public static File exportDir(Context c) {
        try {
            File pub = new File(Environment.getExternalStorageDirectory(), "Download");
            if (pub.exists() && pub.canWrite()) return new File(pub, "ProjectManagerAI");
        } catch (Exception e) {
            // ignorado
        }
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        return new File(base, "PM_Export");
    }

    public static void requestStorageIfNeeded(Activity a) {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 28) {
            try {
                if (a.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    a.requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 4242);
                }
            } catch (Throwable t) {
                // ignorado
            }
        }
    }

    public static String tail(String s, int lines) {
        if (s == null) return "";
        List<String> ls = splitLines(s);
        int from = Math.max(0, ls.size() - lines);
        List<String> out = new ArrayList<String>();
        for (int i = from; i < ls.size(); i++) out.add(ls.get(i));
        return join(out, "\n");
    }


    // ==================== PATCH V2 ====================
    public static int countLines(String s) {
        return s == null || s.length() == 0 ? 0 : splitLines(s).size();
    }

    public static String padLeft(String s, int w) {
        StringBuilder sb = new StringBuilder(s == null ? "" : s);
        while (sb.length() < w) sb.insert(0, ' ');
        return sb.toString();
    }

    public static String firstLine(String s, int max) {
        if (s == null) return "";
        String t = s.trim();
        int i = t.indexOf('\n');
        if (i >= 0) t = t.substring(0, i);
        t = t.trim();
        return t.length() > max ? t.substring(0, max) + "..." : t;
    }

    /** Comprueba de verdad si se puede crear y escribir en una carpeta. */
    public static boolean canWriteDir(File d) {
        try {
            if (d == null) return false;
            if (!d.exists() && !d.mkdirs()) return false;
            if (!d.isDirectory() || !d.canWrite()) return false;
            File t = new File(d, ".pm_wtest");
            if (!writeText(t, "1")) return false;
            t.delete();
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    public static boolean hasWritePermission(Context c) {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            return c.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return true;
        }
    }

    public static void requestWritePermission(Activity a) {
        if (a == null || Build.VERSION.SDK_INT < 23 || Build.VERSION.SDK_INT >= 30) return;
        try {
            if (!hasWritePermission(a)) {
                a.requestPermissions(
                        new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 4242);
            }
        } catch (Throwable t) {
            // ignorado
        }
    }

    /** Android 11+: permiso "Todos los archivos" (por reflexion, compila con SDK 28). */
    public static boolean allFilesAccess() {
        if (Build.VERSION.SDK_INT < 30) return true;
        try {
            java.lang.reflect.Method m = Environment.class.getMethod("isExternalStorageManager");
            Object r = m.invoke(null);
            return r instanceof Boolean && ((Boolean) r).booleanValue();
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestAllFilesAccess(Activity a) {
        if (a == null) return;
        if (Build.VERSION.SDK_INT < 30) {
            requestWritePermission(a);
            return;
        }
        try {
            Intent i = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION",
                    Uri.parse("package:" + a.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
            return;
        } catch (Throwable t) {
            // se intenta la pantalla global
        }
        try {
            Intent i2 = new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION");
            i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i2);
        } catch (Throwable t2) {
            toast(a, "Concede 'Todos los archivos' en Ajustes > Aplicaciones");
        }
    }
}
