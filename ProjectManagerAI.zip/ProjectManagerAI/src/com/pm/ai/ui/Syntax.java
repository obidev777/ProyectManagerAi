package com.pm.ai.ui;

import android.text.Editable;
import android.text.Spannable;
import android.text.style.ForegroundColorSpan;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Resaltado de sintaxis ligero por familia de lenguaje. */
public class Syntax {

    public static final int C_COMMENT = 0xFF5C6A8A;
    public static final int C_STRING = 0xFF9BE29B;
    public static final int C_KEYWORD = 0xFFC792EA;
    public static final int C_NUMBER = 0xFFF78C6C;
    public static final int C_TYPE = 0xFF82AAFF;
    public static final int C_TAG = 0xFFFF9AC1;
    public static final int C_ATTR = 0xFFFFCB6B;

    private static final Pattern P_C_COM = Pattern.compile("/\\*[\\s\\S]*?\\*/|//[^\\n]*");
    private static final Pattern P_HASH_COM = Pattern.compile("#[^\\n]*");
    private static final Pattern P_XML_COM = Pattern.compile("<!--[\\s\\S]*?-->");
    private static final Pattern P_STR_D = Pattern.compile("\"(\\\\.|[^\"\\\\])*\"");
    private static final Pattern P_STR_S = Pattern.compile("'(\\\\.|[^'\\\\])*'");
    private static final Pattern P_STR_T = Pattern.compile("\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''");
    private static final Pattern P_NUM = Pattern.compile("\\b\\d[\\d_]*(\\.\\d+)?([eE][+-]?\\d+)?[fFdDlL]?\\b");
    private static final Pattern P_JKW = Pattern.compile("\\b(abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|native|new|package|private|protected|public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|void|volatile|while|true|false|null)\\b");
    private static final Pattern P_PKW = Pattern.compile("\\b(and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|None|not|or|pass|raise|return|True|False|try|while|with|yield|self)\\b");
    private static final Pattern P_JSKW = Pattern.compile("\\b(var|let|const|function|return|if|else|for|while|do|switch|case|break|continue|new|class|extends|super|this|typeof|instanceof|try|catch|finally|throw|delete|in|of|async|await|yield|true|false|null|undefined)\\b");
    private static final Pattern P_CKW = Pattern.compile("\\b(auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while|include|define|NULL|true|false|bool|class|public|private|protected|template|typename|new|delete|namespace|using|virtual|override)\\b");
    private static final Pattern P_TYPE = Pattern.compile("\\b([A-Z][A-Za-z0-9_]*)\\b");
    private static final Pattern P_ANNO = Pattern.compile("@[A-Za-z_][A-Za-z0-9_]*");
    private static final Pattern P_TAG = Pattern.compile("</?[A-Za-z][A-Za-z0-9_:.-]*");
    private static final Pattern P_ATTR = Pattern.compile("[A-Za-z_:][A-Za-z0-9_.:-]*(?=\\s*=)");

    public static String family(String langOrPath) {
        String s = langOrPath == null ? "" : langOrPath.toLowerCase();
        if (s.indexOf('.') >= 0) {
            int i = s.lastIndexOf('.');
            s = s.substring(i + 1);
        }
        if (s.equals("html") || s.equals("htm") || s.equals("xml") || s.equals("svg")) return "xml";
        if (s.equals("java") || s.equals("kt") || s.equals("aidl")) return "java";
        if (s.equals("py")) return "python";
        if (s.equals("js") || s.equals("mjs") || s.equals("ts") || s.equals("jsx")) return "js";
        if (s.equals("json")) return "json";
        if (s.equals("c") || s.equals("h") || s.equals("cpp") || s.equals("hpp") || s.equals("cc")) return "c";
        if (s.equals("css")) return "css";
        return "text";
    }

    public static void paint(Editable ed, String langOrPath) {
        if (ed == null) return;
        String s = ed.toString();
        int n = s.length();
        if (n == 0) return;
        boolean[] lock = new boolean[n];
        String f = family(langOrPath);

        if (f.equals("xml")) {
            apply(ed, s, lock, P_XML_COM, C_COMMENT, true);
            apply(ed, s, lock, P_TAG, C_TAG, false);
            apply(ed, s, lock, P_ATTR, C_ATTR, false);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
        } else if (f.equals("python")) {
            apply(ed, s, lock, P_HASH_COM, C_COMMENT, true);
            apply(ed, s, lock, P_STR_T, C_STRING, true);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
            apply(ed, s, lock, P_STR_S, C_STRING, true);
            apply(ed, s, lock, P_NUM, C_NUMBER, false);
            apply(ed, s, lock, P_PKW, C_KEYWORD, false);
            apply(ed, s, lock, P_ANNO, C_ATTR, false);
        } else if (f.equals("js") || f.equals("json")) {
            apply(ed, s, lock, P_C_COM, C_COMMENT, true);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
            apply(ed, s, lock, P_STR_S, C_STRING, true);
            apply(ed, s, lock, P_NUM, C_NUMBER, false);
            apply(ed, s, lock, f.equals("js") ? P_JSKW : P_NUM, C_KEYWORD, false);
        } else if (f.equals("c")) {
            apply(ed, s, lock, P_C_COM, C_COMMENT, true);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
            apply(ed, s, lock, P_STR_S, C_STRING, true);
            apply(ed, s, lock, P_NUM, C_NUMBER, false);
            apply(ed, s, lock, P_CKW, C_KEYWORD, false);
        } else if (f.equals("css")) {
            apply(ed, s, lock, P_C_COM, C_COMMENT, true);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
            apply(ed, s, lock, P_NUM, C_NUMBER, false);
            apply(ed, s, lock, P_ATTR, C_ATTR, false);
        } else if (f.equals("java")) {
            apply(ed, s, lock, P_C_COM, C_COMMENT, true);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
            apply(ed, s, lock, P_STR_S, C_STRING, true);
            apply(ed, s, lock, P_NUM, C_NUMBER, false);
            apply(ed, s, lock, P_JKW, C_KEYWORD, false);
            apply(ed, s, lock, P_TYPE, C_TYPE, false);
            apply(ed, s, lock, P_ANNO, C_ATTR, false);
        } else {
            apply(ed, s, lock, P_C_COM, C_COMMENT, true);
            apply(ed, s, lock, P_HASH_COM, C_COMMENT, true);
            apply(ed, s, lock, P_STR_D, C_STRING, true);
            apply(ed, s, lock, P_NUM, C_NUMBER, false);
        }
    }

    private static void apply(Editable ed, String s, boolean[] lock, Pattern p, int color, boolean setLock) {
        Matcher m = p.matcher(s);
        while (m.find()) {
            int a = m.start();
            int b = m.end();
            if (b <= a || b > lock.length) continue;
            boolean blocked = false;
            for (int i = a; i < b; i++) {
                if (lock[i]) {
                    blocked = true;
                    break;
                }
            }
            if (blocked) continue;
            try {
                ed.setSpan(new ForegroundColorSpan(color), a, b, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } catch (Throwable t) {
                return;
            }
            if (setLock) {
                for (int i = a; i < b; i++) lock[i] = true;
            }
        }
    }
}
