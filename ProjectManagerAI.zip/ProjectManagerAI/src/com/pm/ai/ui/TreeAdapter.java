package com.pm.ai.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pm.ai.R;
import com.pm.ai.util.Utils;

import java.util.List;

public class TreeAdapter extends BaseAdapter {

    public static class Row {
        public String path;
        public String name;
        public int depth;
        public boolean dir;
        public boolean expanded;
        public long size;
    }

    public interface Host {
        void onOpenFile(String path);

        void onToggleDir(String path);

        void onMore(Row row, View anchor);
    }

    private final List<Row> data;
    private final Host host;
    private final LayoutInflater inf;
    private final Context ctx;

    public TreeAdapter(Context c, List<Row> data, Host host) {
        this.ctx = c;
        this.data = data;
        this.host = host;
        this.inf = LayoutInflater.from(c);
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int i) {
        return data.get(i);
    }

    public long getItemId(int i) {
        return i;
    }

    public View getView(int pos, View cv, ViewGroup parent) {
        View v = cv == null ? inf.inflate(R.layout.item_tree, parent, false) : cv;
        final Row r = data.get(pos);

        View ind = v.findViewById(R.id.vIndent);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Utils.dp(ctx, 14 * r.depth), 1);
        ind.setLayoutParams(lp);

        ImageView icon = (ImageView) v.findViewById(R.id.ivIcon);
        icon.setImageResource(r.dir ? (r.expanded ? R.drawable.ic_folder_open : R.drawable.ic_folder) : R.drawable.ic_file);
        Utils.tint(icon, r.dir ? Utils.color(ctx, R.color.acc2) : Utils.color(ctx, R.color.txt2));

        TextView name = (TextView) v.findViewById(R.id.tvName);
        name.setText(r.name);
        name.setTextColor(Utils.color(ctx, r.dir ? R.color.txt : R.color.txt));

        TextView meta = (TextView) v.findViewById(R.id.tvMeta);
        meta.setText(r.dir ? "" : Utils.humanSize(r.size));

        ImageView chev = (ImageView) v.findViewById(R.id.ivChevron);
        chev.setVisibility(r.dir ? View.VISIBLE : View.INVISIBLE);
        chev.setRotation(r.expanded ? 90f : 0f);

        v.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (r.dir) host.onToggleDir(r.path);
                else host.onOpenFile(r.path);
            }
        });
        v.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                host.onMore(r, view);
                return true;
            }
        });
        return v;
    }
}
