package com.pm.ai.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.text.Editable;
import android.text.Layout;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.EditText;

import com.pm.ai.util.Utils;

/** EditText con numeros de linea, resaltado de sintaxis y auto-indentado. */
public class CodeEditor extends EditText {

    public interface Listener {
        void onContentChanged();

        void onCursorMoved(int line, int col);
    }

    private boolean updating = false;
    private boolean highlightOn = true;
    private boolean gutterOn = true;
    private String lang = "";
    private int lastLen = 0;
    private int gutterW = 0;
    private Listener listener;

    private final Paint gutterPaint = new Paint();
    private final Paint numPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sepPaint = new Paint();
    private final Paint curPaint = new Paint();
    private final Handler handler = new Handler();
    private Runnable pending;

    public CodeEditor(Context c) {
        super(c);
        init();
    }

    public CodeEditor(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    public CodeEditor(Context c, AttributeSet a, int d) {
        super(c, a, d);
        init();
    }

    private void init() {
        setTypeface(Typeface.MONOSPACE);
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        setTextColor(0xFFEAF0FF);
        setHighlightColor(0x4422D3EE);
        setBackgroundColor(0xFF0A0E1C);
        setHorizontallyScrolling(true);
        setGravity(Gravity.TOP | Gravity.LEFT);
        setLineSpacing(0f, 1.18f);

        gutterPaint.setColor(0xFF0D1428);
        sepPaint.setColor(0xFF26314F);
        sepPaint.setStrokeWidth(1f);
        curPaint.setColor(0xFF141D3A);
        numPaint.setColor(0xFF5A688C);
        numPaint.setTypeface(Typeface.MONOSPACE);
        numPaint.setTextSize(getTextSize() * 0.82f);

        applyGutter();

        addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                if (updating) return;
                autoIndent(e);
                lastLen = e.length();
                applyGutter();
                scheduleHighlight();
                if (listener != null) listener.onContentChanged();
            }
        });
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setHighlightEnabled(boolean b) {
        highlightOn = b;
        if (!b) clearSpans();
        else doHighlight();
    }

    public void setGutterEnabled(boolean b) {
        gutterOn = b;
        applyGutter();
        invalidate();
    }

    public void setLang(String l) {
        this.lang = l == null ? "" : l;
        doHighlight();
    }

    public void load(String text) {
        updating = true;
        setTextKeepState(text == null ? "" : text);
        updating = false;
        lastLen = getText().length();
        setSelection(0);
        applyGutter();
        doHighlight();
    }

    public String content() {
        Editable e = getText();
        return e == null ? "" : e.toString();
    }

    private void autoIndent(Editable e) {
        try {
            int len = e.length();
            if (len <= lastLen) return;
            int sel = getSelectionStart();
            if (sel <= 0 || sel > len) return;
            if (e.charAt(sel - 1) != '\n') return;
            int nl = sel - 1;
            int prevStart = nl - 1;
            while (prevStart >= 0 && e.charAt(prevStart) != '\n') prevStart--;
            prevStart++;
            StringBuilder ind = new StringBuilder();
            for (int k = prevStart; k < nl; k++) {
                char c = e.charAt(k);
                if (c == ' ' || c == '\t') ind.append(c);
                else break;
            }
            int j = nl - 1;
            while (j >= prevStart && (e.charAt(j) == ' ' || e.charAt(j) == '\t')) j--;
            if (j >= prevStart) {
                char last = e.charAt(j);
                if (last == '{' || last == ':' || last == '(') ind.append("    ");
            }
            if (ind.length() > 0) {
                updating = true;
                e.insert(sel, ind.toString());
                updating = false;
            }
        } catch (Throwable t) {
            updating = false;
        }
    }

    private void applyGutter() {
        int w;
        if (!gutterOn) {
            w = Utils.dp(getContext(), 12);
        } else {
            int lines = Math.max(1, getLineCount());
            int digits = String.valueOf(lines).length();
            w = (int) (numPaint.measureText("0") * digits) + Utils.dp(getContext(), 22);
        }
        if (w != gutterW) {
            gutterW = w;
            setPadding(w, Utils.dp(getContext(), 12), Utils.dp(getContext(), 26), Utils.dp(getContext(), 60));
        }
    }

    private void scheduleHighlight() {
        if (!highlightOn) return;
        Editable e = getText();
        if (e == null) return;
        if (e.length() < 30000) {
            doHighlight();
            return;
        }
        if (pending != null) handler.removeCallbacks(pending);
        pending = new Runnable() {
            public void run() {
                doHighlight();
                pending = null;
            }
        };
        handler.postDelayed(pending, 260);
    }

    private void clearSpans() {
        Editable e = getText();
        if (e == null) return;
        updating = true;
        try {
            ForegroundColorSpan[] old = e.getSpans(0, e.length(), ForegroundColorSpan.class);
            for (int i = 0; i < old.length; i++) e.removeSpan(old[i]);
        } catch (Throwable t) {
            // ignorado
        }
        updating = false;
    }

    private void doHighlight() {
        if (!highlightOn) return;
        Editable e = getText();
        if (e == null || e.length() > 200000) return;
        updating = true;
        try {
            ForegroundColorSpan[] old = e.getSpans(0, e.length(), ForegroundColorSpan.class);
            for (int i = 0; i < old.length; i++) e.removeSpan(old[i]);
            Syntax.paint(e, lang);
        } catch (Throwable t) {
            // ignorado
        }
        updating = false;
        invalidate();
    }

    public void insertText(String s) {
        try {
            int sel = getSelectionStart();
            if (sel < 0) sel = content().length();
            getText().insert(sel, s);
        } catch (Throwable t) {
            // ignorado
        }
    }

    public void wrapSelection(String before, String after) {
        try {
            int a = Math.min(getSelectionStart(), getSelectionEnd());
            int b = Math.max(getSelectionStart(), getSelectionEnd());
            Editable e = getText();
            e.insert(b, after);
            e.insert(a, before);
            setSelection(a + before.length(), b + before.length());
        } catch (Throwable t) {
            // ignorado
        }
    }

    public void goToLine(int line) {
        Layout l = getLayout();
        if (l == null) return;
        int ln = Math.max(0, Math.min(line - 1, l.getLineCount() - 1));
        int off = l.getLineStart(ln);
        setSelection(off);
        requestFocus();
        int y = l.getLineTop(ln);
        scrollTo(getScrollX(), Math.max(0, y - getHeight() / 3));
    }

    public int currentLine() {
        Layout l = getLayout();
        if (l == null) return 1;
        int sel = Math.max(0, Math.min(getSelectionStart(), content().length()));
        return l.getLineForOffset(sel) + 1;
    }

    public int currentColumn() {
        Layout l = getLayout();
        if (l == null) return 1;
        int sel = Math.max(0, Math.min(getSelectionStart(), content().length()));
        int ln = l.getLineForOffset(sel);
        return sel - l.getLineStart(ln) + 1;
    }

    protected void onSelectionChanged(int selStart, int selEnd) {
        super.onSelectionChanged(selStart, selEnd);
        invalidate();
        if (listener != null) listener.onCursorMoved(currentLine(), currentColumn());
    }

    protected void onDraw(Canvas canvas) {
        Layout l = getLayout();
        int padTop = getExtendedPaddingTop();
        if (l != null) {
            int line = Math.max(0, Math.min(getSelectionStart(), content().length()));
            int ln = l.getLineForOffset(line);
            float top = padTop + l.getLineTop(ln) - getScrollY();
            float bot = padTop + l.getLineBottom(ln) - getScrollY();
            canvas.drawRect(gutterW, top, getRight() - getLeft(), bot, curPaint);
        }
        super.onDraw(canvas);
        if (gutterOn && l != null) drawGutter(canvas, l, padTop);
    }

    private void drawGutter(Canvas c, Layout l, int padTop) {
        int h = getHeight();
        c.drawRect(0, 0, gutterW, h, gutterPaint);
        c.drawLine(gutterW - 1, 0, gutterW - 1, h, sepPaint);
        int sy = getScrollY();
        int first = l.getLineForVertical(Math.max(0, sy - padTop));
        int last = l.getLineForVertical(Math.max(0, sy + h - padTop));
        if (last >= l.getLineCount()) last = l.getLineCount() - 1;
        float ascent = getPaint().ascent();
        int curLine = l.getLineForOffset(Math.max(0, Math.min(getSelectionStart(), content().length())));
        for (int i = first; i <= last; i++) {
            float y = padTop + l.getLineTop(i) - sy - ascent;
            if (y < -30 || y > h + 30) continue;
            numPaint.setColor(i == curLine ? 0xFF22D3EE : 0xFF5A688C);
            String s = String.valueOf(i + 1);
            float w = numPaint.measureText(s);
            c.drawText(s, gutterW - Utils.dp(getContext(), 10) - w, y, numPaint);
        }
    }
}
