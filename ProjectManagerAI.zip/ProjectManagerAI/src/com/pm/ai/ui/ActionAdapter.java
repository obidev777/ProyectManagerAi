package com.pm.ai.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.pm.ai.R;
import com.pm.ai.core.Action;
import com.pm.ai.core.ImageGen;
import com.pm.ai.util.Utils;
import java.util.ArrayList;
import java.util.List;

/** Lista de acciones detectadas, con miniatura de las imagenes generadas. */
public class ActionAdapter extends BaseAdapter {

    private final List<Action> data;
    private final LayoutInflater inf;
    private final Context ctx;

    public ActionAdapter(Context c, List<Action> data) {
        this.ctx = c;
        this.data = data;
        this.inf = LayoutInflater.from(c);
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int i) {
        return data.get(i);
    }

    public long getItemId(int i) {
        return i;
    }

    public View getView(int pos, View cv, ViewGroup parent) {
        View v = cv == null ? inf.inflate(R.layout.item_action, parent, false) : cv;
        final Action a = data.get(pos);
        CheckBox cb = (CheckBox) v.findViewById(R.id.cbSel);
        cb.setOnCheckedChangeListener(null);
        cb.setChecked(a.selected);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                a.selected = checked;
            }
        });
        TextView kind = (TextView) v.findViewById(R.id.tvKind);
        kind.setText(a.kindLabel() + (a.incomplete() ? " ..." : ""));
        int bg = R.drawable.bg_badge_ok;
        int fg = R.color.ok;
        if (a.kind == Action.REPLACE) {
            bg = R.drawable.bg_badge_info;
            fg = R.color.info;
        } else if (a.kind == Action.EDIT) {
            bg = R.drawable.bg_badge_acc;
            fg = R.color.acc;
        } else if (a.isRange()) {
            bg = R.drawable.bg_badge_warn;
            fg = R.color.warn;
        } else if (a.kind == Action.DELETE) {
            bg = R.drawable.bg_badge_err;
            fg = R.color.err;
        } else if (a.kind == Action.CREATE_IMAGE) {
            bg = R.drawable.bg_badge_acc;
            fg = R.color.acc2;
        } else if (a.kind == Action.CREATE_AUDIO) {
            bg = R.drawable.bg_badge_info;
            fg = R.color.info;
        } else if (a.kind == Action.RENAME || a.kind == Action.CONTINUE
                || a.kind == Action.APPEND) {
            bg = R.drawable.bg_badge_warn;
            fg = R.color.warn;
        }
        kind.setBackgroundResource(bg);
        kind.setTextColor(Utils.color(ctx, fg));
        ((TextView) v.findViewById(R.id.tvPath)).setText(a.path);

        TextView note = (TextView) v.findViewById(R.id.tvNote);
        String nt = a.note == null ? "" : a.note;
        if (a.isRange() && a.rangeLabel().length() > 0) {
            nt = nt.length() == 0 ? a.rangeLabel() : nt + "  |  " + a.rangeLabel();
        }
        if (a.format != null && a.format.length() > 0) {
            nt = nt.length() == 0 ? a.format : nt + "  |  " + a.format;
        }
        if (a.result != null && a.result.length() > 0) nt = nt + "  ->  " + a.result;
        note.setText(nt);
        note.setVisibility(nt.length() == 0 ? View.GONE : View.VISIBLE);

        ((TextView) v.findViewById(R.id.tvDetail)).setText(detailOf(a));

        ImageView thumb = (ImageView) v.findViewById(R.id.ivThumb);
        thumb.setVisibility(View.GONE);
        thumb.setImageDrawable(null);
        if (a.kind == Action.CREATE_IMAGE && a.absPath != null && a.absPath.length() > 0) {
            Bitmap bm = ImageGen.thumb(a.absPath, 96);
            if (bm != null) {
                thumb.setImageBitmap(bm);
                thumb.setVisibility(View.VISIBLE);
            }
        } else if (a.kind == Action.CREATE_AUDIO) {
            thumb.setImageResource(R.drawable.ic_audio);
            thumb.setVisibility(View.VISIBLE);
        }
        return v;
    }

    private String detailOf(Action a) {
        StringBuilder d = new StringBuilder();
        if (a.kind == Action.EDIT) {
            d.append(a.edits.size()).append(" bloque(s) FIND/REPLACE");
        } else if (a.kind == Action.DELETE) {
            d.append("se eliminara el archivo");
        } else if (a.kind == Action.RENAME) {
            d.append("-> ").append(a.target);
        } else if (a.kind == Action.DELETE_LINES) {
            d.append("se borraran ").append(Math.max(0, a.toLine - a.fromLine + 1)).append(" lineas");
        } else if (a.kind == Action.INSERT_AFTER) {
            d.append(a.lines()).append(" lineas nuevas tras la ").append(a.afterLine);
        } else if (a.kind == Action.EDIT_RANGE) {
            d.append("sustituye ").append(Math.max(0, a.toLine - a.fromLine + 1))
                    .append(" lineas por ").append(a.lines())
                    .append(" (").append(a.size()).append(" chars)");
        } else if (a.kind == Action.CREATE_IMAGE || a.kind == Action.CREATE_AUDIO) {
            String fmt = a.format == null || a.format.length() == 0 ? "auto" : a.format;
            d.append("generado por la app desde ").append(fmt).append(" (")
                    .append(a.size()).append(" chars de datos)");
            String head = head(a.content, 3);
            if (head.trim().length() > 0) d.append("\n").append(head.trim());
        } else {
            d.append(a.lines()).append(" lineas, ").append(a.size()).append(" chars");
            String head = head(a.content, 3);
            if (head.trim().length() > 0) d.append("\n").append(head.trim());
        }
        return d.toString();
    }

    private String head(String s, int lines) {
        List<String> ls = Utils.splitLines(s);
        List<String> out = new ArrayList<String>();
        for (int i = 0; i < ls.size() && i < lines; i++) out.add(ls.get(i));
        return Utils.join(out, "\n");
    }
}
