package com.pm.ai;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import com.pm.ai.core.Prefs;
import com.pm.ai.core.Project;
import com.pm.ai.core.Storage;
import com.pm.ai.core.Types;
import com.pm.ai.util.Utils;
import java.io.File;

/**
 * Preview web/texto con pantalla completa inmersiva y giro de pantalla
 * (portrait <-> landscape <-> auto) sin recargar el WebView.
 */
public class PreviewActivity extends Activity {

    private Storage store;
    private Project p;
    private String path;
    private String mode;
    private WebView web;
    private TextView tvText;
    private TextView tvConsole;
    private TextView tvUrl;
    private LinearLayout llConsole;
    private LinearLayout topBar;
    private ScrollView scrollText;
    private ScrollView scrollConsole;
    private View btnFull;
    private View btnExitFull;
    private boolean full = false;
    private boolean webMode = false;
    private boolean consoleOn = true;
    private int orient = 0;

    private final Runnable hideAgain = new Runnable() {
        public void run() {
            if (full) applyFull();
        }
    };

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_preview);
        store = Storage.get(this);
        p = store.open(getIntent().getStringExtra("project"));
        path = Utils.normPath(getIntent().getStringExtra("path"));
        mode = getIntent().getStringExtra("mode");
        if (mode == null) mode = "text";

        web = (WebView) findViewById(R.id.web);
        tvText = (TextView) findViewById(R.id.tvText);
        tvConsole = (TextView) findViewById(R.id.tvConsole);
        tvUrl = (TextView) findViewById(R.id.tvUrl);
        llConsole = (LinearLayout) findViewById(R.id.llConsole);
        topBar = (LinearLayout) findViewById(R.id.topBar);
        scrollText = (ScrollView) findViewById(R.id.scrollText);
        scrollConsole = (ScrollView) findViewById(R.id.scrollConsole);
        btnFull = findViewById(R.id.btnFull);
        btnExitFull = findViewById(R.id.btnExitFull);
        ((TextView) findViewById(R.id.tvTitle)).setText(p.name + " - " + Utils.baseName(path));

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                load();
            }
        });
        findViewById(R.id.btnExternal).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                external();
            }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showMenu(v);
            }
        });
        findViewById(R.id.btnRotate).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rotate();
            }
        });
        btnFull.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setFull(!full);
            }
        });
        btnExitFull.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setFull(false);
            }
        });
        findViewById(R.id.btnClearConsole).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tvConsole.setText("");
            }
        });
        findViewById(R.id.btnToggleConsole).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                consoleOn = !consoleOn;
                scrollConsole.setVisibility(consoleOn ? View.VISIBLE : View.GONE);
                ((TextView) v).setText(consoleOn ? "ocultar" : "mostrar");
            }
        });

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(
                new View.OnSystemUiVisibilityChangeListener() {
                    public void onSystemUiVisibilityChange(int visibility) {
                        if (full && (visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                            getWindow().getDecorView().postDelayed(hideAgain, 1800);
                        }
                    }
                });

        orient = Prefs.previewOrient(this);
        full = Prefs.previewFull(this);
        applyOrient();
        load();
        applyFull();
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, full ? "Salir de pantalla completa" : "Pantalla completa");
        pm.getMenu().add(0, 2, 0, "Girar pantalla");
        pm.getMenu().add(0, 3, 0, "Orientacion: automatica");
        pm.getMenu().add(0, 4, 0, "Orientacion: vertical");
        pm.getMenu().add(0, 5, 0, "Orientacion: horizontal");
        pm.getMenu().add(0, 6, 0, consoleOn ? "Ocultar consola JS" : "Mostrar consola JS");
        pm.getMenu().add(0, 7, 0, "Recargar");
        pm.getMenu().add(0, 8, 0, "Abrir en navegador externo");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == 1) setFull(!full);
                else if (id == 2) rotate();
                else if (id == 3) setOrient(0);
                else if (id == 4) setOrient(1);
                else if (id == 5) setOrient(2);
                else if (id == 6) {
                    consoleOn = !consoleOn;
                    scrollConsole.setVisibility(consoleOn ? View.VISIBLE : View.GONE);
                    llConsole.setVisibility(webMode && consoleOn && !full ? View.VISIBLE : View.GONE);
                } else if (id == 7) load();
                else if (id == 8) external();
                return true;
            }
        });
        pm.show();
    }

    public void setFull(boolean on) {
        full = on;
        applyFull();
    }

    private void applyFull() {
        View decor = getWindow().getDecorView();
        if (full) {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            topBar.setVisibility(View.GONE);
            llConsole.setVisibility(View.GONE);
            btnExitFull.setVisibility(View.VISIBLE);
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            topBar.setVisibility(View.VISIBLE);
            llConsole.setVisibility(webMode && consoleOn ? View.VISIBLE : View.GONE);
            btnExitFull.setVisibility(View.GONE);
        }
        ((android.widget.ImageView) btnFull).setImageResource(full ? R.drawable.ic_compress : R.drawable.ic_expand);
        Prefs.previewFull(this, full);
    }

    private void setOrient(int o) {
        orient = o;
        Prefs.previewOrient(this, o);
        applyOrient();
        Utils.toast(this, o == 1 ? "Orientacion vertical"
                : o == 2 ? "Orientacion horizontal" : "Orientacion automatica");
    }

    private void applyOrient() {
        if (orient == 1) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        else if (orient == 2) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        else setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    /** Si esta en portrait pasa a landscape y viceversa. */
    private void rotate() {
        int cur = getResources().getConfiguration().orientation;
        setOrient(cur == Configuration.ORIENTATION_LANDSCAPE ? 1 : 2);
    }

    private void load() {
        File f = store.file(p, path);
        if (!f.isFile()) {
            webMode = false;
            web.setVisibility(View.GONE);
            scrollText.setVisibility(View.VISIBLE);
            llConsole.setVisibility(View.GONE);
            tvText.setText("No existe el archivo: " + path
                    + "\n\nRuta esperada:\n" + f.getAbsolutePath()
                    + "\n\nRaiz de proyectos:\n" + store.rootPath()
                    + "\n\nTipo: " + Types.label(p.type) + "\n" + Types.runHint(p.type));
            tvUrl.setText(f.getAbsolutePath());
            return;
        }
        String ext = Utils.ext(path);
        if ("web".equals(mode) || ext.equals("html") || ext.equals("htm")) {
            webMode = true;
            setupWeb();
            web.setVisibility(View.VISIBLE);
            scrollText.setVisibility(View.GONE);
            llConsole.setVisibility(consoleOn && !full ? View.VISIBLE : View.GONE);
            tvUrl.setText("file://" + f.getAbsolutePath());
            web.loadUrl("file://" + f.getAbsolutePath());
            appendConsole("Cargando file://" + f.getAbsolutePath());
        } else {
            webMode = false;
            web.setVisibility(View.GONE);
            scrollText.setVisibility(View.VISIBLE);
            llConsole.setVisibility(View.GONE);
            String content = Utils.readText(f);
            StringBuilder sb = new StringBuilder();
            sb.append("== ").append(path).append(" ==\n");
            sb.append(Utils.humanSize(f.length())).append(" | ")
                    .append(Utils.countLines(content)).append(" lineas | ")
                    .append(Utils.dateLong(f.lastModified())).append("\n\n");
            sb.append(content);
            sb.append("\n\n----------------------------------------\n");
            sb.append("COMO EJECUTAR ESTE PROYECTO\n");
            sb.append(Types.runHint(p.type)).append("\n\n");
            sb.append("Ruta del proyecto:\n").append(p.dir.getAbsolutePath()).append("\n");
            tvText.setText(sb.toString());
            tvUrl.setText(f.getAbsolutePath());
        }
    }

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        try {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        } catch (Throwable t) {
            // ignorado
        }
        web.setBackgroundColor(0xFF0A0E1C);
        web.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("file://")) return false;
                Utils.openUrl(PreviewActivity.this, url);
                return true;
            }

            public void onReceivedError(WebView view, int errorCode, String description,
                                        String failingUrl) {
                appendConsole("[ERROR " + errorCode + "] " + description + "  " + failingUrl);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            public boolean onConsoleMessage(ConsoleMessage cm) {
                appendConsole("[" + cm.messageLevel() + "] " + cm.message()
                        + "  (" + cm.sourceId() + ":" + cm.lineNumber() + ")");
                return true;
            }
        });
    }

    private void appendConsole(final String line) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (!full) llConsole.setVisibility(consoleOn ? View.VISIBLE : View.GONE);
                String cur = tvConsole.getText().toString();
                if (cur.length() > 12000) cur = cur.substring(cur.length() - 8000);
                tvConsole.setText(cur + line + "\n");
                scrollConsole.post(new Runnable() {
                    public void run() {
                        scrollConsole.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    private void external() {
        File f = store.file(p, path);
        if (!f.isFile()) {
            Utils.toast(this, "Archivo no encontrado");
            return;
        }
        String ext = Utils.ext(path);
        if (ext.equals("html") || ext.equals("htm")) {
            try {
                Utils.allowFileUri();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(Uri.fromFile(f), "text/html");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Abrir con"));
                return;
            } catch (Throwable t) {
                // se intenta compartir
            }
        }
        Utils.shareFile(this, f);
    }

    public void onBackPressed() {
        if (full) {
            setFull(false);
            return;
        }
        if (web != null && web.getVisibility() == View.VISIBLE && web.canGoBack()) {
            web.goBack();
            return;
        }
        super.onBackPressed();
    }

    protected void onPause() {
        super.onPause();
        try {
            if (web != null) web.onPause();
        } catch (Throwable t) {
            // ignorado
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (web != null) web.onResume();
        } catch (Throwable t) {
            // ignorado
        }
        if (full) getWindow().getDecorView().postDelayed(hideAgain, 300);
    }
}
